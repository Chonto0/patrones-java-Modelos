package co.edu.udistrital.model;

public interface Observador {
    void actualizar(SensorEvent evento);
    String getNotificacion();
}
