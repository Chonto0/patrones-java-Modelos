package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;
import co.edu.udistrital.model.SensorEvent;

public class ModuloFrenos implements Observador {
    private String mensaje;

    @Override
    public void actualizar(SensorEvent evento) {
        mensaje = "Módulo de frenos iniciará verificación de seguridad por: " + evento.getTipoFalla() + ".";
    }


    @Override
    public String getNotificacion() {
        return mensaje;
    }
}
