package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;
import co.edu.udistrital.model.SensorEvent;

public class Conductor implements Observador {
    private String nombre;
    private String mensaje;

    public Conductor(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void actualizar(SensorEvent evento) {
        mensaje = "Conductor " + nombre + " ha sido notificado: Verifica " + evento.getTipoFalla() + ".";
    }


    @Override
    public String getNotificacion() {
        return mensaje;
    }
}
