package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;
import co.edu.udistrital.model.SensorEvent;

public class ModuloMotor implements Observador {
    private String mensaje;

    @Override
    public void actualizar(SensorEvent evento) {
        mensaje = "Ajustando rendimiento del motor ante: " + evento.getTipoFalla() + ".";
    }


    @Override
    public String getNotificacion() {
        return mensaje;
    }
}
