package co.edu.udistrital.model;

public class SensorEvent {
    private String tipoFalla;

    public SensorEvent(String tipoFalla) {
        this.tipoFalla = tipoFalla;
    }

    public String getTipoFalla() {
        return tipoFalla;
    }
}
