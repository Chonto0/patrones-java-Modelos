package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class SistemaCentral {

    private List<Observador> observadores;
    private List<String> notificacionesActuales;

    public SistemaCentral() {
        observadores = new ArrayList<>();
        notificacionesActuales = new ArrayList<>();
    }

    public void agregarObservador(Observador o) {
        observadores.add(o);
    }

    public void eliminarObservador(Observador o) {
        observadores.remove(o);
    }

    public void notificarFalla(String tipoFalla) {
        notificacionesActuales.clear(); 
        SensorEvent evento = new SensorEvent(tipoFalla);
        for (Observador o : observadores) {
            o.actualizar(evento);
            notificacionesActuales.add(o.getNotificacion());
        }
    }

    public List<String> getNotificaciones() {
        return notificacionesActuales;
    }
}
