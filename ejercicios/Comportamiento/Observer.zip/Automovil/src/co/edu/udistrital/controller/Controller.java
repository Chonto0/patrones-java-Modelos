package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private SistemaCentral sistema;

    public Controller() {
        vista = new VistaConsola();
        sistema = new SistemaCentral();

        sistema.agregarObservador(new Conductor("Carlos"));
        sistema.agregarObservador(new ModuloMotor());
        sistema.agregarObservador(new ModuloFrenos());
    }

    public void run() {
        vista.mostrarInformacion("Bienvenido al sistema de monitoreo del automóvil inteligente.");

        int opcion;
        do {
            vista.mostrarInformacion("\nSeleccione una opción:");
            vista.mostrarInformacion("1. Simular falla de presión de llanta");
            vista.mostrarInformacion("2. Simular falla de sensor de temperatura");
            vista.mostrarInformacion("3. Salir");

            opcion = vista.leerDatoEntero("Opción:");

            switch (opcion) {
                case 1:
                    sistema.notificarFalla("Presión baja en llanta delantera izquierda");
                    mostrarNotificaciones();
                    break;
                case 2:
                    sistema.notificarFalla("Fallo en sensor de temperatura del motor");
                    mostrarNotificaciones();
                    break;
                case 3:
                    vista.mostrarInformacion("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarInformacion("Opción no válida.");
            }

        } while (opcion != 3);
    }

    private void mostrarNotificaciones() {
        for (String msg : sistema.getNotificaciones()) {
            vista.mostrarInformacion(msg);
        }
    }
}
