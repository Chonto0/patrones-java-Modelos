package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class Alarma implements Observador {
    @Override
    public String actualizar(String evento) {
        return "\nAlarma activada: " + evento;
    }
}
