package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class Luces implements Observador {
    @Override
    public String actualizar(String evento) {
        return "\nLuces encendidas por: " + evento;
    }
}
