package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class Grabadora implements Observador {
    @Override
    public String actualizar(String evento) {
        return "Grabación iniciada por: " + evento;
    }
}
