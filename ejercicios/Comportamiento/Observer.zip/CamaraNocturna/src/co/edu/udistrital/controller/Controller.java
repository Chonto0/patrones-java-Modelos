package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

import java.util.List;

public class Controller {

	private VistaConsola vista;
	private CamaraNocturna camara;

	public Controller() {
		camara = new CamaraNocturna();
		vista = new VistaConsola();

		camara.agregarObservador(new Alarma());
		camara.agregarObservador(new Luces());
		camara.agregarObservador(new Grabadora());
	}

	public void run() {
		int opcion;
		do {
			vista.mostrarInformacion("\n=== Cámara Nocturna ===");
			vista.mostrarInformacion("1. Simular detección de movimiento");
			vista.mostrarInformacion("2. Simular detección de calor");
			vista.mostrarInformacion("0. Salir");

			opcion = vista.leerDatoEntero("\nSeleccione una opción:");

			List<String> respuestas = null;

			switch (opcion) {
			case 1:
				respuestas = camara.detectarMovimiento();
				break;
			case 2:
				respuestas = camara.detectarCalor();
				break;
			case 0:
				vista.mostrarInformacion("\nSaliendo del sistema...");
				break;
			default:
				vista.mostrarInformacion("\nOpción no válida.");
			}

			if (respuestas != null) {
				for (String r : respuestas) {
					vista.mostrarInformacion(r);
				}
			}

		} while (opcion != 0);
	}
}
