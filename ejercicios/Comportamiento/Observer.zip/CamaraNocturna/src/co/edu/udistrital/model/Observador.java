package co.edu.udistrital.model;

public interface Observador {
    String actualizar(String evento);
}
