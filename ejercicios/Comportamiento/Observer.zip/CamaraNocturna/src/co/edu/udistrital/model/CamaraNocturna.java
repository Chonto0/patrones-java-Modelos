package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class CamaraNocturna {

    private List<Observador> observadores;

    public CamaraNocturna() {
        observadores = new ArrayList<>();
    }

    public void agregarObservador(Observador obs) {
        observadores.add(obs);
    }

    public void eliminarObservador(Observador obs) {
        observadores.remove(obs);
    }

    public List<String> detectarMovimiento() {
        return notificar("\nMovimiento detectado");
    }

    public List<String> detectarCalor() {
        return notificar("\nFuente de calor detectada");
    }

    private List<String> notificar(String evento) {
        List<String> mensajes = new ArrayList<>();
        for (Observador o : observadores) {
            mensajes.add(o.actualizar(evento));
        }
        return mensajes;
    }
}
