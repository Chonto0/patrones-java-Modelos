package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class TorreControl implements Observador {
    @Override
    public String actualizar(String mensaje) {
        if (mensaje.contains("Misil lanzado")) {
            return "[Torre de Control] Solicitar permiso para lanzar siguiente misil.";
        } else if (mensaje.contains("Altitud")) {
            return "[Torre de Control] Altitud registrada.";
        } else {
            return "[Torre de Control] Atención: Ataque en curso, avisar a unidades cercanas.";
        }
    }
}
