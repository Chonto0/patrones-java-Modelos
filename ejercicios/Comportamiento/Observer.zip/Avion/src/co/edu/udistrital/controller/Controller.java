package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

import java.util.List;

public class Controller {

    private VistaConsola vista;
    private Avion avion;

    public Controller() {
        this.vista = new VistaConsola();
        this.avion = new Avion();

        avion.agregarObservador(new PanelEstado());
        avion.agregarObservador(new Radar());
        avion.agregarObservador(new TorreControl());
    }

    public void run() {
        boolean salir = false;
        while (!salir) {
            vista.mostrarInformacion("\n--- Simulador de Avión de Guerra ---");
            vista.mostrarInformacion("1. Recibir ataque");
            vista.mostrarInformacion("2. Lanzar misil");
            vista.mostrarInformacion("3. Cambiar altitud");
            vista.mostrarInformacion("4. Ver estado");
            vista.mostrarInformacion("5. Salir");

            int opcion = vista.leerDatoEntero("Seleccione una opción:");

            List<String> mensajes;
            switch (opcion) {
                case 1:
                    mensajes = avion.recibirAtaque();
                    for (String msg : mensajes) vista.mostrarInformacion(msg);
                    break;
                case 2:
                    mensajes = avion.lanzarMisil();
                    for (String msg : mensajes) vista.mostrarInformacion(msg);
                    break;
                case 3:
                    int alt = vista.leerDatoEntero("Ingrese nueva altitud:");
                    mensajes = avion.cambiarAltitud(alt);
                    for (String msg : mensajes) vista.mostrarInformacion(msg);
                    break;
                case 4:
                    vista.mostrarInformacion("Altitud: " + avion.getAltitud() + " m");
                    vista.mostrarInformacion("Misiles restantes: " + avion.getMisiles());
                    break;
                case 5:
                    salir = true;
                    break;
                default:
                    vista.mostrarInformacion("Opción no válida.");
            }
        }

        vista.mostrarInformacion("Simulación finalizada.");
    }
}
