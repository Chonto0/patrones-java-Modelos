package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class PanelEstado implements Observador {
	@Override
	public String actualizar(String mensaje) {
		if (mensaje.contains("Misil lanzado")) {
			return "[Panel Estado] Arsenal actualizado: " + mensaje;
		} else if (mensaje.contains("Altitud")) {
			return "[Panel Estado] " + mensaje;
		} else {
			return "[Panel Estado] ALERTA: " + mensaje;
		}
	}
}
