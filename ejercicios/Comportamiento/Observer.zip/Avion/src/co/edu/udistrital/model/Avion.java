package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Avion {
    private List<Observador> observadores = new ArrayList<>();
    private int altitud = 1000;
    private int misiles = 5;

    public void agregarObservador(Observador o) {
        observadores.add(o);
    }

    public void quitarObservador(Observador o) {
        observadores.remove(o);
    }

    private List<String> notificar(String mensaje) {
        List<String> respuestas = new ArrayList<>();
        for (Observador o : observadores) {
            respuestas.add(o.actualizar(mensaje));
        }
        return respuestas;
    }

    public List<String> recibirAtaque() {
        return notificar("¡Avión atacado! Maniobra evasiva activada.");
    }

    public List<String> lanzarMisil() {
        if (misiles > 0) {
            misiles--;
            return notificar("Misil lanzado. Misiles restantes: " + misiles);
        } else {
            return notificar("¡Sin misiles disponibles!");
        }
    }

    public List<String> cambiarAltitud(int nuevaAltitud) {
        this.altitud = nuevaAltitud;
        return notificar("Altitud actual: " + altitud + " metros.");
    }

    public int getAltitud() {
        return altitud;
    }

    public int getMisiles() {
        return misiles;
    }
}
