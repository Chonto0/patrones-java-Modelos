package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Observador;

public class Radar implements Observador {
    @Override
    public String actualizar(String mensaje) {
        if (mensaje.contains("Misil lanzado")) {
            return "[Radar] Detectando trayectoria del misil...";
        } else if (mensaje.contains("Altitud")) {
            return "[Radar] Ajuste de altitud detectado.";
        } else {
            return "[Radar] Ataque detectado en coordenadas del avión.";
        }
    }
}
