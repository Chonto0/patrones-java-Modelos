package co.edu.udistrital.model;

public class GestorBackup {

	private Aplicacion.Backup ultimoBackup;

	public void guardarBackup(Aplicacion.Backup backup) {
		this.ultimoBackup = backup;
	}

	public String restaurarBackup() {
		if (ultimoBackup != null) {
			ultimoBackup.restaurar();
		}
		return "\nNo hay backups disponibles.";
	}

}
