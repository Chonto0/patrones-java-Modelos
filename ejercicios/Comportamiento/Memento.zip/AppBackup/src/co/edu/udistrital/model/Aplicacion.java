package co.edu.udistrital.model;

public class Aplicacion {

    private String version;

    public Aplicacion(String versionInicial) {
        this.version = versionInicial;
    }

    public void setVersion(String nuevaVersion) {
        this.version = nuevaVersion;
    }

    public String getVersion() {
        return version;
    }

    public Backup crearBackup() {
        return new Backup(this, version);
    }

    public static class Backup {

        private Aplicacion app;
        private String estado;

        private Backup(Aplicacion app, String estado) {
            this.app = app;
            this.estado = estado;
        }

        public void restaurar() {
            app.setVersion(estado);
        }

    }

}
