package co.edu.udistrital.controller;

import co.edu.udistrital.model.Aplicacion;
import co.edu.udistrital.model.GestorBackup;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	public void run() {

		boolean salir = false;
		Aplicacion app = new Aplicacion("1.0");
		GestorBackup gestor = new GestorBackup();
		VistaConsola vista = new VistaConsola();

		while (!salir) {
			vista.mostrarInformacion("\n--- MENÚ ---");
			vista.mostrarInformacion("1. Crear nueva versión de la aplicación");
			vista.mostrarInformacion("2. Mostrar estado actual");
			vista.mostrarInformacion("3. Guardar backup");
			vista.mostrarInformacion("4. Restaurar última versión guardada");
			vista.mostrarInformacion("5. Salir");

			String opcion = vista.leerCadenaTexto("\nSeleccione una opción: ");

			switch (opcion) {
			case "1" -> {
				String nuevaVersion = vista.leerCadenaTexto("\nIngrese nueva versión: ");
				app.setVersion(nuevaVersion);
				break;
			}
			case "2" -> {
				vista.mostrarInformacion("\nVersión actual: " + app.getVersion());
				break;
			}
			case "3" -> {
				gestor.guardarBackup(app.crearBackup());
				vista.mostrarInformacion("\nBackup guardado exitosamente.");
				break;
			}
			case "4" -> {
				gestor.restaurarBackup();
				break;
			}
			case "5" -> {
				salir = true;
			}
			}
		}
	}
}
