package co.edu.udistrital.model;

import java.util.Random;

public class Juego {
	private String nombreJugador;
	private int nivel;
	private int vidas;

	public Juego(String nombreJugador) {
		this.nombreJugador = nombreJugador;
		this.nivel = 1;
		this.vidas = generarVidasAleatorias(); 
	}

	private int generarVidasAleatorias() {
		Random rand = new Random();
		return rand.nextInt(5) + 1; 
	}

	public void jugarNivel() {
		nivel++;
		vidas--;
	}

	public String obtenerEstado() {
		return "Jugador: " + nombreJugador + "\nNivel: " + nivel + "\nVidas: " + vidas;
	}

	public SlotPartida crearSlot() {
		return new SlotPartida(this, nombreJugador, nivel, vidas);
	}

	public void restaurar(SlotPartida slot) {
		this.nombreJugador = slot.nombreJugador;
		this.nivel = slot.nivel;
		this.vidas = slot.vidas;
	}

	public static class SlotPartida {
		private Juego juego;
		private String nombreJugador;
		private int nivel;
		private int vidas;

		private SlotPartida(Juego juego, String nombreJugador, int nivel, int vidas) {
			this.juego = juego;
			this.nombreJugador = nombreJugador;
			this.nivel = nivel;
			this.vidas = vidas;
		}

		public void cargar() {
			juego.restaurar(this);
		}
	}
}
