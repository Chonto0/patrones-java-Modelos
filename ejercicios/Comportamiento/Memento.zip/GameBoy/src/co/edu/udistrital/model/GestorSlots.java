package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

import co.edu.udistrital.model.Juego.SlotPartida;

public class GestorSlots {
    private Map<Integer, SlotPartida> slots = new HashMap<>();

    public void guardarSlot(int numero, SlotPartida slot) {
        slots.put(numero, slot);
    }

    public SlotPartida obtenerSlot(int numero) {
        return slots.get(numero);
    }

    public boolean existeSlot(int numero) {
        return slots.containsKey(numero);
    }

    public String mostrarSlotsDisponibles() {
        if (slots.isEmpty()) return "No hay slots guardados.";
        StringBuilder sb = new StringBuilder("Slots guardados:\n");
        for (Integer num : slots.keySet()) {
            sb.append("Slot ").append(num).append("\n");
        }
        return sb.toString();
    }
}
