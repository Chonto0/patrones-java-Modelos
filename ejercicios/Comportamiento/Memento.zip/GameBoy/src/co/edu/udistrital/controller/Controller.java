package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	private Juego juego;
	private GestorSlots gestor;

	public Controller() {
		vista = new VistaConsola();
		gestor = new GestorSlots();
	}

	public void run() {
		String nombre = vista.leerCadenaTexto("Bienvenido. Ingresa tu nombre de jugador:");
		juego = new Juego(nombre);

		int opcion;
		do {
			vista.mostrarInformacion("\n== Menú del Emulador GameBoy ==");
			vista.mostrarInformacion("1. Jugar nivel");
			vista.mostrarInformacion("2. Guardar partida");
			vista.mostrarInformacion("3. Cargar partida");
			vista.mostrarInformacion("4. Ver estado actual");
			vista.mostrarInformacion("5. Ver slots guardados");
			vista.mostrarInformacion("0. Salir");

			opcion = vista.leerDatoEntero("Selecciona una opción:");

			switch (opcion) {
			case 1:
				juego.jugarNivel();
				vista.mostrarInformacion("¡Nivel jugado!");
				break;
			case 2:
				int numSlotGuardar = vista.leerDatoEntero("Ingresa número de slot para guardar:");
				gestor.guardarSlot(numSlotGuardar, juego.crearSlot());
				vista.mostrarInformacion("Partida guardada en slot " + numSlotGuardar);
				break;
			case 3:
				int numSlotCargar = vista.leerDatoEntero("Ingresa número de slot para cargar:");
				if (gestor.existeSlot(numSlotCargar)) {
					gestor.obtenerSlot(numSlotCargar).cargar();
					vista.mostrarInformacion("Slot " + numSlotCargar + " cargado exitosamente.");
				} else {
					vista.mostrarInformacion("Ese slot no existe.");
				}
				break;
			case 4:
				vista.mostrarInformacion("Estado actual del juego:\n" + juego.obtenerEstado());

				break;
			case 5:
				vista.mostrarInformacion(gestor.mostrarSlotsDisponibles());
				break;
			case 0:
				vista.mostrarInformacion("¡Hasta pronto!");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}
		} while (opcion != 0);
	}
}
