package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class EditorUML {

	private List<String> clases;

	public EditorUML() {
		clases = new ArrayList<>();
	}

	public void agregarClase(String nombreClase) {
		clases.add(nombreClase);
	}

	public String obtenerDiagrama() {
		if (clases.isEmpty()) {
			return "El diagrama UML está vacío.";
		}
		StringBuilder sb = new StringBuilder("Clases en el diagrama:\n");
		for (String c : clases) {
			sb.append("- ").append(c).append("\n");
		}
		return sb.toString();
	}

	public static class Memento {
		private String claseReciente;

		private Memento(String claseReciente) {
			this.claseReciente = claseReciente;
		}

		private String getClaseReciente() {
			return claseReciente;
		}
	}

	public Memento crearMemento() {
		if (!clases.isEmpty()) {
			return new Memento(clases.get(clases.size() - 1));
		}
		return null;
	}

	public void restaurar(Memento memento) {
		if (memento != null) {
			clases.remove(memento.getClaseReciente());
		}
	}
}
