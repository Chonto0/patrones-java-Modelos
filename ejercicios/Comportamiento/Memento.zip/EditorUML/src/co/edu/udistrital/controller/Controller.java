package co.edu.udistrital.controller;

import co.edu.udistrital.model.EditorUML;
import co.edu.udistrital.model.Historial;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private EditorUML editor;
	private Historial historial;

	public Controller() {
		vista = new VistaConsola();
		editor = new EditorUML();
		historial = new Historial();
	}

	public void run() {
		int opcion;
		do {
			vista.mostrarInformacion(
					"\nEditor UML - Menú:\n1. Agregar clase\n2. Mostrar diagrama\n3. Deshacer última clase\n0. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción:");

			switch (opcion) {
			case 1 -> {
				String nombreClase = vista.leerCadenaTexto("Ingrese el nombre de la clase:");
				editor.agregarClase(nombreClase);
				historial.guardar(editor.crearMemento());
			}
			case 2 -> vista.mostrarInformacion(editor.obtenerDiagrama());
			case 3 -> {
				EditorUML.Memento m = historial.deshacer();
				if (m != null) {
					editor.restaurar(m);
					vista.mostrarInformacion("Última clase eliminada.");
				} else {
					vista.mostrarInformacion("No hay clases para deshacer.");
				}
			}
			case 0 -> vista.mostrarInformacion("Saliendo del programa...");
			default -> vista.mostrarInformacion("Opción inválida.");
			}
		} while (opcion != 0);
	}
}
