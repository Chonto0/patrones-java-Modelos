package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Historial {

	private List<EditorUML.Memento> historial;
	private int indiceActual;

	public Historial() {
		historial = new ArrayList<>();
		indiceActual = -1;
	}

	public void guardar(EditorUML.Memento memento) {
		if (memento == null)
			return;

		while (historial.size() > indiceActual + 1) {
			historial.remove(historial.size() - 1);
		}
		historial.add(memento);
		indiceActual++;
	}

	public EditorUML.Memento deshacer() {
		if (indiceActual >= 0) {
			EditorUML.Memento m = historial.get(indiceActual);
			indiceActual--;
			return m;
		}
		return null;
	}
}
