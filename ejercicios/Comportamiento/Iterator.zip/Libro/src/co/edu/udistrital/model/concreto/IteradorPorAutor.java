package co.edu.udistrital.model.concreto;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import co.edu.udistrital.model.Libro;
import co.edu.udistrital.model.LibroIterator;

public class IteradorPorAutor implements LibroIterator {
    private Iterator<Libro> iterator;

    public IteradorPorAutor(List<Libro> libros) {
        libros.sort(Comparator.comparing(Libro::getAutor));
        this.iterator = libros.iterator();
    }

    public boolean hasNext() {
        return iterator.hasNext();
    }

    public Libro next() {
        return iterator.next();
    }
}