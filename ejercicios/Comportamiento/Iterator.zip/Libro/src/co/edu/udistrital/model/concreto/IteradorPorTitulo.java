package co.edu.udistrital.model.concreto;

import java.util.*;

import co.edu.udistrital.model.Libro;
import co.edu.udistrital.model.LibroIterator;

public class IteradorPorTitulo implements LibroIterator {
    private Iterator<Libro> iterator;

    public IteradorPorTitulo(List<Libro> libros) {
        libros.sort(Comparator.comparing(Libro::getTitulo));
        this.iterator = libros.iterator();
    }

    public boolean hasNext() {
        return iterator.hasNext();
    }

    public Libro next() {
        return iterator.next();
    }
}




