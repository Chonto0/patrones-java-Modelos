package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.*;

public class Controller {

    private VistaConsola vista;
    private Catalogo catalogo;

    public Controller() {
        vista = new VistaConsola();
        catalogo = new Catalogo();
        poblarCatalogo();
    }

    private void poblarCatalogo() {
        catalogo.agregarLibro(new Libro("Cien Años de Soledad", "Gabriel García Márquez", "Realismo Mágico"));
        catalogo.agregarLibro(new Libro("El Hobbit", "J.R.R. Tolkien", "Fantasía"));
        catalogo.agregarLibro(new Libro("1984", "George Orwell", "Distopía"));
        catalogo.agregarLibro(new Libro("Rayuela", "Julio Cortázar", "Surrealismo"));
        catalogo.agregarLibro(new Libro("El Aleph", "Jorge Luis Borges", "Ficción"));
    }

    public void run() {
        boolean salir = false;
        while (!salir) {
            vista.mostrarInformacion("\n--- Biblioteca Digital ---");
            vista.mostrarInformacion("1. Ver libros por título");
            vista.mostrarInformacion("2. Ver libros por autor");
            vista.mostrarInformacion("3. Ver libros por género");
            vista.mostrarInformacion("0. Salir");

            int opcion = vista.leerDatoEntero("Selecciona una opción:");
            LibroIterator iterador = null;

            switch (opcion) {
                case 1:
                    iterador = catalogo.crearIteradorPorTitulo();
                    break;
                case 2:
                    iterador = catalogo.crearIteradorPorAutor();
                    break;
                case 3:
                    iterador = catalogo.crearIteradorPorGenero();
                    break;
                case 0:
                    salir = true;
                    continue;
                default:
                    vista.mostrarInformacion("Opción no válida");
                    continue;
            }

            vista.mostrarInformacion("Libros encontrados:\n");
            while (iterador.hasNext()) {
                vista.mostrarInformacion(iterador.next().toString());
            }
        }

        vista.mostrarInformacion("¡Hasta pronto!");
    }
}
