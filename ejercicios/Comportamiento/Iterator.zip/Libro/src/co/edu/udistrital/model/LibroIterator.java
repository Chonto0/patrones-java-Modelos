package co.edu.udistrital.model;

public interface LibroIterator {
    boolean hasNext();
    Libro next();
}
