package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.concreto.*;

public class Catalogo {
    private List<Libro> libros = new ArrayList<>();

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    public List<Libro> getLibros() {
        return libros;
    }

    public LibroIterator crearIteradorPorTitulo() {
        return new IteradorPorTitulo(libros);
    }

    public LibroIterator crearIteradorPorAutor() {
        return new IteradorPorAutor(libros);
    }

    public LibroIterator crearIteradorPorGenero() {
        return new IteradorPorGenero(libros);
    }
}
