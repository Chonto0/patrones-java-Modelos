package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private Inventario inventario;

	public Controller() {
		inventario = new Inventario();
		vista = new VistaConsola();
		cargarDatos();
	}

	private void cargarDatos() {
		inventario.agregarProducto(new Producto("Cuaderno", "Papelería", "Tigre", 50));
		inventario.agregarProducto(new Producto("Esfero", "Papelería", "Tigre", 20));
		inventario.agregarProducto(new Producto("Regla", "Papelería", "Norma", 10));
		inventario.agregarProducto(new Producto("Tinta", "Impresión", "Canon", 5));
		inventario.agregarProducto(new Producto("Cartucho", "Impresión", "HP", 2));
	}

	public void run() {
		int opcion;
		do {
			vista.mostrarInformacion(
					"\n1. Buscar por categoría\n2. Buscar por proveedor\n3. Buscar por stock bajo\n0. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción:");

			switch (opcion) {
			case 1:
				String cat = vista.leerCadenaTexto("Ingrese la categoría:");
				mostrarProductos(inventario.crearIteradorPorCategoria(cat));
				break;
			case 2:
				String prov = vista.leerCadenaTexto("Ingrese el proveedor:");
				mostrarProductos(inventario.crearIteradorPorProveedor(prov));
				break;
			case 3:
				int stock = vista.leerDatoEntero("Mostrar productos con stock menor a:");
				mostrarProductos(inventario.crearIteradorPorStock(stock));
				break;
			case 0:
				vista.mostrarInformacion("Saliendo del sistema...");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}
		} while (opcion != 0);
	}

	private void mostrarProductos(IteradorProducto iterador) {
		boolean encontrado = false;
		while (iterador.hasNext()) {
			vista.mostrarInformacion(iterador.next().toString());
			encontrado = true;
		}
		if (!encontrado) {
			vista.mostrarInformacion("No se encontraron productos.");
		}
	}
}
