package co.edu.udistrital.model;

public class Producto {
	private String nombre;
	private String categoria;
	private String proveedor;
	private int stock;

	public Producto(String nombre, String categoria, String proveedor, int stock) {
		this.nombre = nombre;
		this.categoria = categoria;
		this.proveedor = proveedor;
		this.stock = stock;
	}

	public String getNombre() {
		return nombre;
	}

	public String getCategoria() {
		return categoria;
	}

	public String getProveedor() {
		return proveedor;
	}

	public int getStock() {
		return stock;
	}

	@Override
	public String toString() {
		return nombre + " | " + categoria + " | " + proveedor + " | Stock: " + stock;
	}
}
