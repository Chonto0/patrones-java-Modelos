package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.IteradorProducto;
import co.edu.udistrital.model.Producto;

public class IteradorPorStock implements IteradorProducto {
	private List<Producto> productos;
	private int limite;
	private int posicion = 0;

	public IteradorPorStock(List<Producto> productos, int limite) {
		this.productos = productos;
		this.limite = limite;
	}

	public boolean hasNext() {
		while (posicion < productos.size()) {
			if (productos.get(posicion).getStock() < limite) {
				return true;
			}
			posicion++;
		}
		return false;
	}

	public Producto next() {
		return productos.get(posicion++);
	}
}
