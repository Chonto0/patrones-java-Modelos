package co.edu.udistrital.model;

public interface IteradorProducto {
	boolean hasNext();
	Producto next();
}
