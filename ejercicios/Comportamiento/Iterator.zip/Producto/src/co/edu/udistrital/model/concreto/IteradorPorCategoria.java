package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.IteradorProducto;
import co.edu.udistrital.model.Producto;

public class IteradorPorCategoria implements IteradorProducto {
	private List<Producto> productos;
	private String categoria;
	private int posicion = 0;

	public IteradorPorCategoria(List<Producto> productos, String categoria) {
		this.productos = productos;
		this.categoria = categoria;
	}

	public boolean hasNext() {
		while (posicion < productos.size()) {
			if (productos.get(posicion).getCategoria().equalsIgnoreCase(categoria)) {
				return true;
			}
			posicion++;
		}
		return false;
	}

	public Producto next() {
		return productos.get(posicion++);
	}
}
