package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.IteradorProducto;
import co.edu.udistrital.model.Producto;

public class IteradorPorProveedor implements IteradorProducto {
	private List<Producto> productos;
	private String proveedor;
	private int posicion = 0;

	public IteradorPorProveedor(List<Producto> productos, String proveedor) {
		this.productos = productos;
		this.proveedor = proveedor;
	}

	public boolean hasNext() {
		while (posicion < productos.size()) {
			if (productos.get(posicion).getProveedor().equalsIgnoreCase(proveedor)) {
				return true;
			}
			posicion++;
		}
		return false;
	}

	public Producto next() {
		return productos.get(posicion++);
	}
}
