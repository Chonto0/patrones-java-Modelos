package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.concreto.*;

public class Inventario {
	private List<Producto> productos = new ArrayList<>();

	public void agregarProducto(Producto producto) {
		productos.add(producto);
	}

	public IteradorProducto crearIteradorPorCategoria(String categoria) {
		return new IteradorPorCategoria(productos, categoria);
	}

	public IteradorProducto crearIteradorPorProveedor(String proveedor) {
		return new IteradorPorProveedor(productos, proveedor);
	}

	public IteradorProducto crearIteradorPorStock(int limiteInferior) {
		return new IteradorPorStock(productos, limiteInferior);
	}
}
