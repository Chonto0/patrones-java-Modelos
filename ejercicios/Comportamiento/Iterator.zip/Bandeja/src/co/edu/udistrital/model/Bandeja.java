package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.concreto.IteradorDeMensajes;

public class Bandeja {
    private List<Mensaje> mensajes;

    public Bandeja() {
        mensajes = new ArrayList<>();
    }

    public void agregarMensaje(Mensaje mensaje) {
        mensajes.add(mensaje);
    }

    public IteradorMensaje crearIterador() {
        return new IteradorDeMensajes(this);
    }

    public List<Mensaje> getMensajes() {
        return mensajes;
    }
}
