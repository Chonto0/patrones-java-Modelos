package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.Bandeja;
import co.edu.udistrital.model.IteradorMensaje;
import co.edu.udistrital.model.Mensaje;

public class IteradorDeMensajes implements IteradorMensaje {
    private List<Mensaje> mensajes;
    private int posicionActual = 0;

    public IteradorDeMensajes(Bandeja bandeja) {
        this.mensajes = bandeja.getMensajes();
    }

    public boolean hasNext() {
        return posicionActual < mensajes.size();
    }

    public Mensaje next() {
        return mensajes.get(posicionActual++);
    }
}
