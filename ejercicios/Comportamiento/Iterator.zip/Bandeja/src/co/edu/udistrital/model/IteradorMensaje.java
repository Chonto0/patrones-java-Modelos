package co.edu.udistrital.model;

public interface IteradorMensaje {
    boolean hasNext();
    Mensaje next();
}
