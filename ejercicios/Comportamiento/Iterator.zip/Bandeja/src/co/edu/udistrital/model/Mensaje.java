package co.edu.udistrital.model;

public class Mensaje {
    private String asunto;
    private String contenido;

    public Mensaje(String asunto, String contenido) {
        this.asunto = asunto;
        this.contenido = contenido;
    }

    public String getAsunto() {
        return asunto;
    }

    public String getContenido() {
        return contenido;
    }

    @Override
    public String toString() {
        return "Asunto: " + asunto + "\nContenido: " + contenido + "\n";
    }
}
