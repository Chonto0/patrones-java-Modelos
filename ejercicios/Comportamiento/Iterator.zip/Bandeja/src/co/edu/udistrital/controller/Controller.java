package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private ClienteCorreo clienteCorreo;

	public Controller() {
		clienteCorreo = new ClienteCorreo();
		vista = new VistaConsola();
	}

	public void run() {
		int opcion;

		do {
			vista.mostrarInformacion(
					"\n--- Cliente de Correo ---\n1. Ver Bandeja de Entrada\n2. Ver Bandeja de Salida\n3. Ver Borradores\n4. Agregar Mensaje\n0. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción:");

			switch (opcion) {
			case 1:
				mostrarMensajes(clienteCorreo.getEntrada(), "Entrada");
				break;
			case 2:
				mostrarMensajes(clienteCorreo.getSalida(), "Salida");
				break;
			case 3:
				mostrarMensajes(clienteCorreo.getBorradores(), "Borradores");
				break;
			case 4:
				agregarMensaje();
				break;
			case 0:
				vista.mostrarInformacion("¡Hasta luego!");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}
		} while (opcion != 0);
	}

	private void mostrarMensajes(Bandeja bandeja, String nombre) {
		vista.mostrarInformacion("\n--- Mensajes en Bandeja de " + nombre + " ---");
		IteradorMensaje iterador = bandeja.crearIterador();

		if (!iterador.hasNext()) {
			vista.mostrarInformacion("No hay mensajes.");
			return;
		}

		while (iterador.hasNext()) {
			Mensaje msg = iterador.next();
			vista.mostrarInformacion(msg.toString());
		}
	}

	private void agregarMensaje() {
		String asunto = vista.leerCadenaTexto("Ingrese el asunto:");
		String contenido = vista.leerCadenaTexto("Ingrese el contenido:");

		int destino = vista.leerDatoEntero("¿A qué bandeja desea agregarlo?\n1. Entrada\n2. Salida\n3. Borradores");

		Mensaje nuevo = new Mensaje(asunto, contenido);

		switch (destino) {
		case 1:
			clienteCorreo.getEntrada().agregarMensaje(nuevo);
			vista.mostrarInformacion("Mensaje agregado a Entrada.");
			break;
		case 2:
			clienteCorreo.getSalida().agregarMensaje(nuevo);
			vista.mostrarInformacion("Mensaje agregado a Salida.");
			break;
		case 3:
			clienteCorreo.getBorradores().agregarMensaje(nuevo);
			vista.mostrarInformacion("Mensaje agregado a Borradores.");
			break;
		default:
			vista.mostrarInformacion("Opción no válida. No se agregó el mensaje.");
		}
	}
}
