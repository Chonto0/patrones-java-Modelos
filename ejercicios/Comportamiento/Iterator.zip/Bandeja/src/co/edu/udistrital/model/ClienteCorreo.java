package co.edu.udistrital.model;

public class ClienteCorreo {
    private Bandeja entrada;
    private Bandeja salida;
    private Bandeja borradores;

    public ClienteCorreo() {
        entrada = new Bandeja();
        salida = new Bandeja();
        borradores = new Bandeja();

        entrada.agregarMensaje(new Mensaje("Bienvenido", "Gracias por registrarte."));
        entrada.agregarMensaje(new Mensaje("Factura", "Tu factura de este mes."));
        
        salida.agregarMensaje(new Mensaje("Reunión", "Confirmación de asistencia."));
        
        borradores.agregarMensaje(new Mensaje("Idea", "Recordar enviar propuesta."));
    }

    public Bandeja getEntrada() {
        return entrada;
    }

    public Bandeja getSalida() {
        return salida;
    }

    public Bandeja getBorradores() {
        return borradores;
    }
}
