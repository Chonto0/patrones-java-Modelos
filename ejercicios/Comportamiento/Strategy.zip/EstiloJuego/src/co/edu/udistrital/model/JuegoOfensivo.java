package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstiloJuego;

public class JuegoOfensivo implements EstiloJuego {

    @Override
    public String ejecutarTactica() {
        return "El equipo presiona alto, domina la posesión y busca goles constantemente.";
    }
}
