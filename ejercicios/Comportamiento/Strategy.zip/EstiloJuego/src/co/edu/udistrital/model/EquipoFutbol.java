package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstiloJuego;

public class EquipoFutbol {
    private String nombre;
    private EstiloJuego estilo;

    public EquipoFutbol(String nombre) {
        this.nombre = nombre;
    }

    public void setEstilo(EstiloJuego estilo) {
        this.estilo = estilo;
    }

    public String jugar() {
        if (estilo == null) {
            return "No se ha definido un estilo de juego.";
        }
        return "El equipo " + nombre + " ejecuta su estilo: " + estilo.ejecutarTactica();
    }
}
