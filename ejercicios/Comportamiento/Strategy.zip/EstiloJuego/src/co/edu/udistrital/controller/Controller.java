package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private EquipoFutbol equipo;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		String nombre = vista.leerCadenaTexto("Ingrese el nombre del equipo:");
		equipo = new EquipoFutbol(nombre);

		boolean salir = false;
		while (!salir) {
			vista.mostrarInformacion("\nSeleccione el estilo de juego:");
			vista.mostrarInformacion("1. Defensivo");
			vista.mostrarInformacion("2. Ofensivo");
			vista.mostrarInformacion("3. Equilibrado");
			vista.mostrarInformacion("4. Salir");

			int opcion = vista.leerDatoEntero("Opción:");

			switch (opcion) {
			case 1:
				equipo.setEstilo(new JuegoDefensivo());
				vista.mostrarInformacion(equipo.jugar());
				break;
			case 2:
				equipo.setEstilo(new JuegoOfensivo());
				vista.mostrarInformacion(equipo.jugar());
				break;
			case 3:
				equipo.setEstilo(new JuegoEquilibrado());
				vista.mostrarInformacion(equipo.jugar());
				break;
			case 4:
				salir = true;
				vista.mostrarInformacion("¡Hasta luego!");
				break;
			default:
				vista.mostrarInformacion("Opción inválida. Intente de nuevo.");
			}
		}
	}
}
