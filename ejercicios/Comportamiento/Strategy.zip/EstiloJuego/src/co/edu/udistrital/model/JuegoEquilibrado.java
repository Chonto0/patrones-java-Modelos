package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstiloJuego;

public class JuegoEquilibrado implements EstiloJuego {

    @Override
    public String ejecutarTactica() {
        return "El equipo equilibra defensa y ataque, se adapta según el partido.";
    }
}
