package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstiloJuego;

public class JuegoDefensivo implements EstiloJuego {

    @Override
    public String ejecutarTactica() {
        return "El equipo se posiciona atrás, prioriza la defensa y busca contraataques.";
    }
}
