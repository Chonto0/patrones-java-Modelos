package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class PrendaZapatoDeportivo implements EstrategiaPrenda {
    public String descripcion() {
        return "Tenis deportivos blancos.";
    }
}
