package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class Persona {

    private String nombre;
    private EstrategiaPrenda camisa;
    private EstrategiaPrenda pantalon;
    private EstrategiaPrenda calzado;

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public void setCamisa(EstrategiaPrenda camisa) {
        this.camisa = camisa;
    }

    public void setPantalon(EstrategiaPrenda pantalon) {
        this.pantalon = pantalon;
    }

    public void setCalzado(EstrategiaPrenda calzado) {
        this.calzado = calzado;
    }

    public String mostrarConjunto() {
        StringBuilder conjunto = new StringBuilder();
        conjunto.append("Conjunto de " + nombre + ":\n");

        conjunto.append("Camisa: " + (camisa != null ? camisa.descripcion() : "No seleccionada") + "\n");
        conjunto.append("Pantalón: " + (pantalon != null ? pantalon.descripcion() : "No seleccionado") + "\n");
        conjunto.append("Calzado: " + (calzado != null ? calzado.descripcion() : "No seleccionado") + "\n");

        return conjunto.toString();
    }
}
