package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class PrendaPantalonJeans implements EstrategiaPrenda {
    public String descripcion() {
        return "Jeans azul oscuro.";
    }
}
