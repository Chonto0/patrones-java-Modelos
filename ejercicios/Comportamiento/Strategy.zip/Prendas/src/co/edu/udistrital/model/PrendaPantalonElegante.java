package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class PrendaPantalonElegante implements EstrategiaPrenda {
    public String descripcion() {
        return "Pantalón de vestir negro.";
    }
}
