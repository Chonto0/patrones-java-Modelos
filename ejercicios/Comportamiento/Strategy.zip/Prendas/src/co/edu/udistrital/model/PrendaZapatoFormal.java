package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class PrendaZapatoFormal implements EstrategiaPrenda {
    public String descripcion() {
        return "Zapatos de cuero negros.";
    }
}
