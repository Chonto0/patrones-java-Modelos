package co.edu.udistrital.model.strategy;

public interface EstrategiaPrenda {
    String descripcion();
}
