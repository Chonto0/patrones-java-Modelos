package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private Persona persona;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        String nombre = vista.leerCadenaTexto("Ingrese su nombre:");
        persona = new Persona(nombre);

        boolean salir = false;

        while (!salir) {
            vista.mostrarInformacion("\nMenú:");
            vista.mostrarInformacion("1. Seleccionar camisa");
            vista.mostrarInformacion("2. Seleccionar pantalón");
            vista.mostrarInformacion("3. Seleccionar calzado");
            vista.mostrarInformacion("4. Mostrar conjunto actual");
            vista.mostrarInformacion("5. Salir");

            int opcion = vista.leerDatoEntero("Seleccione una opción:");

            switch (opcion) {
                case 1:
                    seleccionarCamisa();
                    break;
                case 2:
                    seleccionarPantalon();
                    break;
                case 3:
                    seleccionarCalzado();
                    break;
                case 4:
                    vista.mostrarInformacion(persona.mostrarConjunto());
                    break;
                case 5:
                    salir = true;
                    vista.mostrarInformacion("Hasta luego.");
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida.");
            }
        }
    }

    private void seleccionarCamisa() {
        vista.mostrarInformacion("1. Camisa formal");
        vista.mostrarInformacion("2. Camisa casual");
        int opcion = vista.leerDatoEntero("Seleccione camisa:");

        switch (opcion) {
            case 1:
                persona.setCamisa(new PrendaCamisaFormal());
                break;
            case 2:
                persona.setCamisa(new PrendaCamisaCasual());
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
        }
    }

    private void seleccionarPantalon() {
        vista.mostrarInformacion("1. Pantalón elegante");
        vista.mostrarInformacion("2. Jeans");
        int opcion = vista.leerDatoEntero("Seleccione pantalón:");

        switch (opcion) {
            case 1:
                persona.setPantalon(new PrendaPantalonElegante());
                break;
            case 2:
                persona.setPantalon(new PrendaPantalonJeans());
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
        }
    }

    private void seleccionarCalzado() {
        vista.mostrarInformacion("1. Zapato formal");
        vista.mostrarInformacion("2. Zapato deportivo");
        int opcion = vista.leerDatoEntero("Seleccione calzado:");

        switch (opcion) {
            case 1:
                persona.setCalzado(new PrendaZapatoFormal());
                break;
            case 2:
                persona.setCalzado(new PrendaZapatoDeportivo());
                break;
            default:
                vista.mostrarInformacion("Opción inválida.");
        }
    }
}
