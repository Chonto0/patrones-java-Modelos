package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.EstrategiaPrenda;

public class PrendaCamisaCasual implements EstrategiaPrenda {
    public String descripcion() {
        return "Camiseta estampada de algodón.";
    }
}
