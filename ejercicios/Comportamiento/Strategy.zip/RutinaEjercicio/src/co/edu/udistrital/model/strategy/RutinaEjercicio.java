package co.edu.udistrital.model.strategy;

public interface RutinaEjercicio {
    String realizarRutina();
}
