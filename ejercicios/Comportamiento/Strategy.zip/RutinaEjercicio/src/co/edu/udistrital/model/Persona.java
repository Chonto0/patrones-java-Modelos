package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.RutinaEjercicio;

public class Persona {
    private String nombre;
    private RutinaEjercicio rutina;

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    public void setRutina(RutinaEjercicio rutina) {
        this.rutina = rutina;
    }

    public String hacerEjercicio() {
        if (rutina == null) {
            return "No se ha seleccionado ninguna rutina aún.";
        }
        return "La persona " + nombre + " realiza su rutina: " + rutina.realizarRutina();
    }
}
