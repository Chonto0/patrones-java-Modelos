package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.RutinaEjercicio;

public class RutinaFlexibilidad implements RutinaEjercicio {

    @Override
    public String realizarRutina() {
        return "Practica 20 minutos de yoga, estiramientos de espalda y piernas.";
    }
}
