package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.RutinaEjercicio;

public class RutinaCardio implements RutinaEjercicio {

    @Override
    public String realizarRutina() {
        return "Realiza 30 minutos de trote, 15 minutos de bicicleta y 10 minutos de cuerda.";
    }
}
