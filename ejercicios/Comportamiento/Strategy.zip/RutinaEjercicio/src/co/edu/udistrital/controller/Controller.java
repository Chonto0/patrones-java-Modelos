package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private Persona persona;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        String nombre = vista.leerCadenaTexto("Ingrese su nombre:");
        persona = new Persona(nombre);

        boolean salir = false;
        while (!salir) {
            vista.mostrarInformacion("\nSeleccione el tipo de rutina de ejercicio:");
            vista.mostrarInformacion("1. Cardio");
            vista.mostrarInformacion("2. Fuerza");
            vista.mostrarInformacion("3. Flexibilidad");
            vista.mostrarInformacion("4. Salir");

            int opcion = vista.leerDatoEntero("Opción:");

            switch (opcion) {
                case 1:
                    persona.setRutina(new RutinaCardio());
                    vista.mostrarInformacion(persona.hacerEjercicio());
                    break;
                case 2:
                    persona.setRutina(new RutinaFuerza());
                    vista.mostrarInformacion(persona.hacerEjercicio());
                    break;
                case 3:
                    persona.setRutina(new RutinaFlexibilidad());
                    vista.mostrarInformacion(persona.hacerEjercicio());
                    break;
                case 4:
                    salir = true;
                    vista.mostrarInformacion("¡Hasta luego! Mantente activo.");
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida. Intente de nuevo.");
            }
        }
    }
}
