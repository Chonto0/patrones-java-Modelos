package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.RutinaEjercicio;

public class RutinaFuerza implements RutinaEjercicio {

    @Override
    public String realizarRutina() {
        return "Haz 4 series de sentadillas, 3 de flexiones y 3 de levantamiento de pesas.";
    }
}
