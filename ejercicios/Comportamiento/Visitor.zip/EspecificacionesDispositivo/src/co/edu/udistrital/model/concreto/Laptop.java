package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ElementoMuseo;
import co.edu.udistrital.model.visitor.Visitor;

public class Laptop implements ElementoMuseo {
	private String marca;
	private String procesador;
	private int ramGB;

	public Laptop(String marca, String procesador, int ramGB) {
		this.marca = marca;
		this.procesador = procesador;
		this.ramGB = ramGB;
	}

	public String getMarca() {
		return marca;
	}

	public String getProcesador() {
		return procesador;
	}

	public int getRamGB() {
		return ramGB;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitLaptop(this);
	}
}
