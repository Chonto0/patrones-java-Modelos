package co.edu.udistrital.model.visitor;

import co.edu.udistrital.model.concreto.*;

public interface Visitor {
    void visitTelefono(Telefono telefono);
    void visitLaptop(Laptop laptop);
    void visitAccesorio(Accesorio accesorio);
}
