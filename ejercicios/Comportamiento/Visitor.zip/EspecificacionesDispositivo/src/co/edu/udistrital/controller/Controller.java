package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.ElementoMuseo;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.model.visitor.*;

public class Controller {

    private VistaConsola vista;
    private List<ElementoMuseo> elementos;

    public Controller() {
        vista = new VistaConsola();
        elementos = new ArrayList<>();

        elementos.add(new Telefono("Samsung", "Galaxy S22", 128));
        elementos.add(new Laptop("Dell", "Intel i7", 16));
        elementos.add(new Accesorio("Cargador", "USB-C rápido"));
    }

    public void run() {
        vista.mostrarInformacion("Especificiones de Dispositivos");

        for (ElementoMuseo elemento : elementos) {
            DescripcionTecnicaVisitor visitor = new DescripcionTecnicaVisitor();
            elemento.aceptar(visitor);
            String descripcion = visitor.getResultado();
            vista.mostrarInformacion(descripcion);
        }
    }
}
