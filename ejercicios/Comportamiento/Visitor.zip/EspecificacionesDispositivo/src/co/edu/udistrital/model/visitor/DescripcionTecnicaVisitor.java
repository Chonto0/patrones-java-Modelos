package co.edu.udistrital.model.visitor;

import co.edu.udistrital.model.concreto.*;

public class DescripcionTecnicaVisitor implements Visitor {

	private String resultado;

	public String getResultado() {
		return resultado;
	}

	@Override
	public void visitTelefono(Telefono telefono) {
		resultado = "Teléfono: " + telefono.getMarca() + " " + telefono.getModelo() + ", Memoria: "
				+ telefono.getMemoriaGB() + "GB";
	}

	@Override
	public void visitLaptop(Laptop laptop) {
		resultado = "Laptop: " + laptop.getMarca() + ", Procesador: " + laptop.getProcesador() + ", RAM: "
				+ laptop.getRamGB() + "GB";
	}

	@Override
	public void visitAccesorio(Accesorio accesorio) {
		resultado = "Accesorio: " + accesorio.getTipo() + ", Descripción: " + accesorio.getDescripcion();
	}
}
