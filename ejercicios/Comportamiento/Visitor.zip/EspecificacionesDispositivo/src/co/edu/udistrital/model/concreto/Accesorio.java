package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ElementoMuseo;
import co.edu.udistrital.model.visitor.Visitor;

public class Accesorio implements ElementoMuseo {
    private String tipo;
    private String descripcion;

    public Accesorio(String tipo, String descripcion) {
        this.tipo = tipo;
        this.descripcion = descripcion;
    }

    public String getTipo() { return tipo; }
    public String getDescripcion() { return descripcion; }

    @Override
    public void aceptar(Visitor visitante) {
    	visitante.visitAccesorio(this);
    }
}
