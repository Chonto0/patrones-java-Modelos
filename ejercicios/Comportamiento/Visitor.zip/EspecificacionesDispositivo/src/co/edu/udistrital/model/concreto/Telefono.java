package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ElementoMuseo;
import co.edu.udistrital.model.visitor.Visitor;

public class Telefono implements ElementoMuseo {
	private String marca;
	private String modelo;
	private int memoriaGB;

	public Telefono(String marca, String modelo, int memoriaGB) {
		this.marca = marca;
		this.modelo = modelo;
		this.memoriaGB = memoriaGB;
	}

	public String getMarca() {
		return marca;
	}

	public String getModelo() {
		return modelo;
	}

	public int getMemoriaGB() {
		return memoriaGB;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitTelefono(this);
	}
}
