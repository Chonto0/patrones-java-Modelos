package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.visitor.Visitor;
import co.edu.udistrital.model.Contenido;

public class Video implements Contenido {
	private String titulo;
	private double duracion;

	public Video(String titulo, double duracion) {
		this.titulo = titulo;
		this.duracion = duracion;
	}

	public String getTitulo() {
		return titulo;
	}

	public double getDuracion() {
		return duracion;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitarVideo(this);
	}
}
