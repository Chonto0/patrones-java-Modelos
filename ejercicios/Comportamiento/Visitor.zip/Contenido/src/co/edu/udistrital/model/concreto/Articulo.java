package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.visitor.Visitor;
import co.edu.udistrital.model.Contenido;

public class Articulo implements Contenido {
	private String titulo;
	private int palabras;

	public Articulo(String titulo, int palabras) {
		this.titulo = titulo;
		this.palabras = palabras;
	}

	public String getTitulo() {
		return titulo;
	}

	public int getPalabras() {
		return palabras;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitarArticulo(this);
	}
}
