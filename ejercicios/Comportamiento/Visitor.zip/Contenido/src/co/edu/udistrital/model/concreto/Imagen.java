package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.visitor.Visitor;
import co.edu.udistrital.model.Contenido;

public class Imagen implements Contenido {
	private String nombreArchivo;
	private int ancho;
	private int alto;

	public Imagen(String nombreArchivo, int ancho, int alto) {
		this.nombreArchivo = nombreArchivo;
		this.ancho = ancho;
		this.alto = alto;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public int getAncho() {
		return ancho;
	}

	public int getAlto() {
		return alto;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitarImagen(this);
	}
}
