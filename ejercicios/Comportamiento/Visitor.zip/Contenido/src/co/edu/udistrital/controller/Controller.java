package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.Contenido;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.model.visitor.EstadisticasVisitor;

public class Controller {

	private VistaConsola vista;
	private List<Contenido> contenidos;

	public Controller() {
		vista = new VistaConsola();
		contenidos = new ArrayList<>();
	}

	public void run() {
		vista.mostrarInformacion("=== Sistema de Gestión de Contenidos ===");

		contenidos.add(new Articulo("Patrón Visitor en Java", 1200));
		contenidos.add(new Video("Tutorial Visitor", 15.5));
		contenidos.add(new Imagen("visitor_diagrama.png", 1024, 768));
		contenidos.add(new Articulo("Diseño de patrones", 800));
		contenidos.add(new Video("Ejemplo real Visitor", 8.0));

		EstadisticasVisitor estadisticas = new EstadisticasVisitor();

		for (Contenido c : contenidos) {
			c.aceptar(estadisticas);
		}

		vista.mostrarInformacion(estadisticas.generarReporte());
	}
}
