package co.edu.udistrital.model.visitor;

import co.edu.udistrital.model.concreto.*;

public class EstadisticasVisitor implements Visitor {

    private int totalPalabras;
    private double totalMinutosVideo;
    private int totalPixelesImagen;

    public EstadisticasVisitor() {
        totalPalabras = 0;
        totalMinutosVideo = 0.0;
        totalPixelesImagen = 0;
    }

    @Override
    public void visitarArticulo(Articulo articulo) {
        totalPalabras += articulo.getPalabras();
    }

    @Override
    public void visitarVideo(Video video) {
        totalMinutosVideo += video.getDuracion();
    }

    @Override
    public void visitarImagen(Imagen imagen) {
        totalPixelesImagen += imagen.getAncho() * imagen.getAlto();
    }

    public String generarReporte() {
        return "ESTADÍSTICAS DE CONTENIDO:\n"
             + "- Total de palabras en artículos: " + totalPalabras + "\n"
             + "- Duración total de videos: " + totalMinutosVideo + " minutos\n"
             + "- Total de pixeles en imágenes: " + totalPixelesImagen + " px²";
    }
}
