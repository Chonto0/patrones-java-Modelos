package co.edu.udistrital.model;

import co.edu.udistrital.model.visitor.Visitor;

public interface ObraDeArte {
    void aceptar(Visitor visitante);
}
