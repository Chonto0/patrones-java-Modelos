package co.edu.udistrital.model.visitor;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.concreto.*;

public class GuiaTuristico implements Visitor {

	private List<String> mensajes;

	public GuiaTuristico() {
		mensajes = new ArrayList<>();
	}

	public List<String> obtenerMensajes() {
		return mensajes;
	}

	@Override
	public void visitarPintura(Pintura pintura) {
		mensajes.add("Pintura: '" + pintura.getTitulo() + "', Autor: " + pintura.getAutor());
	}

	@Override
	public void visitarEscultura(Escultura escultura) {
		mensajes.add("Escultura de " + escultura.getMaterial() + ", Altura: " + escultura.getAltura() + " metros.");
	}

	@Override
	public void visitarArteInteractivo(ArteInteractivo arte) {
		mensajes.add("Instalación interactiva con tecnología: " + arte.getTecnologia());
	}
}
