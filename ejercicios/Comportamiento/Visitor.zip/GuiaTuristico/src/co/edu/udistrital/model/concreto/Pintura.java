package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ObraDeArte;
import co.edu.udistrital.model.visitor.Visitor;

public class Pintura implements ObraDeArte {
    private String titulo;
    private String autor;

    public Pintura(String titulo, String autor) {
        this.titulo = titulo;
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    @Override
    public void aceptar(Visitor visitante) {
    	visitante.visitarPintura(this);
    }
}
