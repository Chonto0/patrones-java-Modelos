package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.ObraDeArte;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.model.visitor.GuiaTuristico;

public class Controller {

	private VistaConsola vista;
	private List<ObraDeArte> obras;

	public Controller() {
		vista = new VistaConsola();
		obras = new ArrayList<>();

		obras.add(new Pintura("La noche estrellada", "Vincent van Gogh"));
		obras.add(new Escultura("Mármol", 5.2));
		obras.add(new ArteInteractivo("Realidad Aumentada"));
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido al Museo Virtual \n");

		GuiaTuristico guia = new GuiaTuristico();

		for (ObraDeArte obra : obras) {
			obra.aceptar(guia);
		}

		for (String mensaje : guia.obtenerMensajes()) {
			vista.mostrarInformacion(mensaje);
		}

		vista.mostrarInformacion("\nFin del recorrido. ¡Gracias por visitar el museo!");
	}
}
