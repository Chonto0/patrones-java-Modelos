package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ObraDeArte;
import co.edu.udistrital.model.visitor.Visitor;

public class Escultura implements ObraDeArte {
    private String material;
    private double altura;

    public Escultura(String material, double altura) {
        this.material = material;
        this.altura = altura;
    }

    public String getMaterial() {
        return material;
    }

    public double getAltura() {
        return altura;
    }

    @Override
    public void aceptar(Visitor visitante) {
    	visitante.visitarEscultura(this);
    }
}
