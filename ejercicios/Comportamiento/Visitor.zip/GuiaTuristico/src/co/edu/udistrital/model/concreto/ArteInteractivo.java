package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ObraDeArte;
import co.edu.udistrital.model.visitor.Visitor;

public class ArteInteractivo implements ObraDeArte {
	private String tecnologia;

	public ArteInteractivo(String tecnologia) {
		this.tecnologia = tecnologia;
	}

	public String getTecnologia() {
		return tecnologia;
	}

	@Override
	public void aceptar(Visitor visitante) {
		visitante.visitarArteInteractivo(this);
	}
}
