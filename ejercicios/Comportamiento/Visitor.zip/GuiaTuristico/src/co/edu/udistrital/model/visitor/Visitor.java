package co.edu.udistrital.model.visitor;

import co.edu.udistrital.model.concreto.*;

public interface Visitor {
    void visitarPintura(Pintura pintura);
    void visitarEscultura(Escultura escultura);
    void visitarArteInteractivo(ArteInteractivo arte);
}
