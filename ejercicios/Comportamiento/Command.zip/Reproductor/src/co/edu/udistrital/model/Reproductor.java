package co.edu.udistrital.model;

import java.util.List;

public class Reproductor {
    private List<String> pistas = List.of("Pista 1", "Pista 2", "Pista 3", "Pista 4");
    private int indiceActual = 0;

    public String play() {
        return "Reproduciendo: " + pistas.get(indiceActual);
    }

    public String pause() {
        return "Pausando reproducción: " + pistas.get(indiceActual);
    }

    public String stop() {
        return "Deteniendo reproducción.";
    }

    public String nextTrack() {
        indiceActual = (indiceActual + 1) % pistas.size();
        return "Pasando a la siguiente pista: " + pistas.get(indiceActual);
    }

    public String getPistaActual() {
        return pistas.get(indiceActual);
    }
}
