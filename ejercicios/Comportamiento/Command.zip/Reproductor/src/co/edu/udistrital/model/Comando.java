package co.edu.udistrital.model;

public interface Comando {
    String ejecutar(); 
}
