// Invoker.java
package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class Invoker {

    private Map<Integer, Comando> comandos;

    public Invoker() {
        comandos = new HashMap<>();
    }

    public void registrarComando(int opcion, Comando comando) {
        comandos.put(opcion, comando);
    }

    public String ejecutar(int opcion) {
        Comando comando = comandos.get(opcion);
        return (comando != null) ? comando.ejecutar() : "Comando no válido.";
    }
}
