package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Reproductor;

public class PlayCommand implements Comando {
    private Reproductor reproductor;

    public PlayCommand(Reproductor reproductor) {
        this.reproductor = reproductor;
    }

    public String ejecutar() {
        return reproductor.play();
    }
}
