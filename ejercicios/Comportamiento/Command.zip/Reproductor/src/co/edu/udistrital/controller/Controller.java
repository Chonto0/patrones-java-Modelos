// Controller.java
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Invoker;
import co.edu.udistrital.model.Reproductor;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private Reproductor reproductor;
	private Invoker invoker;

	public Controller() {
		vista = new VistaConsola();
		reproductor = new Reproductor();
		invoker = new Invoker();

		invoker.registrarComando(1, new PlayCommand(reproductor));
		invoker.registrarComando(2, new PauseCommand(reproductor));
		invoker.registrarComando(3, new StopCommand(reproductor));
		invoker.registrarComando(4, new NextTrackCommand(reproductor));
	}

	public void run() {
		int opcion;

		do {
			vista.mostrarInformacion("\n--- REPRODUCTOR ---");
			vista.mostrarInformacion("Pista actual: " + reproductor.getPistaActual());
			vista.mostrarInformacion("1. Reproducir");
			vista.mostrarInformacion("2. Pausar");
			vista.mostrarInformacion("3. Detener");
			vista.mostrarInformacion("4. Siguiente pista");
			vista.mostrarInformacion("0. Salir");

			opcion = vista.leerDatoEntero("Seleccione una opción:");

			if (opcion == 0) {
				vista.mostrarInformacion("Saliendo del reproductor...");
				break;
			}

			String resultado = invoker.ejecutar(opcion);
			vista.mostrarInformacion(resultado);

		} while (opcion != 0);
	}
}
