package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Reproductor;

public class StopCommand implements Comando {
    private Reproductor reproductor;

    public StopCommand(Reproductor reproductor) {
        this.reproductor = reproductor;
    }

    public String ejecutar() {
        return reproductor.stop();
    }
}
