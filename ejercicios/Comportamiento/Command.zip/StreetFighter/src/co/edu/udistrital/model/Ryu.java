package co.edu.udistrital.model;

public class Ryu {

    public String hadouken() {
        return "Ryu lanza un ¡Hadouken!";
    }

    public String shoryuken() {
        return "Ryu ejecuta un ¡Shoryuken!";
    }

    public String bloquear() {
        return "Ryu se pone en posición de ¡Bloqueo!";
    }

    public String patada() {
        return "Ryu lanza una ¡Patada fuerte!";
    }

    public String punio() {
        return "Ryu lanza un ¡Puño rápido!";
    }
}
