// Controller.java
package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private Ryu ryu;
	private Invoker invoker;

	public Controller() {
		this.vista = new VistaConsola();
		this.ryu = new Ryu();
		this.invoker = new Invoker();

		registrarComandos();
	}

	private void registrarComandos() {
		invoker.registrarComando(1, new HadoukenCommand(ryu));
		invoker.registrarComando(2, new ShoryukenCommand(ryu));
		invoker.registrarComando(3, new BloquearCommand(ryu));
		invoker.registrarComando(4, new PatadaCommand(ryu));
		invoker.registrarComando(5, new PunioCommand(ryu));
	}

	public void run() {
		vista.mostrarInformacion("== STREET FIGHTER: CONTROL DE RYU ==");

		boolean salir = false;
		while (!salir) {
			vista.mostrarInformacion("\nComandos disponibles:");
			vista.mostrarInformacion("1. Hadouken");
			vista.mostrarInformacion("2. Shoryuken");
			vista.mostrarInformacion("3. Bloquear");
			vista.mostrarInformacion("4. Patada");
			vista.mostrarInformacion("5. Puño");
			vista.mostrarInformacion("6. Repetir último comando");
			vista.mostrarInformacion("0. Salir");

			int opcion = vista.leerDatoEntero("Selecciona un comando:");

			switch (opcion) {
			case 0:
				vista.mostrarInformacion("¡Fin del combate!");
				salir = true;
				break;
			case 6:
				vista.mostrarInformacion(invoker.repetirUltimoComando());
				break;
			default:
				vista.mostrarInformacion(invoker.ejecutar(opcion));
				break;
			}
		}
	}
}
