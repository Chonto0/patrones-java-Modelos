package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Ryu;

public class BloquearCommand implements Comando {
    private Ryu ryu;

    public BloquearCommand(Ryu ryu) {
        this.ryu = ryu;
    }

    public String ejecutar() {
        return ryu.bloquear();
    }
}
