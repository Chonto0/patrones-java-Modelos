// Invoker.java
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Invoker {

    private Map<Integer, Comando> comandos = new HashMap<>();
    private List<Comando> historial = new ArrayList<>();

    public void registrarComando(int opcion, Comando comando) {
        comandos.put(opcion, comando);
    }

    public String ejecutar(int opcion) {
        Comando comando = comandos.get(opcion);
        if (comando != null) {
            historial.add(comando);
            return comando.ejecutar();
        } else {
            return "Comando inválido.";
        }
    }

    public String repetirUltimoComando() {
        if (!historial.isEmpty()) {
            Comando ultimo = historial.get(historial.size() - 1);
            return ultimo.ejecutar();
        } else {
            return "No hay comando anterior para repetir.";
        }
    }
}
