package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Ryu;

public class ShoryukenCommand implements Comando {
    private Ryu ryu;

    public ShoryukenCommand(Ryu ryu) {
        this.ryu = ryu;
    }

    public String ejecutar() {
        return ryu.shoryuken();
    }
}
