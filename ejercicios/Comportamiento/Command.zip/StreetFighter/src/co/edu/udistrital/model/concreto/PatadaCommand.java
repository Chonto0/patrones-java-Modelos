package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Ryu;

public class PatadaCommand implements Comando {
    private Ryu ryu;

    public PatadaCommand(Ryu ryu) {
        this.ryu = ryu;
    }

    public String ejecutar() {
        return ryu.patada();
    }
}
