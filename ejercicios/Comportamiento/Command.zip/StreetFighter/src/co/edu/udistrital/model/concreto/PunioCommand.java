package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Ryu;

public class PunioCommand implements Comando {
    private Ryu ryu;

    public PunioCommand(Ryu ryu) {
        this.ryu = ryu;
    }

    public String ejecutar() {
        return ryu.punio();
    }
}
