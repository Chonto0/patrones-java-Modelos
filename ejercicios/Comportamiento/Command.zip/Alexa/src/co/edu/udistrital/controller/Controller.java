package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private Alexa alexa;

    public Controller() {
        vista = new VistaConsola();
        alexa = new Alexa();
    }

    public void run() {
        boolean salir = false;
        while (!salir) {
            int opcion = vista.leerDatoEntero(
                "\n=== ALEXA ===\n1. Encender luz\n2. Reproducir música\n3. Decir hora\n0. Salir\nElige una opción:");

            Comando comando = null;

            switch (opcion) {
                case 1:
                    comando = new ComandoEncenderLuz(alexa);
                    break;
                case 2:
                    comando = new ComandoReproducirMusica(alexa);
                    break;
                case 3:
                    comando = new ComandoDecirHora(alexa);
                    break;
                case 0:
                    salir = true;
                    vista.mostrarInformacion("Cerrando Alexa. ¡Hasta luego!");
                    continue;
                default:
                    vista.mostrarInformacion("Opción no válida.");
                    continue;
            }


            Invoker invoker = new Invoker(comando);
            String resultado = invoker.ejecutar();

            vista.mostrarInformacion(resultado);
        }
    }
}
