package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Alexa;
import co.edu.udistrital.model.Comando;

public class ComandoReproducirMusica implements Comando {
    private Alexa alexa;

    public ComandoReproducirMusica(Alexa alexa) {
        this.alexa = alexa;
    }

    @Override
    public String ejecutar() {
        return alexa.reproducirMusica();
    }
}
