package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Comando;
import co.edu.udistrital.model.Alexa;

public class ComandoDecirHora implements Comando {
	private Alexa alexa;

	public ComandoDecirHora(Alexa alexa) {
		this.alexa = alexa;
	}

	@Override
	public String ejecutar() {
		return alexa.decirHora();
	}
}
