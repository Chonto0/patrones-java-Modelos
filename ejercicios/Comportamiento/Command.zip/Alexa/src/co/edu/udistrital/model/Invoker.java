package co.edu.udistrital.model;

public class Invoker {
    private Comando comando;

    public Invoker(Comando comando) {
        this.comando = comando;
    }

    public String ejecutar() {
        return comando.ejecutar();
    }
}
