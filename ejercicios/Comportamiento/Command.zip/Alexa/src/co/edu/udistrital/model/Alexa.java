package co.edu.udistrital.model;

import java.time.LocalTime;

public class Alexa {

    public String encenderLuz() {
        return "Alexa: Las luces han sido encendidas.";
    }

    public String reproducirMusica() {
        return "Alexa: Reproduciendo tu lista de música favorita.";
    }

    public String decirHora() {
        LocalTime hora = LocalTime.now();
        return "Alexa: La hora actual es " + hora.getHour() + ":" + String.format("%02d", hora.getMinute());
    }
}
