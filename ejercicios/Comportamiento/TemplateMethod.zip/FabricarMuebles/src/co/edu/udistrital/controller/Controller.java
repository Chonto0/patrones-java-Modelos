package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.FabricarMueble;
import co.edu.udistrital.model.concreto.FabricarMesa;
import co.edu.udistrital.model.concreto.FabricarSilla;

import java.util.List;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido a la fábrica de muebles.");
		int opcion = vista.leerDatoEntero("Seleccione el mueble a fabricar:\n1. Silla\n2. Mesa");

		FabricarMueble mueble;

		switch (opcion) {
		case 1:
			mueble = new FabricarSilla();
			vista.mostrarInformacion("Fabricando silla...");
			break;
		case 2:
			mueble = new FabricarMesa();
			vista.mostrarInformacion("Fabricando mesa...");
			break;
		default:
			vista.mostrarInformacion("Opción inválida. Saliendo del programa.");
			return;
		}

		List<String> pasos = mueble.fabricar();
		for (String paso : pasos) {
			vista.mostrarInformacion(paso);
		}
	}
}
