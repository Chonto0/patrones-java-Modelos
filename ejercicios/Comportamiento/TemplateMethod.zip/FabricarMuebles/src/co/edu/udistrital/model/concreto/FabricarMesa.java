package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.FabricarMueble;

public class FabricarMesa extends FabricarMueble {

	@Override
	protected void cortarMadera() {
		registrarPaso("Cortando madera para la mesa...");
	}

	@Override
	protected void ensamblar() {
		registrarPaso("Ensamblando la mesa...");
	}

	@Override
	protected void lijar() {
		registrarPaso("Lijando la superficie de la mesa...");
	}

	@Override
	protected void pintar() {
		registrarPaso("Pintando la mesa con pintura mate.");
	}
}
