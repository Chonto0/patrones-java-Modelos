package co.edu.udistrital.model;

import java.util.List;

public abstract class FabricarMueble {

	protected StringBuilder log;

	public FabricarMueble() {
		log = new StringBuilder();
	}

	public final List<String> fabricar() {
		cortarMadera();
		ensamblar();
		lijar();
		pintar();
		return List.of(log.toString().split("\n"));
	}

	protected void registrarPaso(String mensaje) {
		log.append(mensaje).append("\n");
	}

	protected abstract void cortarMadera();

	protected abstract void ensamblar();

	protected abstract void lijar();

	protected abstract void pintar();
}
