package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;

import java.util.List;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("Bienvenido al sistema de cocina.");
        vista.mostrarInformacion("Seleccione una receta:\n1. Pasta\n2. Pizza");

        int opcion = vista.leerDatoEntero("Ingrese su elección:");

        RecetaCocina receta = null;

        switch (opcion) {
            case 1:
                receta = new HacerPasta();
                break;
            case 2:
                receta = new HacerPizza();
                break;
            default:
                vista.mostrarInformacion("Opción no válida.");
                return;
        }

        List<String> pasos = receta.prepararReceta();
        vista.mostrarInformacion("Preparando receta seleccionada...\n");

        for (String paso : pasos) {
            vista.mostrarInformacion(paso);
        }
    }
}
