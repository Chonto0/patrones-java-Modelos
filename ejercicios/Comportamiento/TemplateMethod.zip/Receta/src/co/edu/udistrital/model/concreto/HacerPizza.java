package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.RecetaCocina;

import java.util.Arrays;

public class HacerPizza extends RecetaCocina {

    @Override
    protected List<String> prepararIngredientes() {
        return Arrays.asList("Preparando masa, salsa de tomate, queso y pepperoni.");
    }

    @Override
    protected List<String> cocinar() {
        return Arrays.asList("Horneando la pizza durante 20 minutos.");
    }

    @Override
    protected List<String> decorar() {
        return Arrays.asList("Añadiendo orégano y un chorrito de aceite de oliva.");
    }

    @Override
    protected List<String> servir() {
        return Arrays.asList("Sirviendo la pizza cortada en porciones.");
    }
}
