package co.edu.udistrital.model.concreto;

import java.util.List;

import co.edu.udistrital.model.RecetaCocina;

import java.util.Arrays;

public class HacerPasta extends RecetaCocina {

    @Override
    protected List<String> prepararIngredientes() {
        return Arrays.asList("Preparando pasta, salsa de tomate, ajo y queso.");
    }

    @Override
    protected List<String> cocinar() {
        return Arrays.asList("Cocinando la pasta en agua hirviendo y preparando la salsa.");
    }

    @Override
    protected List<String> decorar() {
        return Arrays.asList("Decorando con hojas de albahaca y queso rallado.");
    }

    @Override
    protected List<String> servir() {
        return Arrays.asList("Sirviendo la pasta caliente en un plato hondo.");
    }
}
