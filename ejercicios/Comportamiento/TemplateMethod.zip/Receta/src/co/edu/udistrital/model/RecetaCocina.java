package co.edu.udistrital.model;

import java.util.List;

public abstract class RecetaCocina {

    public final List<String> prepararReceta() {
        List<String> pasos = new java.util.ArrayList<>();
        pasos.addAll(prepararIngredientes());
        pasos.addAll(cocinar());
        pasos.addAll(decorar());
        pasos.addAll(servir());
        return pasos;
    }

    protected abstract List<String> prepararIngredientes();
    protected abstract List<String> cocinar();
    protected abstract List<String> decorar();
    protected abstract List<String> servir();
}
