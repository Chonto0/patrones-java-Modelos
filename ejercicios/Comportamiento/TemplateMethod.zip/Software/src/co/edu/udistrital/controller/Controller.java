package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("Bienvenido al asistente de instalación.");
        vista.mostrarInformacion("1. Instalar Windows");
        vista.mostrarInformacion("2. Instalar Linux");

        int opcion = vista.leerDatoEntero("Seleccione una opción:");

        InstalarSoftware instalador = null;

        switch (opcion) {
            case 1:
                String version = vista.leerCadenaTexto("Ingrese versión de Windows a instalar (Home / Pro):");
                instalador = new InstalarWindows(version);
                break;

            case 2:
                String distro = vista.leerCadenaTexto("¿Qué distribución desea instalar? (Ubuntu / Fedora / Debian):");
                boolean experto = vista.leerDatoEntero("¿Modo experto? (1. Sí / 2. No):") == 1;
                instalador = new InstalarLinux(distro, experto);
                break;

            default:
                vista.mostrarInformacion("Opción no válida.");
                return;
        }

        String[] pasos = instalador.instalar();

        for (String paso : pasos) {
            vista.mostrarInformacion(paso);
        }

        vista.mostrarInformacion("\n Instalación finalizada.");
    }
}
