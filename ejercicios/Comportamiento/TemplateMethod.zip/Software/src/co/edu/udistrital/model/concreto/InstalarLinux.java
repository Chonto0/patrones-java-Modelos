package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.InstalarSoftware;

public class InstalarLinux extends InstalarSoftware {

	private String distro;
	private boolean modoExperto;

	public InstalarLinux(String distro, boolean modoExperto) {
		this.distro = distro;
		this.modoExperto = modoExperto;
	}

	@Override
	protected boolean verificarCompatibilidad() {
		return true;
	}

	@Override
	protected void prepararEntorno() {
		if (modoExperto) {

		}
	}

	@Override
	protected String descargar() {
		return "Descargando " + distro + " LTS...";
	}

	@Override
	protected String ejecutarInstalador() {
		return "Arrancando entorno gráfico de instalación de " + distro + "...";
	}

	@Override
	protected String configurar() {
		return modoExperto ? "Configuración avanzada activada. Personalizando particiones..."
				: "Configuración automática aplicada.";
	}

	@Override
	protected String finalizar() {
		return "Distribución " + distro + " instalada correctamente.";
	}
}
