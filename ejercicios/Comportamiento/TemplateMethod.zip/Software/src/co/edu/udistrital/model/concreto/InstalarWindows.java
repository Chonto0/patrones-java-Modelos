package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.InstalarSoftware;

public class InstalarWindows extends InstalarSoftware {

	private String version;

	public InstalarWindows(String version) {
		this.version = version;
	}

	@Override
	protected boolean verificarCompatibilidad() {
		return true;
	}

	@Override
	protected String descargar() {
		return "Descargando instalador de Windows " + version + "...";
	}

	@Override
	protected String ejecutarInstalador() {
		return "Ejecutando instalador de Windows " + version + "...";
	}

	@Override
	protected String configurar() {
		return "Configurando idioma, región y disco de instalación...";
	}

	@Override
	protected String finalizar() {
		return "Windows " + version + " instalado correctamente.";
	}
}
