package co.edu.udistrital.model;

public abstract class InstalarSoftware {

	public final String[] instalar() {
		if (!verificarCompatibilidad()) {
			return new String[] { "El sistema no es compatible con esta instalación." };
		}

		prepararEntorno();

		if (!validarConexion()) {
			return new String[] { "No se pudo establecer conexión a Internet." };
		}

		return new String[] { descargar(), ejecutarInstalador(), configurar(), finalizar() };
	}

	protected void prepararEntorno() {

	}

	protected boolean validarConexion() {
		return true;
	}

	protected abstract boolean verificarCompatibilidad();

	protected abstract String descargar();

	protected abstract String ejecutarInstalador();

	protected abstract String configurar();

	protected abstract String finalizar();
}
