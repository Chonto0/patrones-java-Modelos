package co.edu.udistrital.model;

public interface ControlRemotoMediator {
    String encenderDispositivo(String nombre);
    String apagarDispositivo(String nombre);
}
