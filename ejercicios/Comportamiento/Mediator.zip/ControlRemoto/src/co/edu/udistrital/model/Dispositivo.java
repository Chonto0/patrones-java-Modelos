package co.edu.udistrital.model;

public abstract class Dispositivo {
    protected String nombre;

    public Dispositivo(String nombre) {
        this.nombre = nombre;
    }

    public abstract String encender();
    public abstract String apagar();
}
