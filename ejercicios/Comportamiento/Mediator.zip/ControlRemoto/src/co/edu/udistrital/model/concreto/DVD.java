package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Dispositivo;

public class DVD extends Dispositivo {

    public DVD() {
        super("DVD");
    }

    @Override
    public String encender() {
        return "DVD encendido.";
    }

    @Override
    public String apagar() {
        return "DVD apagado.";
    }
}
