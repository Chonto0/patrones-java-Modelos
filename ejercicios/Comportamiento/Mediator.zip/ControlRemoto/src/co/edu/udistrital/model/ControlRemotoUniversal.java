package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class ControlRemotoUniversal implements ControlRemotoMediator {

    private Map<String, Dispositivo> dispositivos = new HashMap<>();

    public void registrarDispositivo(Dispositivo dispositivo) {
        dispositivos.put(dispositivo.nombre.toLowerCase(), dispositivo);
    }

    @Override
    public String encenderDispositivo(String nombre) {
        Dispositivo d = dispositivos.get(nombre.toLowerCase());
        if (d != null) {
            return d.encender();
        } else {
            return "Dispositivo no encontrado.";
        }
    }

    @Override
    public String apagarDispositivo(String nombre) {
        Dispositivo d = dispositivos.get(nombre.toLowerCase());
        if (d != null) {
            return d.apagar();
        } else {
            return "Dispositivo no encontrado.";
        }
    }
}
