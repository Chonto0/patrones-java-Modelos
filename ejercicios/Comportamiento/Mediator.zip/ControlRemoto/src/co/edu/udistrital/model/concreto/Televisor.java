package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Dispositivo;

public class Televisor extends Dispositivo {

    public Televisor() {
        super("Televisor");
    }

    @Override
    public String encender() {
        return "Televisor encendido.";
    }

    @Override
    public String apagar() {
        return "Televisor apagado.";
    }
}
