package co.edu.udistrital.controller;

import java.util.HashMap;
import java.util.Map;

import co.edu.udistrital.model.ControlRemotoUniversal;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private ControlRemotoUniversal controlRemoto;
    private Map<Integer, String> dispositivos;

    public Controller() {
        vista = new VistaConsola();
        controlRemoto = new ControlRemotoUniversal();
        dispositivos = new HashMap<>();

        controlRemoto.registrarDispositivo(new Televisor());
        dispositivos.put(1, "Televisor");

        controlRemoto.registrarDispositivo(new DVD());
        dispositivos.put(2, "DVD");

        controlRemoto.registrarDispositivo(new EquipoSonido());
        dispositivos.put(3, "Equipo de Sonido");
    }

    public void run() {
        int opcion;
        do {
            vista.mostrarInformacion("\n--- CONTROL REMOTO UNIVERSAL ---");
            vista.mostrarInformacion("1. Encender dispositivo");
            vista.mostrarInformacion("2. Apagar dispositivo");
            vista.mostrarInformacion("0. Salir");

            opcion = vista.leerDatoEntero("Seleccione una opción:");

            switch (opcion) {
                case 1 -> {
                    String nombre = seleccionarDispositivo();
                    if (nombre != null) {
                        String resultado = controlRemoto.encenderDispositivo(nombre);
                        vista.mostrarInformacion(resultado);
                    }
                }
                case 2 -> {
                    String nombre = seleccionarDispositivo();
                    if (nombre != null) {
                        String resultado = controlRemoto.apagarDispositivo(nombre);
                        vista.mostrarInformacion(resultado);
                    }
                }
                case 0 -> vista.mostrarInformacion("Saliendo del programa...");
                default -> vista.mostrarInformacion("Opción no válida.");
            }
        } while (opcion != 0);
    }

    private String seleccionarDispositivo() {
        vista.mostrarInformacion("\nSeleccione un dispositivo:");
        for (Map.Entry<Integer, String> entry : dispositivos.entrySet()) {
            vista.mostrarInformacion(entry.getKey() + ". " + entry.getValue());
        }

        int seleccion = vista.leerDatoEntero("Ingrese número del dispositivo:");
        String nombre = dispositivos.get(seleccion);

        if (nombre == null) {
            vista.mostrarInformacion("Dispositivo no válido.");
        }

        return nombre;
    }
}
