package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Dispositivo;

public class EquipoSonido extends Dispositivo {

    public EquipoSonido() {
        super("Equipo de Sonido");
    }

    @Override
    public String encender() {
        return "Equipo de sonido encendido.";
    }

    @Override
    public String apagar() {
        return "Equipo de sonido apagado.";
    }
}
