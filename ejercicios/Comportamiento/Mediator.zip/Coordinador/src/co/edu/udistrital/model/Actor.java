package co.edu.udistrital.model;

public abstract class Actor {
    protected CoordinadorMediator mediador;
    protected String nombre;

    public Actor(CoordinadorMediator mediador, String nombre) {
        this.mediador = mediador;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public abstract void enviar(String mensaje);
    public abstract void recibir(String mensaje);
}
