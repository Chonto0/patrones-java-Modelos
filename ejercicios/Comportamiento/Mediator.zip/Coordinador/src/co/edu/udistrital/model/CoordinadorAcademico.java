package co.edu.udistrital.model;

import co.edu.udistrital.model.concreto.*;

public class CoordinadorAcademico implements CoordinadorMediator {

	private Estudiante estudiante;
	private Profesor profesor;
	private Directiva directiva;

	public void registrarEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}

	public void registrarProfesor(Profesor profesor) {
		this.profesor = profesor;
	}

	public void registrarDirectiva(Directiva directiva) {
		this.directiva = directiva;
	}

	@Override
	public void enviarMensaje(Actor emisor, String mensaje) {
		if (emisor instanceof Estudiante) {
			profesor.recibir("Estudiante " + emisor.getNombre() + " dice: " + mensaje);
		} else if (emisor instanceof Profesor) {
			directiva.recibir("Profesor " + emisor.getNombre() + " informa: " + mensaje);
		} else if (emisor instanceof Directiva) {
			estudiante.recibir("Directiva responde: " + mensaje);
		}
	}

	public void mensajeDesdeEstudiante(String mensaje) {
		estudiante.enviar(mensaje);
	}

	public void mensajeDesdeProfesor(String mensaje) {
		profesor.enviar(mensaje);
	}

	public void mensajeDesdeDirectiva(String mensaje) {
		directiva.enviar(mensaje);
	}

	public String obtenerRespuestaParaProfesor() {
		return profesor.obtenerMensajeRecibido();
	}

	public String obtenerRespuestaParaDirectiva() {
		return directiva.obtenerMensajeRecibido();
	}

	public String obtenerRespuestaParaEstudiante() {
		return estudiante.obtenerMensajeRecibido();
	}
}
