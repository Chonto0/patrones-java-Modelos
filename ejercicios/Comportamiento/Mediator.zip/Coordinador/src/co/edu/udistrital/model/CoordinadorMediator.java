package co.edu.udistrital.model;

public interface CoordinadorMediator {
    void enviarMensaje(Actor emisor, String mensaje);
}
