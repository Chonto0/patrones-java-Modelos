package co.edu.udistrital.controller;

import co.edu.udistrital.model.CoordinadorAcademico;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private CoordinadorAcademico coordinador;

	public Controller() {
		vista = new VistaConsola();
		coordinador = new CoordinadorAcademico();

		// Registro interno en el mediador
		coordinador.registrarEstudiante(new Estudiante(coordinador, "Luis"));
		coordinador.registrarProfesor(new Profesor(coordinador, "Dra. Martínez"));
		coordinador.registrarDirectiva(new Directiva(coordinador, "Decano Rodríguez"));
	}

	public void run() {
		int opcion;
		do {
			vista.mostrarInformacion("\n--- MENÚ COORDINADOR ACADÉMICO ---");
			vista.mostrarInformacion("1. Estudiante envía solicitud");
			vista.mostrarInformacion("2. Profesor reporta conflicto");
			vista.mostrarInformacion("3. Directiva responde");
			vista.mostrarInformacion("0. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción:");

			switch (opcion) {
			case 1:
				String mensajeE = vista.leerCadenaTexto("Mensaje del estudiante:");
				coordinador.mensajeDesdeEstudiante(mensajeE);
				vista.mostrarInformacion(coordinador.obtenerRespuestaParaProfesor());
				break;
			case 2:
				String mensajeP = vista.leerCadenaTexto("Mensaje del profesor:");
				coordinador.mensajeDesdeProfesor(mensajeP);
				vista.mostrarInformacion(coordinador.obtenerRespuestaParaDirectiva());
				break;
			case 3:
				String mensajeD = vista.leerCadenaTexto("Mensaje de la directiva:");
				coordinador.mensajeDesdeDirectiva(mensajeD);
				vista.mostrarInformacion(coordinador.obtenerRespuestaParaEstudiante());
				break;
			case 0:
				vista.mostrarInformacion("Saliendo del sistema.");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}

		} while (opcion != 0);
	}
}
