package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Actor;
import co.edu.udistrital.model.CoordinadorMediator;

public class Estudiante extends Actor {

    private String mensajeRecibido;

    public Estudiante(CoordinadorMediator mediador, String nombre) {
        super(mediador, nombre);
    }

    @Override
    public void enviar(String mensaje) {
        mediador.enviarMensaje(this, mensaje);
    }

    @Override
    public void recibir(String mensaje) {
        this.mensajeRecibido = mensaje;
    }

    public String obtenerMensajeRecibido() {
        return mensajeRecibido;
    }
}
