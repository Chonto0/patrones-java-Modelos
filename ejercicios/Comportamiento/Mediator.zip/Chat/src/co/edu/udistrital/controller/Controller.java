package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.*;

import java.util.List;

public class Controller {

	private VistaConsola vista;
	private ServidorDeChat servidor;

	public Controller() {
		vista = new VistaConsola();
		servidor = new ServidorDeChat();
	}

	public void run() {
		vista.mostrarInformacion("=== Chatico ===");

		Persona persona1 = new Persona(vista.leerCadenaTexto("Ingrese nombre de la persona 1:"), servidor);
		Persona persona2 = new Persona(vista.leerCadenaTexto("Ingrese nombre de la persona 2:"), servidor);

		boolean salir = false;
		while (!salir) {
			vista.mostrarInformacion("\n1. " + persona1.getNombre() + " envía mensaje");
			vista.mostrarInformacion("2. " + persona2.getNombre() + " envía mensaje");
			vista.mostrarInformacion("3. Salir");

			int opcion = vista.leerDatoEntero("Seleccione una opción:");

			switch (opcion) {
			case 1:
				manejarMensaje(persona1);
				break;
			case 2:
				manejarMensaje(persona2);
				break;
			case 3:
				salir = true;
				vista.mostrarInformacion("Saliendo del servidor...");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}
		}
	}

	private void manejarMensaje(Persona persona) {
		String texto = vista.leerCadenaTexto("Mensaje de " + persona.getNombre() + ":");
		String emitido = persona.enviar(texto);
		vista.mostrarInformacion(emitido);

		List<String> respuestas = servidor.enviar(persona.getNombre() + ": " + texto, persona);
		for (String respuesta : respuestas) {
			vista.mostrarInformacion(respuesta);
		}
	}
}
