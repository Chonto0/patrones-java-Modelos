package co.edu.udistrital.model;

public class Persona {

	private String nombre;
	private Mediador servidor;

	public Persona(String nombre, Mediador servidor) {
		this.nombre = nombre;
		this.servidor = servidor;
		servidor.registrarPersona(this);
	}

	public String getNombre() {
		return nombre;
	}

	public String enviar(String mensaje) {
		return nombre + " dice: " + mensaje;
	}

	public String recibir(String mensaje) {
		return "[" + nombre + " recibe mensaje] " + mensaje;
	}
}
