package co.edu.udistrital.model;

import java.util.List;

public interface Mediador {
	List<String> enviar(String mensaje, Persona remitente);

	void registrarPersona(Persona persona);
}
