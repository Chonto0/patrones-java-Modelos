package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class ServidorDeChat implements Mediador {

	private List<Persona> personas;

	public ServidorDeChat() {
		personas = new ArrayList<>();
	}

	@Override
	public List<String> enviar(String mensaje, Persona remitente) {
		List<String> respuestas = new ArrayList<>();
		for (Persona persona : personas) {
			if (!persona.equals(remitente)) {
				respuestas.add(persona.recibir(mensaje));
			}
		}
		return respuestas;
	}

	@Override
	public void registrarPersona(Persona persona) {
		if (!personas.contains(persona)) {
			personas.add(persona);
		}
	}
}
