package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Autenticacion;
import co.edu.udistrital.model.Estado;

public class EstadoNoAutenticado implements Estado {

	@Override
	public boolean requiereCredenciales() {
		return true;
	}

	@Override
	public String manejar(Autenticacion contexto, String usuario, String contrasena) {
		if (contexto.getUsuario().getNombreUsuario().equals(usuario)
				&& contexto.getUsuario().verificarContrasena(contrasena)) {
			contexto.setEstado(new EstadoAutenticado());
			return "Autenticación exitosa.";
		} else {
			contexto.incrementarIntentosFallidos();
			if (contexto.getIntentosFallidos() >= 3) {
				contexto.setEstado(new EstadoBloqueado());
				return "Demasiados intentos fallidos. Usuario bloqueado.";
			}
			return "Credenciales incorrectas. Intento " + contexto.getIntentosFallidos() + " de 3.";
		}
	}
}
