package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Autenticacion;
import co.edu.udistrital.model.Estado;

public class EstadoBloqueado implements Estado {

    @Override
    public boolean requiereCredenciales() {
        return false;
    }

    @Override
    public String manejar(Autenticacion contexto, String usuario, String contrasena) {
        return "El usuario está bloqueado. No se permiten más intentos.";
    }
}
