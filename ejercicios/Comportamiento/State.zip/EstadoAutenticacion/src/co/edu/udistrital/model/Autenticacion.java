package co.edu.udistrital.model;

import co.edu.udistrital.model.concreto.EstadoNoAutenticado;

public class Autenticacion {

	private Estado estadoActual;
	private Usuario usuario;
	private int intentosFallidos;

	public Autenticacion() {
		this.estadoActual = new EstadoNoAutenticado();
		this.intentosFallidos = 0;
	}

	public String manejar(String nombreUsuario, String contrasena) {
		return estadoActual.manejar(this, nombreUsuario, contrasena);
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public int getIntentosFallidos() {
		return intentosFallidos;
	}

	public Estado getEstadoActual() {
		return estadoActual;
	}

	public void incrementarIntentosFallidos() {
		intentosFallidos++;
	}

	public void setEstado(Estado nuevoEstado) {
		this.estadoActual = nuevoEstado;
		if (nuevoEstado instanceof EstadoNoAutenticado) {
			intentosFallidos = 0;
		}
	}
}
