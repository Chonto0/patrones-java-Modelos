package co.edu.udistrital.model;

public interface Estado {
    boolean requiereCredenciales();  
    String manejar(Autenticacion contexto, String usuario, String contrasena);
}
