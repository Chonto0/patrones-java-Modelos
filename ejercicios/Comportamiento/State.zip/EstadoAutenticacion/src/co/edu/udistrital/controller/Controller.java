package co.edu.udistrital.controller;

import co.edu.udistrital.model.Autenticacion;
import co.edu.udistrital.model.Usuario;
import co.edu.udistrital.model.concreto.EstadoNoAutenticado;
import co.edu.udistrital.view.VistaConsola;

import java.util.HashMap;
import java.util.Map;

public class Controller {

	private VistaConsola vista;
	private Autenticacion contexto;
	private Map<String, Usuario> usuarios;

	public Controller() {
		vista = new VistaConsola();

		usuarios = new HashMap<>();
		usuarios.put("admin", new Usuario("admin", "1234"));
		usuarios.put("user", new Usuario("user", "abcd"));

		contexto = new Autenticacion();
	}

	public void run() {
		int opcion;
		do {
			opcion = vista.leerDatoEntero("""
						1. Iniciar sesión
						2. Salir
						3. Cerrar sesión
					""");

			switch (opcion) {
			case 1 -> {
				String nombreUsuario = "", contrasena = "";

				if (contexto.getEstadoActual().requiereCredenciales()) {
					nombreUsuario = vista.leerCadenaTexto("Nombre de usuario:");
					contrasena = vista.leerCadenaTexto("Contraseña:");

					Usuario usuario = usuarios.get(nombreUsuario);
					if (usuario == null) {
						vista.mostrarInformacion("El usuario no existe.");
						break;
					} else {
						contexto.setUsuario(usuario);
					}
				}

				String resultado = contexto.manejar(nombreUsuario, contrasena);
				vista.mostrarInformacion(resultado);
			}

			case 2 -> vista.mostrarInformacion("Saliendo del sistema...");
			case 3 -> {
				contexto.setEstado(new EstadoNoAutenticado());
				vista.mostrarInformacion("Sesión cerrada. Estado reiniciado.");
			}
			default -> vista.mostrarInformacion("Opción inválida.");
			}
		} while (opcion != 2);
	}
}
