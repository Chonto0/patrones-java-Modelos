package co.edu.udistrital.controller;

import co.edu.udistrital.model.Paquete;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;
    private Paquete paquete;

    public Controller() {
        vista = new VistaConsola();
        paquete = new Paquete();
    }

    public void run() {
        boolean continuar = true;

        while (continuar) {
            vista.mostrarInformacion("Estado actual del paquete: " + paquete.obtenerEstadoActual());

            if (paquete.obtenerEstadoActual().equals("Entregado") ||
                paquete.obtenerEstadoActual().equals("Perdido")) {
                vista.mostrarInformacion("El paquete ha llegado a un estado final.");
                break;
            }

            int opcion = vista.leerDatoEntero("\n¿Deseas avanzar al siguiente estado?\n1. Sí\n2. Salir");
            switch (opcion) {
                case 1:
                    paquete.procesarEstado();
                    break;
                case 2:
                    continuar = false;
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida.");
            }
        }

        vista.mostrarInformacion("Estado final del paquete: " + paquete.obtenerEstadoActual());
    }
}
