package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.Paquete;

public class EstadoEntregado implements Estado {

    @Override
    public void avanzarEstado(Paquete paquete) {
        
    }

    @Override
    public String getNombre() {
        return "Entregado";
    }
}
