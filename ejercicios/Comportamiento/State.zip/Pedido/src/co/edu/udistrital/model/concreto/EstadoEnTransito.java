package co.edu.udistrital.model.concreto;

import java.util.Random;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.Paquete;

public class EstadoEnTransito implements Estado {

    @Override
    public void avanzarEstado(Paquete paquete) {
        Random random = new Random();
        double probabilidad = random.nextDouble();

        if (probabilidad < 0.05) { 
            paquete.setEstado(new EstadoPerdido());
        } else {
            paquete.setEstado(new EstadoEntregado());
        }
    }

    @Override
    public String getNombre() {
        return "En tránsito";
    }
}
