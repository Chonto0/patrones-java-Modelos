package co.edu.udistrital.model;

public interface Estado {
    void avanzarEstado(Paquete paquete);
    String getNombre();
}
