package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.Paquete;

public class EstadoEnAlmacen implements Estado {

    @Override
    public void avanzarEstado(Paquete paquete) {
        paquete.setEstado(new EstadoEnTransito());
    }

    @Override
    public String getNombre() {
        return "En almacén";
    }
}
