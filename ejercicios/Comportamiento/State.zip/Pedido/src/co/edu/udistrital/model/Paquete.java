package co.edu.udistrital.model;

import co.edu.udistrital.model.concreto.EstadoEnAlmacen;

public class Paquete {
    private Estado estado;

    public Paquete() {
        this.estado = new EstadoEnAlmacen(); 
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public Estado getEstado() {
        return estado;
    }

    public void procesarEstado() {
        estado.avanzarEstado(this);
    }

    public String obtenerEstadoActual() {
        return estado.getNombre();
    }
}
