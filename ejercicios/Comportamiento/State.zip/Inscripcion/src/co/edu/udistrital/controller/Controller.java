package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

import java.util.ArrayList;
import java.util.List;

public class Controller {

	private VistaConsola vista;
	private Inscripcion contexto;

	public Controller() {
		this.contexto = new Inscripcion();
		this.vista = new VistaConsola();
	}

	public void run() {
		while (true) {
			Estado estado = contexto.getEstadoActual();
			vista.mostrarInformacion("\n>> Estado actual: " + estado.getNombreEstado() + "\n");

			if (estado instanceof RegistroAbierto) {
				mostrarMenuPrincipal();
			} else if (estado instanceof EnInscripcion inscripcion) {
				ejecutarInscripcion(inscripcion);
			} else if (estado instanceof InscripcionExitosa) {
				vista.mostrarInformacion(" Inscripción realizada con éxito.");
				ResultadoEstado resultado = estado.manejar();
				vista.mostrarInformacion(resultado.getMensaje());
				contexto.setEstado(resultado.getNuevoEstado());
			}
		}
	}

	private void mostrarMenuPrincipal() {
		vista.mostrarInformacion("""
				=== SISTEMA DE INSCRIPCIÓN ACADÉMICA ===\n
				1. Iniciar inscripción
				2. Reportar problema
				3. Salir""");
		int opcion = vista.leerDatoEntero("\nSeleccione una opción:");
		switch (opcion) {
		case 1 -> {
			ResultadoEstado resultado = contexto.getEstadoActual().manejar();
			vista.mostrarInformacion(resultado.getMensaje());
			contexto.setEstado(resultado.getNuevoEstado());
		}
		case 2 -> vista.mostrarInformacion(" Problema reportado. Gracias.");
		case 3 -> {
			vista.mostrarInformacion(" Saliendo del sistema...");
			System.exit(0);
		}
		default -> vista.mostrarInformacion(" Opción inválida.");
		}
	}

	private void ejecutarInscripcion(EnInscripcion inscripcion) {
		vista.mostrarInformacion("\n>> Bienvenido al módulo de inscripción.");
		List<String> materias = List.of("Ecuaciones Diferenciales", "Modelos de programación", "Métodos numéricos",
				"Ciencias de la computación II", "Investigación de operaciones I ");

		for (int i = 0; i < materias.size(); i++) {
			vista.mostrarInformacion((i + 1) + ". " + materias.get(i));
		}

		List<String> seleccionadas = new ArrayList<>();
		String continuar;
		do {
			int opcion = vista.leerDatoEntero("\nSeleccione la materia a inscribir (número):");
			if (opcion >= 1 && opcion <= materias.size()) {
				String materia = materias.get(opcion - 1);
				if (!seleccionadas.contains(materia)) {
					seleccionadas.add(materia);
				} else {
					vista.mostrarInformacion("\nYa has seleccionado esa materia.");
				}
			} else {
				vista.mostrarInformacion("Número inválido.");
			}
			continuar = vista.leerCadenaTexto("¿Desea agregar otra materia? (s/n):");
		} while (continuar.equalsIgnoreCase("s"));

		vista.mostrarInformacion("Materias seleccionadas:");
		for (String m : seleccionadas) {
			vista.mostrarInformacion(" - " + m);
		}

		inscripcion.setMateriasSeleccionadas(seleccionadas);

		vista.mostrarInformacion("""
				1. Confirmar inscripción
				2. Cancelar""");
		int opcion = vista.leerDatoEntero("Seleccione una opción:");
		if (opcion == 1) {
			ResultadoEstado resultado = inscripcion.manejar();
			vista.mostrarInformacion(resultado.getMensaje());
			contexto.setEstado(resultado.getNuevoEstado());
		} else {
			vista.mostrarInformacion(" Inscripción cancelada.");
			contexto.setEstado(new RegistroAbierto());
		}
	}
}
