package co.edu.udistrital.model;

public interface Estado {
    ResultadoEstado manejar();
    String getNombreEstado();
}
