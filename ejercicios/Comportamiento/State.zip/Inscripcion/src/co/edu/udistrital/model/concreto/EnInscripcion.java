package co.edu.udistrital.model.concreto;

import java.util.List;
import java.util.Random;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.ResultadoEstado;

public class EnInscripcion implements Estado {

    private List<String> materiasSeleccionadas;

    public void setMateriasSeleccionadas(List<String> materias) {
        this.materiasSeleccionadas = materias;
    }

    public List<String> getMateriasSeleccionadas() {
        return materiasSeleccionadas;
    }

    @Override
    public ResultadoEstado manejar() {
        Random random = new Random();
        int chance = random.nextInt(100);
        if (chance < 20) {
            return new ResultadoEstado(new InscripcionExitosa(), "\n Inscripción realizada con éxito.");
        } else {
            return new ResultadoEstado(new RegistroAbierto(), "\n La página se ha caído durante la inscripción.");
        }
    }

    @Override
    public String getNombreEstado() {
        return "\nEn Inscripción";
    }
}
