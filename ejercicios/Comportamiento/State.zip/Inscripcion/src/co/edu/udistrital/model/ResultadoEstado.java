package co.edu.udistrital.model;

public class ResultadoEstado {
    private Estado nuevoEstado;
    private String mensaje;

    public ResultadoEstado(Estado nuevoEstado, String mensaje) {
        this.nuevoEstado = nuevoEstado;
        this.mensaje = mensaje;
    }

    public Estado getNuevoEstado() {
        return nuevoEstado;
    }

    public String getMensaje() {
        return mensaje;
    }
}
