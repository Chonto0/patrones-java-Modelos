package co.edu.udistrital.model.concreto;

import java.util.Random;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.ResultadoEstado;

public class RegistroAbierto implements Estado {

    @Override
    public ResultadoEstado manejar() {
        Random random = new Random();
        int chance = random.nextInt(100);
        if (chance < 15) {
            return new ResultadoEstado(new EnInscripcion(), "\n Accediste al sistema de inscripción.");
        } else {
            return new ResultadoEstado(this, "\n La página se ha caído. Reiniciando...");
        }
    }

    @Override
    public String getNombreEstado() {
        return "\nRegistro Abierto";
    }
}
