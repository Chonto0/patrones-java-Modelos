package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Estado;
import co.edu.udistrital.model.ResultadoEstado;

public class InscripcionExitosa implements Estado {

	@Override
	public ResultadoEstado manejar() {
		return new ResultadoEstado(new RegistroAbierto(), "\n Volviendo al menú principal...");
	}

	@Override
	public String getNombreEstado() {
		return "\nInscripción Exitosa";
	}
}
