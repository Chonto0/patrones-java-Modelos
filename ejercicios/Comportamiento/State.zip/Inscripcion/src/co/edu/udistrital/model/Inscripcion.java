package co.edu.udistrital.model;

import co.edu.udistrital.model.concreto.RegistroAbierto;

public class Inscripcion {

    private Estado estado;

    public Inscripcion() {
        this.estado = new RegistroAbierto();
    }

    public Estado getEstadoActual() {
        return estado;
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }
}
