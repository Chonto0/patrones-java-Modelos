package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Control de Calidad de Productos ===");
        
        int dimension = vista.leerDatoEntero("Ingrese la dimensión del producto (cm): ");
        int peso = vista.leerDatoEntero("Ingrese el peso del producto (g): ");
        boolean defecto = vista.leerDefectoVisual("¿El producto tiene defectos visuales?");

        Producto producto = new Producto(dimension, peso, defecto);


        ControlCalidad dimensiones = new RevisionDimensiones();
        ControlCalidad pesoRev = new RevisionPeso();
        ControlCalidad visual = new RevisionVisual();
        ControlCalidad aprobacion = new AprobacionFinal();

        dimensiones.setSiguiente(pesoRev);
        pesoRev.setSiguiente(visual);
        visual.setSiguiente(aprobacion);

        String resultado = dimensiones.revisar(producto);
        vista.mostrarInformacion("\nResultado de control de calidad: " + resultado);
    }
}
