package co.edu.udistrital.model;

public class AprobacionFinal extends ControlCalidad {
    @Override
    public String revisar(Producto producto) {
        return "Producto aprobado en todas las revisiones.";
    }
}
