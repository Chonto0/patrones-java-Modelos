package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ControlCalidad;
import co.edu.udistrital.model.Producto;

public class RevisionVisual extends ControlCalidad {
    @Override
    public String revisar(Producto producto) {
        if (!producto.tieneDefectoVisual()) {
            if (siguiente != null) return siguiente.revisar(producto);
            return "Producto aprobado tras revisión visual.";
        }
        return "Rechazado: Presenta defectos visuales.";
    }
}
