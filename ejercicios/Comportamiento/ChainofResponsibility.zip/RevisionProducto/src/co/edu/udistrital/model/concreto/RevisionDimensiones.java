package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ControlCalidad;
import co.edu.udistrital.model.Producto;

public class RevisionDimensiones extends ControlCalidad {
    @Override
    public String revisar(Producto producto) {
        if (producto.getDimension() >= 10) {
            if (siguiente != null) return siguiente.revisar(producto);
            return "Producto aprobado tras revisión de dimensiones.";
        }
        return "Rechazado: Dimensiones insuficientes (mínimo 10 cm).";
    }
}
