package co.edu.udistrital.model;

public class Producto {
    private int dimension;
    private int peso;
    private boolean defectoVisual;

    public Producto(int dimension, int peso, boolean defectoVisual) {
        this.dimension = dimension;
        this.peso = peso;
        this.defectoVisual = defectoVisual;
    }

    public int getDimension() {
        return dimension;
    }

    public int getPeso() {
        return peso;
    }

    public boolean tieneDefectoVisual() {
        return defectoVisual;
    }
}
