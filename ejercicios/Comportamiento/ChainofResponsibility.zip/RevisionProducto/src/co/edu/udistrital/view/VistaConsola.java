package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {
	private Scanner sc;

	public VistaConsola() {
		sc = new Scanner(System.in);
	}

	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}

	public int leerDatoEntero(String mensaje) {
		int dato = -1;
		do {
			System.out.print(mensaje);
			while (!sc.hasNextInt()) {
				System.out.print("Por favor ingrese un número válido: ");
				sc.next();
			}
			dato = sc.nextInt();
		} while (dato < 0);
		sc.nextLine();
		return dato;
	}

	public boolean leerDefectoVisual(String mensaje) {
        String entrada;
        do {
            System.out.print(mensaje + " (S/N): ");
            entrada = sc.nextLine().trim().toUpperCase();
        } while (!entrada.equals("S") && !entrada.equals("N"));

        return entrada.equals("S");
    }
}