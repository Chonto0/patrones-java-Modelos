package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.ControlCalidad;
import co.edu.udistrital.model.Producto;

public class RevisionPeso extends ControlCalidad {
    @Override
    public String revisar(Producto producto) {
        if (producto.getPeso() >= 50 && producto.getPeso() <= 200) {
            if (siguiente != null) return siguiente.revisar(producto);
            return "Producto aprobado tras revisión de peso.";
        }
        return "Rechazado: Peso fuera del rango (50g - 200g).";
    }
}
