package co.edu.udistrital.model;

public abstract class ControlCalidad {
    protected ControlCalidad siguiente;

    public void setSiguiente(ControlCalidad siguiente) {
        this.siguiente = siguiente;
    }

    public abstract String revisar(Producto producto);
}
