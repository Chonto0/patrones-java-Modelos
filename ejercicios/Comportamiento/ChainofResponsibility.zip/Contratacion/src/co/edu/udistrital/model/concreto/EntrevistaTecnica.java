package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Candidato;
import co.edu.udistrital.model.Evaluador;

public class EntrevistaTecnica extends Evaluador {
    public String evaluar(Candidato candidato) {
        if (candidato.pasoTecnica()) {
            if (siguiente != null) return "Entrevista técnica aprobada.\n" + siguiente.evaluar(candidato);
            else return "Entrevista técnica aprobada.";
        } else {
            return "Falló entrevista técnica. Candidato rechazado.";
        }
    }
}
