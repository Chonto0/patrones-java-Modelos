package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {

    private static final Scanner sc = new Scanner(System.in);

    public static void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public static boolean leerBooleano(String mensaje) {
        while (true) {
            mostrarMensaje(mensaje);
            String entrada = sc.nextLine().trim().toLowerCase();
            if (entrada.equals("si") || entrada.equals("sí")) return true;
            else if (entrada.equals("no")) return false;
            else mostrarMensaje("Entrada no válida. Escriba 'si' o 'no'.");
        }
    }

    public static String leerLinea(String mensaje) {
        mostrarMensaje(mensaje);
        return sc.nextLine();
    }
}
