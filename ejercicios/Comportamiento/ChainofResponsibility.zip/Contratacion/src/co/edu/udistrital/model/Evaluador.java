package co.edu.udistrital.model;

public abstract class Evaluador {
    protected Evaluador siguiente;

    public void setSiguiente(Evaluador siguiente) {
        this.siguiente = siguiente;
    }

    public abstract String evaluar(Candidato candidato);
}
