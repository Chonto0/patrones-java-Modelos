package co.edu.udistrital.model;

public class Candidato {
    private String nombre;
    private boolean documentosOk;
    private boolean tecnicaOk;
    private boolean rrhhOk;

    public Candidato(String nombre, boolean documentosOk, boolean tecnicaOk, boolean rrhhOk) {
        this.nombre = nombre;
        this.documentosOk = documentosOk;
        this.tecnicaOk = tecnicaOk;
        this.rrhhOk = rrhhOk;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean tieneDocumentos() {
        return documentosOk;
    }

    public boolean pasoTecnica() {
        return tecnicaOk;
    }

    public boolean pasoRRHH() {
        return rrhhOk;
    }
}
