package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Candidato;
import co.edu.udistrital.model.Evaluador;

public class DocumentosVerificador extends Evaluador { 
    public String evaluar(Candidato candidato) {
        if (candidato.tieneDocumentos()) {
            if (siguiente != null) return "Documentos verificados.\n" + siguiente.evaluar(candidato);
            else return "Documentos verificados.";
        } else {
            return "Faltan documentos. Candidato rechazado.";
        }
    }
}
