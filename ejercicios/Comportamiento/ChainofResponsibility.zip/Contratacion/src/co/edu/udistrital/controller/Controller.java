package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.concreto.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    public void run() {
        // Crear cadena de evaluadores
        Evaluador documentos = new DocumentosVerificador();
        Evaluador tecnica = new EntrevistaTecnica();
        Evaluador rrhh = new EntrevistaRRHH();
        Evaluador aprobacion = new AprobacionFinal();

        documentos.setSiguiente(tecnica);
        tecnica.setSiguiente(rrhh);
        rrhh.setSiguiente(aprobacion);

        // Ingreso de datos por parte del usuario
        String nombre = VistaConsola.leerLinea("Ingrese el nombre del candidato:");

        boolean documentosOk = VistaConsola.leerBooleano("¿Tiene todos los documentos? (si/no): ");
        boolean tecnicaOk = VistaConsola.leerBooleano("¿Aprobó la entrevista técnica? (si/no): ");
        boolean rrhhOk = VistaConsola.leerBooleano("¿Aprobó la entrevista con RRHH? (si/no): ");

        Candidato candidato = new Candidato(nombre, documentosOk, tecnicaOk, rrhhOk);

        VistaConsola.mostrarMensaje("\nEvaluando a " + candidato.getNombre() + ":\n" + documentos.evaluar(candidato));
    }
}
