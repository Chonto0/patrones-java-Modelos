package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Candidato;
import co.edu.udistrital.model.Evaluador;

public class EntrevistaRRHH extends Evaluador {
    public String evaluar(Candidato candidato) {
        if (candidato.pasoRRHH()) {
            if (siguiente != null) return "Entrevista RRHH aprobada.\n" + siguiente.evaluar(candidato);
            else return "Entrevista RRHH aprobada.";
        } else {
            return "Falló entrevista RRHH. Candidato rechazado.";
        }
    }
}
