package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Candidato;
import co.edu.udistrital.model.Evaluador;

public class AprobacionFinal extends Evaluador {
    public String evaluar(Candidato candidato) {
        return "Candidato aprobado para contratación.";
    }
}
