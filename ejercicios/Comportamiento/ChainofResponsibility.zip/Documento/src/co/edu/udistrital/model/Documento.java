package co.edu.udistrital.model;

public class Documento {
    private boolean identidadValida = false;
    private boolean diplomaValido = false;
    private boolean pagoValido = false;

    public boolean isCompletado() {
        return identidadValida && diplomaValido && pagoValido;
    }

    public boolean isIdentidadValida() {
        return identidadValida;
    }

    public void setIdentidadValida(boolean identidadValida) {
        this.identidadValida = identidadValida;
    }

    public boolean isDiplomaValido() {
        return diplomaValido;
    }

    public void setDiplomaValido(boolean diplomaValido) {
        this.diplomaValido = diplomaValido;
    }

    public boolean isPagoValido() {
        return pagoValido;
    }

    public void setPagoValido(boolean pagoValido) {
        this.pagoValido = pagoValido;
    }
}
