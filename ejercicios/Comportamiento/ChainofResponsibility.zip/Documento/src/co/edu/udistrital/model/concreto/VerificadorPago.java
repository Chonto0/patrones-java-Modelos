package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Documento;
import co.edu.udistrital.model.VerificadorBase;

public class VerificadorPago extends VerificadorBase {
    private int respuesta;

    public VerificadorPago(int respuesta) {
        this.respuesta = respuesta;
    }

    @Override
    public void verificar(Documento doc) {
        doc.setPagoValido(respuesta == 1);
        verificarSiguiente(doc);
    }
}
