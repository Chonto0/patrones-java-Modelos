package co.edu.udistrital.model;

public interface IVerificador {
    IVerificador setSiguiente(IVerificador verificador);
    void verificar(Documento doc);
}
