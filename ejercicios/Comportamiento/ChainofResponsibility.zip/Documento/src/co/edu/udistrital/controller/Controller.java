package co.edu.udistrital.controller;

import co.edu.udistrital.model.Documento;
import co.edu.udistrital.model.IVerificador;
import co.edu.udistrital.model.concreto.VerificadorDiploma;
import co.edu.udistrital.model.concreto.VerificadorIdentidad;
import co.edu.udistrital.model.concreto.VerificadorPago;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("Responde 1 para SÍ y 2 para NO.\n");

        int identidad = vista.leerDatoEntero("¿El documento de identidad es válido? ");
        int diploma = vista.leerDatoEntero("¿El diploma de bachiller es válido? ");
        int pago = vista.leerDatoEntero("¿El pago está confirmado? ");

        Documento doc = new Documento();

        // Se crea la cadena
        IVerificador verificador = new VerificadorIdentidad(identidad);
        verificador.setSiguiente(new VerificadorDiploma(diploma))
                   .setSiguiente(new VerificadorPago(pago));

        // Ejecutar la verificación en cadena
        verificador.verificar(doc);

        // Resultado final
        if (doc.isCompletado()) {
            vista.mostrarInformacion("Registro completado exitosamente.");
        } else {
            vista.mostrarInformacion("Registro incompleto. Documentos faltantes o inválidos.");
        }
    }
}
