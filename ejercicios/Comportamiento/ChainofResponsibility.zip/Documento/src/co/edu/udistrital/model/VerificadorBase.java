package co.edu.udistrital.model;

public abstract class VerificadorBase implements IVerificador {
    protected IVerificador siguiente;

    @Override
    public IVerificador setSiguiente(IVerificador verificador) {
        this.siguiente = verificador;
        return verificador;
    }

    protected void verificarSiguiente(Documento doc) {
        if (siguiente != null) {
            siguiente.verificar(doc);
        }
    }
}
