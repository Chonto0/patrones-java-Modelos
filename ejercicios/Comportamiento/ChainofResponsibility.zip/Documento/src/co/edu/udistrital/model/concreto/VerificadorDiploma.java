package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Documento;
import co.edu.udistrital.model.VerificadorBase;

public class VerificadorDiploma extends VerificadorBase {
    private int respuesta;

    public VerificadorDiploma(int respuesta) {
        this.respuesta = respuesta;
    }

    @Override
    public void verificar(Documento doc) {
        doc.setDiplomaValido(respuesta == 1);
        verificarSiguiente(doc);
    }
}
