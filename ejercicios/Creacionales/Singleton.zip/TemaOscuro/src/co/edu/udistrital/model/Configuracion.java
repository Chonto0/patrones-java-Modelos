package co.edu.udistrital.model;

public class Configuracion {

	// Instancia única de Configuracion (Singleton)
	private static Configuracion instancia;

	// Valor que representa la configuración del sistema (por ejemplo, un tema)
	private String configuracion;

	// Constructor privado para evitar que se creen múltiples instancias
	private Configuracion() {
	}

	// Método que retorna la única instancia de Configuracion
	public static Configuracion getInstancia() {
		if (instancia == null) {
			// Si no existe aún, se crea la instancia
			instancia = new Configuracion();
		}
		// Se retorna la instancia existente
		return instancia;
	}

	// Getter para obtener el valor de la configuración
	public String getConfiguracion() {
		return configuracion;
	}

	// Setter para modificar el valor de la configuración
	public void setConfiguracion(String configuracion) {
		this.configuracion = configuracion;
	}
}