package co.edu.udistrital.controller;

import co.edu.udistrital.model.Configuracion;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		// Obtener la instancia única de Configuracion
		Configuracion configuracion = Configuracion.getInstancia();
		Configuracion otraConfiguracion = Configuracion.getInstancia(); // Mismo objeto

		// Establecer una configuración (Tema Oscuro)
		configuracion.setConfiguracion("Se establecío Tema Oscuro");

		// Mostrar la configuración usando otra referencia al mismo objeto
		vista.mostrarInformacion("Establecer Tema para el dispositivo \n" + otraConfiguracion.getConfiguracion());

		// Cambiar la configuración a Tema Claro desde otraConfiguracion
		// Como es la misma instancia, esto modifica el mismo objeto compartido
		otraConfiguracion.setConfiguracion("Se establecio Tema Claro"); // se garantiza que se obtendra la misma
																		// instancia siempre
	}
}
