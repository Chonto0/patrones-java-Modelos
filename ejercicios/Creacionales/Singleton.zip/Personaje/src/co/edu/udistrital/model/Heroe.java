package co.edu.udistrital.model;

public class Heroe {

	// Instancia única del héroe (Singleton)
	private static Heroe instancia;

	// Atributos del héroe
	private String nombre;
	private int nivel;
	private int puntosDeVida;

	// Constructor privado para impedir instanciación desde fuera de la clase
	private Heroe() {
		this.nombre = "Guerrero Legendario"; // nombre por defecto
		this.nivel = 1; // nivel inicial
		this.puntosDeVida = 100; // vida inicial
	}

	// Método para obtener la única instancia del héroe (Singleton)
	public static Heroe getInstancia() {
		if (instancia == null) {
			// Si aún no existe la instancia, la crea
			instancia = new Heroe();
		}
		// Retorna la instancia existente
		return instancia;
	}

	// Getters y setters para acceder y modificar los atributos del héroe
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getNivel() {
		return nivel;
	}

	// Método para subir el nivel del héroe
	public void subirNivel() {
		this.nivel++;
	}

	public int getPuntosDeVida() {
		return puntosDeVida;
	}

	// Método para aplicar daño al héroe y reducir sus puntos de vida
	public void recibirDaño(int daño) {
		this.puntosDeVida -= daño;
		// Si la vida cae por debajo de 0, se ajusta a 0
		if (this.puntosDeVida < 0) {
			this.puntosDeVida = 0;
		}
	}
}
