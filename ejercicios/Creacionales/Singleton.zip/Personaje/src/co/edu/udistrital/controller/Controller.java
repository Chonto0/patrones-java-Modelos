package co.edu.udistrital.controller;

import co.edu.udistrital.model.Heroe;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		// Se obtiene la instancia del héroe (Singleton)
		Heroe heroe = Heroe.getInstancia();
		Heroe otroHeroe = Heroe.getInstancia(); // Mismo objeto

		// Mostrar información inicial del héroe
		vista.mostrarInformacion("Bienvenido, " + heroe.getNombre());
		vista.mostrarInformacion("Nivel actual: " + heroe.getNivel());
		vista.mostrarInformacion("Puntos de vida: " + heroe.getPuntosDeVida());

		// Modificar el estado del héroe (sube de nivel y recibe daño)
		otroHeroe.subirNivel();
		otroHeroe.recibirDaño(30);

		// Mostrar estado actualizado usando la misma instancia
		vista.mostrarInformacion("\nDespués de la batalla:");
		vista.mostrarInformacion("Nivel: " + heroe.getNivel());
		vista.mostrarInformacion("Puntos de vida: " + heroe.getPuntosDeVida());
	}
}