package co.edu.udistrital.model;

public class Configuracion {

	// Atributo estático para guardar la única instancia de la clase (Singleton)
	private static Configuracion instancia;

	// Atributos de configuración de un dispositivo
	private String idiomaYregion;
	private String redWIFI;
	private String cuenta;
	private String desbloqueo;

	// Constructor privado: impide que se creen objetos desde fuera de la clase
	private Configuracion() {
		// Evita instanciación directa
	}

	// Método estático para acceder a la única instancia de Configuracion
	public static Configuracion getInstancia() {
		// Si aún no se ha creado la instancia, se crea
		if (instancia == null) {
			instancia = new Configuracion();
		}
		// Se devuelve la misma instancia en todas las llamadas
		return instancia;
	}

	// Métodos getters y setters para acceder y modificar los atributos
	public String getIdiomaYregion() {
		return idiomaYregion;
	}

	public void setIdiomaYregion(String idiomaYregion) {
		this.idiomaYregion = idiomaYregion;
	}

	public String getRedWIFI() {
		return redWIFI;
	}

	public void setRedWIFI(String redWIFI) {
		this.redWIFI = redWIFI;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getDesbloqueo() {
		return desbloqueo;
	}

	public void setDesbloqueo(String desbloqueo) {
		this.desbloqueo = desbloqueo;
	}
}
