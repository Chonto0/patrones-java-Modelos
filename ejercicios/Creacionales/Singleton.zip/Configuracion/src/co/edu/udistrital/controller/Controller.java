package co.edu.udistrital.controller;

import co.edu.udistrital.model.Configuracion;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		// Se obtiene la instancia única de configuración (Singleton)
		Configuracion configuracion = Configuracion.getInstancia();
		Configuracion otraConfiguracion = Configuracion.getInstancia();

		// Se configuran los valores usando la instancia
		configuracion.setIdiomaYregion("Español, Colombia");
		configuracion.setRedWIFI("Red_UD_Estudiantes");
		configuracion.setCuenta("alumno001@gmail.com");
		configuracion.setDesbloqueo("PIN:8642");

		// Se muestran los datos usando otra referencia (que apunta a la misma
		// instancia)
		vista.mostrarInformacion("Idioma y región: " + otraConfiguracion.getIdiomaYregion());
		vista.mostrarInformacion("Red Wi-Fi: " + otraConfiguracion.getRedWIFI());
		vista.mostrarInformacion("Cuenta: " + otraConfiguracion.getCuenta());
		vista.mostrarInformacion("Desbloqueo: " + otraConfiguracion.getDesbloqueo());
	}
}