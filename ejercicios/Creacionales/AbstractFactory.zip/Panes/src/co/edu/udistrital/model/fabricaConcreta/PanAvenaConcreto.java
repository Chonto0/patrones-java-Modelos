package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.PanAvena;
import co.edu.udistrital.model.fabricaAbstracta.Pan;
import co.edu.udistrital.model.fabricaAbstracta.PanFactory;

public class PanAvenaConcreto implements PanFactory {

    @Override
    public Pan crearPan() {
        return new PanAvena(); // Crea y retorna una instancia de PanAvena
    }
}
