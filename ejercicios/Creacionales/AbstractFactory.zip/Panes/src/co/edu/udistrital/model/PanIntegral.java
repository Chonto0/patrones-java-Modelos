package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.Pan;

public class PanIntegral implements Pan {

	@Override
	public String nombre() {
		return "Pan Integral"; // Retorna el nombre del pan
	}

	@Override
	public String hornear() {
		return "Horneando Pan Integral"; // Descripción de cómo se hornea el pan
	}

	@Override
	public String preparar() {
		return "Preparando pan Integral"; // Descripción de la preparación del pan
	}
}