package co.edu.udistrital.controller;

import java.util.Scanner;

import co.edu.udistrital.model.fabricaAbstracta.Pan;
import co.edu.udistrital.model.fabricaAbstracta.PanFactory;
import co.edu.udistrital.model.fabricaConcreta.PanAvenaConcreto;
import co.edu.udistrital.model.fabricaConcreta.PanBlancoConcreto;
import co.edu.udistrital.model.fabricaConcreta.PanIntegralConcreto;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		// se selecciona la fábrica correspondiente
		vista.mostrarInformacion("Bienvenido a la panadería. ¿Qué tipo de pan deseas?");
		vista.mostrarInformacion("Opciones disponibles: 'Blanco', 'Integral', 'Avena'");

		try (Scanner scanner = new Scanner(System.in)) {
			String tipoDePan = scanner.nextLine();

			PanFactory creadorPan;

			// se asigna la fábrica según el tipo de pan
			switch (tipoDePan.toLowerCase()) {
			case "blanco":
				creadorPan = new PanBlancoConcreto();
				break;
			case "integral":
				creadorPan = new PanIntegralConcreto();
				break;
			case "avena":
				creadorPan = new PanAvenaConcreto();
				break;
			default:
				vista.mostrarInformacion("Error: Tipo de pan desconocido.");
				return;
			}

			// se crea el pan usando la fábrica correspondiente
			Pan pan = creadorPan.crearPan();

			// se muestran los detalles del pan
			vista.mostrarInformacion(pan.preparar());
			vista.mostrarInformacion(pan.hornear());
		}
	}
}
