package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.PanBlanco;
import co.edu.udistrital.model.fabricaAbstracta.Pan;
import co.edu.udistrital.model.fabricaAbstracta.PanFactory;

public class PanBlancoConcreto implements PanFactory {

    @Override
    public Pan crearPan() {
        return new PanBlanco(); // Crea y retorna una instancia de PanBlanco
    }
}
