package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.PanIntegral;
import co.edu.udistrital.model.fabricaAbstracta.Pan;
import co.edu.udistrital.model.fabricaAbstracta.PanFactory;

public class PanIntegralConcreto implements PanFactory {

	@Override
	public Pan crearPan() {
		return new PanIntegral();// Crea y retorna una instancia de PanIntegral
	}
}
