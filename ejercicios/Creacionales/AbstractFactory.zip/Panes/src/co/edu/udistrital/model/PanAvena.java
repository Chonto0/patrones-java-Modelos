package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.Pan;

public class PanAvena implements Pan{
	
    @Override
    public String nombre() {
        return "Pan de Avena"; // Retorna el nombre del pan
    }

    @Override
    public String hornear() {
        return "Horneando Pan de Avena"; // Descripción de cómo se hornea el pan
    }
    
    @Override
    public String preparar() {
        return "Preparando pan de avena"; // Descripción de la preparación del pan
    }
}