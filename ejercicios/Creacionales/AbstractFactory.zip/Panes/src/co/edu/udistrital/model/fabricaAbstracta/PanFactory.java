package co.edu.udistrital.model.fabricaAbstracta;

public interface PanFactory { // creador

	// Método para crear un objeto de tipo Pan
	Pan crearPan();

}