package co.edu.udistrital.model.fabricaAbstracta;

public interface Pan {
	// Método para obtener el nombre del pan
	String nombre();

	// Método para preparar el pan
	String preparar();

	// Método para hornear el pan
	String hornear();
}