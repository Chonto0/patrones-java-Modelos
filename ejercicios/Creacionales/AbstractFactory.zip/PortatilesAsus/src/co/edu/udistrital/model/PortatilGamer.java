package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.Portatil;

public class PortatilGamer implements Portatil {
	@Override
	public String obtenerDetalles() {
		return "Portátil Gamer: Ryzen 9, 32GB RAM, 1TB SSD, RTX 4080";
	}
}