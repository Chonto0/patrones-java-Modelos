package co.edu.udistrital.controller;

import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.Concreta.GamerConcreto;
import co.edu.udistrital.model.Concreta.HogarConcreto;
import co.edu.udistrital.model.Concreta.TrabajoConcreto;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		int op = 0;
		// Bucle principal del programa que se ejecuta hasta que el usuario elija salir
		do {
			op = menu(); // Muestra el menú y lee la opción del usuario

			// Ejecuta la opción seleccionada por el usuario
			switch (op) {
			case 1:
				// Crea un portátil gamer
				portatil(new GamerConcreto());
				break;
			case 2:
				// Crea un portátil de trabajo
				portatil(new TrabajoConcreto());
				break;
			case 3:
				// Crea un portátil de hogar
				portatil(new HogarConcreto());
				break;
			case 4:
				// Opción para salir del programa
				vista.mostrarInformacion("Cerrando Programa");
				System.exit(0); // Termina la ejecución
			default:
				// Si el usuario ingresa una opción inválida
				vista.mostrarInformacion(".....Opcion invalida....");
			}

			vista.mostrarInformacion(""); // Espacio en blanco para separar salidas
		} while (op != 4);
	}

	/**
	 * Método que usa una fábrica de portátiles (PortatilFactory) para crear un
	 * portátil y mostrar sus especificaciones.
	 */
	public void portatil(PortatilFactory Portatil) {
		Portatil portatil = Portatil.crearPortatil(); // Usa la fábrica concreta
		vista.mostrarInformacion("Especificaciones del portátil:");
		vista.mostrarInformacion(portatil.obtenerDetalles());
	}

	/**
	 * Muestra el menú al usuario y retorna la opción seleccionada.
	 */
	public int menu() {
		String menu2 = "Bienvenido a la tienda ASUS. \n" + "Seleccione el tipo de portátil: \n"
				+ "1. Gamer\n2. Trabajo\n3. Hogar\n4. Cerrar programa. \n" + "Ingrese su opción: \n";
		return vista.leerDatoEntero(menu2);
	}
}
