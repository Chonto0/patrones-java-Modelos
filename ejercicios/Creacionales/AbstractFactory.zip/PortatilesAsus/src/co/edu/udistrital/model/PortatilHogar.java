package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.Portatil;

public class PortatilHogar implements Portatil {
	@Override
	public String obtenerDetalles() {
		return "Portátil de Hogar: Intel i3, 8GB RAM, 256GB SSD, Gráficos Integrados";
	}
}
