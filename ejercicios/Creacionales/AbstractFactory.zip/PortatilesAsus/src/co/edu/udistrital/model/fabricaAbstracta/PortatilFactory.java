package co.edu.udistrital.model.fabricaAbstracta;

// Interfaz para la fábrica abstracta.
// Define el método que deben implementar todas las fábricas concretas para crear un portátil.
public interface PortatilFactory {
	Portatil crearPortatil();
}
