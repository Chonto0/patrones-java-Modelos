package co.edu.udistrital.model.fabricaAbstracta;

// Método que todas las clases que representen un portátil deben implementar.
// Devuelve una cadena con los detalles del portátil.
public interface Portatil {
	String obtenerDetalles();
}