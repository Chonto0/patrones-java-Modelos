package co.edu.udistrital.model.Concreta;

import co.edu.udistrital.model.PortatilTrabajo;
import co.edu.udistrital.model.fabricaAbstracta.*;

public class TrabajoConcreto implements PortatilFactory {
    @Override
	public Portatil crearPortatil() {
    	// Retorna una instancia concreta de un portátil para el trabajo.
		return new PortatilTrabajo();
	}
}
