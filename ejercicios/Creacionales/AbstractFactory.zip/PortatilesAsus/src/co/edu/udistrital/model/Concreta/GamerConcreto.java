package co.edu.udistrital.model.Concreta;

import co.edu.udistrital.model.PortatilGamer;
import co.edu.udistrital.model.fabricaAbstracta.*;

public class GamerConcreto implements PortatilFactory {
	@Override
	public Portatil crearPortatil() {
		// Retorna una instancia concreta de un portátil tipo Gamer.
		return new PortatilGamer();
	}
}
