package co.edu.udistrital.model.Concreta;

import co.edu.udistrital.model.PortatilHogar;
import co.edu.udistrital.model.fabricaAbstracta.*;

public class HogarConcreto implements PortatilFactory {

	@Override
	public Portatil crearPortatil() {
		// Retorna una instancia concreta de un portátil para el hogar.
		return new PortatilHogar();
	}
}
