package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.Portatil;

public class PortatilTrabajo implements Portatil {
	@Override
	public String obtenerDetalles() {
		return "Portátil de Trabajo: Intel i7, 16GB RAM, 512GB SSD, Gráficos Intel Iris";
	}
}
