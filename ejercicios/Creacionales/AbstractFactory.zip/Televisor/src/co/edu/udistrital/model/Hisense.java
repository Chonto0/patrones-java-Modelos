package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.TV;

public class Hisense implements TV {
	
    @Override
    public String descripcion32() {
        return "Caixum TV 32 pulgadas - LED básico";
    }

    @Override
    public String descripcion44() {
        return "Caixum TV 44 pulgadas - LED Full HD";
    }

    @Override
    public String descripcion60() {
        return "Caixum TV 60 pulgadas - 4K Smart TV";
    }
}