package co.edu.udistrital.model;

import co.edu.udistrital.model.fabricaAbstracta.TV;

public class Samsung implements TV {
    @Override
    public String descripcion32() {
        return "Samsung TV 32 pulgadas - Full HD";
    }

    @Override
    public String descripcion44() {
        return "Samsung TV 44 pulgadas - UHD 4K";
    }

    @Override
    public String descripcion60() {
        return "Samsung TV 60 pulgadas - QLED";
    }
}