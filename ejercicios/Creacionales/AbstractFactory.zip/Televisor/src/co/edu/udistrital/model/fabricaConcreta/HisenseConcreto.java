package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.fabricaAbstracta.*;

public class HisenseConcreto implements TVFactory {
    @Override
    public TV crearTV() {
        return new Samsung();
    }
	
}

