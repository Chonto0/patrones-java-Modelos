package co.edu.udistrital.model.fabricaAbstracta;

public interface TV {
    String descripcion32();
    String descripcion44();
    String descripcion60();
}