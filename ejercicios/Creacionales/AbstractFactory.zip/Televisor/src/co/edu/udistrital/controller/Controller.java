package co.edu.udistrital.controller;

import co.edu.udistrital.model.fabricaConcreta.SamsungConcreto;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.fabricaAbstracta.TV;
import co.edu.udistrital.model.fabricaAbstracta.TVFactory;
import co.edu.udistrital.model.fabricaConcreta.HisenseConcreto;
import co.edu.udistrital.model.fabricaConcreta.CaixumConcreto;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int op = 0;
        do {
            op = menu();
            switch (op) {
                case 1:
                    mostrarTV(new SamsungConcreto());
                    break;
                case 2:
                    mostrarTV(new HisenseConcreto());
                    break;
                case 3:
                    mostrarTV(new CaixumConcreto());
                    break;
                case 4:
                    vista.mostrarInformacion("Cerrando programa...");
                    System.exit(0);
                    break;
                default:
                    vista.mostrarInformacion("Opción inválida...");
            }
            vista.mostrarInformacion("");
        } while (op != 4);
    }

    public void mostrarTV(TVFactory fabrica) {
        TV servicioTV = fabrica.crearTV();
        int tamanio = seleccionarTamano();

        switch (tamanio) {
            case 1:
                vista.mostrarInformacion(servicioTV.descripcion32());
                break;
            case 2:
                vista.mostrarInformacion(servicioTV.descripcion44());
                break;
            case 3:
                vista.mostrarInformacion(servicioTV.descripcion60());
                break;
            default:
                vista.mostrarInformacion("Tamaño inválido...");
        }
    }

    public int menu() {
        String textoMenu = 
            "===== MENU DE MARCAS DE TELEVISORES =====\n" +
            "1. Samsung\n" +
            "2. Hisense\n" +
            "3. Caixum\n" +
            "4. Cerrar programa\n\n" +
            "Seleccione una opción: ";
        return vista.leerDatoEntero(textoMenu);
    }

    public int seleccionarTamano() {
        String textoTamano =
            "\nSeleccione el tamaño de pantalla:\n" +
            "1. 32 pulgadas\n" +
            "2. 44 pulgadas\n" +
            "3. 60 pulgadas\n\n" +
            "Seleccione una opción: ";
        return vista.leerDatoEntero(textoTamano);
    }
}
