package co.edu.udistrital.model.fabricaAbstracta;

public interface TVFactory {
	TV crearTV();
}