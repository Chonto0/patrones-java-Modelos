package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.Samsung;
import co.edu.udistrital.model.fabricaAbstracta.*;

public class SamsungConcreto implements TVFactory {
	
    @Override
    public TV crearTV() {
        return new Samsung();
    }
	
}

