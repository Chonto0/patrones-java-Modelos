package co.edu.udistrital.model.abstracto;

//Interfaz que define el contrato del Factory Method
public interface PanFactory {
	Pan crearPan(String nombre); // Método para crear panes según el tipo
}