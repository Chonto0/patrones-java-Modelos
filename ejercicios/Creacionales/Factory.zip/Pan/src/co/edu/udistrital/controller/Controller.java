package co.edu.udistrital.controller;

import java.util.Scanner;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		// Crear una fábrica de panes (patrón Factory Method)
		PanFactory creadorPan = new PanCreador();

		// Se usa try-with-resources para asegurar que Scanner se cierre automáticamente
		try (Scanner scanner = new Scanner(System.in)) {

			// Mostrar mensaje de bienvenida
			vista.mostrarInformacion("Bienvenido a la panadería. ¿Qué tipo de pan deseas?");
			vista.mostrarInformacion("Opciones disponibles: 'Blanco', 'Integral', 'Avena'");

			// Leer el tipo de pan que el usuario desea
			String tipoDePan = scanner.nextLine();

			try {
				// Utilizar la fábrica para crear una instancia del tipo de pan seleccionado
				Pan pan = creadorPan.crearPan(tipoDePan);

				// Mostrar los pasos de preparación y horneado del pan
				vista.mostrarInformacion(pan.preparar()); // Salida: "Preparando pan..."
				vista.mostrarInformacion(pan.hornear()); // Salida: "El pan ... está horneado."

			} catch (IllegalArgumentException e) {
				// Captura errores cuando se ingresa un tipo de pan inválido
				vista.mostrarInformacion("Error: " + e.getMessage());
			}
		}
	}
}
