package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Pan;
import co.edu.udistrital.model.abstracto.PanFactory;

//Clase que implementa la lógica para crear panes específicos
public class PanCreador implements PanFactory {

	// Método que crea un tipo de pan específico según el parámetro
	@Override
	public Pan crearPan(String tipo) {
		switch (tipo) {
		case "Blanco":
			return new PanBlanco(); // Crea pan blanco
		case "Integral":
			return new PanIntegral(); // Crea pan integral
		case "Avena":
			return new PanAvena(); // Crea pan de avena
		default:
			// Lanza excepción si el tipo no es válido
			throw new IllegalArgumentException("Tipo de pan desconocido: " + tipo);
		}
	}
}
