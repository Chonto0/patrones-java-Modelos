package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pan;

//Clase concreta que representa el pan integral
public class PanIntegral extends Pan {

	public PanIntegral() {
		super("Pan Integral"); // Llama al constructor de la superclase
	}

	// Implementación del método preparar
	@Override
	public String preparar() {
		return "Preparando pan integral";
	}
}