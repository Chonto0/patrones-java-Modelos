package co.edu.udistrital.model.abstracto;

public abstract class Pan {
	protected String nombre;

	// Constructor que inicializa el nombre del pan
	public Pan(String nombre) {
		this.nombre = nombre;
	}

	// Método abstracto que cada tipo de pan debe implementar
	public abstract String preparar();

	// Método concreto que simula hornear cualquier tipo de pan
	public String hornear() {
		return "El pan " + nombre + " está horneado.";
	}

	// Método toString que muestra el nombre del pan
	@Override
	public String toString() {
		return "Pan: " + nombre;
	}
}