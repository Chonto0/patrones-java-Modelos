package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pan;

//Clase que representa el pan blanco
public class PanBlanco extends Pan {

	public PanBlanco() {
		super("Pan Blanco"); // Llama al constructor de la superclase
	}

	// Implementación del método preparar
	@Override
	public String preparar() {
		return "Preparando pan blanco";
	}
}