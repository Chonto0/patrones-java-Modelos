package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pan;

//Clase que representa el pan de avena
public class PanAvena extends Pan {

	public PanAvena() {
		super("Pan de Avena"); // Llama al constructor de la superclase
	}

	// Implementación del método preparar
	@Override
	public String preparar() {
		return "Preparando pan de avena";
	}
}