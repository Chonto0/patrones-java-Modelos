package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Personaje;

//La clase Ladron extiende (hereda de) la clase abstracta Personaje
public class Ladron extends Personaje{

	// Constructor de la clase Ladron que recibe los atributos y los pasa al constructor de la clase padre (Personaje)
	public Ladron(int mana, int fuerza, int destreza, int agilidad) {
		super(mana, fuerza, destreza, agilidad);// Llama al constructor de la clase abstracta
	}

    // Implementación del método abstracto describir(), requerido por la clase base
    // Retorna una descripción textual del tipo de personaje
	@Override
	public String describir() {
		return " Ladron ";
	}

    // Implementación del método abstracto nivel(), también requerido por la clase base
    // Calcula un "nivel" del personaje a partir de sus estadísticas, con distintos pesos
	@Override
	public String nivel() {
			
		double pesoladron = 0.4;
		double peso= 0.2;
		
		double suma = pesoladron + peso*3;
		
		double nivCal = (mana * peso + fuerza * peso + destreza * peso + agilidad * pesoladron) / suma;
		
		int niv = (int) Math.round(nivCal);
		
		return Integer.toString(niv);
	}
}
