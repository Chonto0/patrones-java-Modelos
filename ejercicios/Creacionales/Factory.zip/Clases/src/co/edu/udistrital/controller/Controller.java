package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		// Variables para las estadísticas del personaje
		int a = 0;
		int b = 0;
		int c = 0;
		int d = 0;

		vista.mostrarInformacion("ESTADISTICAS DE TU PERSONAJE");

		// Solicita al usuario los valores para cada estadística mediante la vista
		// (consola)
		a = vista.leerDatoEntero("\t" + "Digite valor del mana: ");
		b = vista.leerDatoEntero("\t" + "Digite valor de la fuerza: ");
		c = vista.leerDatoEntero("\t" + "Digite valor de la destreza: ");
		d = vista.leerDatoEntero("\t" + "Digite valor de la agilidad: ");

		// Se crea una fábrica de personajes usando la implementación concreta
		PersonajeFactory fabrica = new PersonajeCreador();

		// Se utiliza la fábrica para crear el personaje adecuado según las estadísticas
		Personaje personaje = fabrica.crearPersonaje(a, b, c, d);

		// Muestra al usuario qué tipo de personaje se creó y cuál es su nivel
		vista.mostrarInformacion("Tu personaje es un" + personaje.describir());
		vista.mostrarInformacion("Su nivel es " + personaje.nivel());
	}

}
