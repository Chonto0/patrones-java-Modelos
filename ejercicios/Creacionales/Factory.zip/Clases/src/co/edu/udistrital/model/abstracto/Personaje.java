package co.edu.udistrital.model.abstracto;

public abstract class Personaje {

	protected int mana;
	protected int fuerza;
	protected int destreza;
	protected int agilidad;

//Constructor de la clase que inicializa los atributos con los valores recibidos como parámetros
	public Personaje(int mana1, int fuerza2, int destreza3, int agilidad4) {
		this.mana = mana1;
		this.fuerza = fuerza2;
		this.destreza = destreza3;
		this.agilidad = agilidad4;
	}

	public abstract String describir();

	public abstract String nivel();

}
