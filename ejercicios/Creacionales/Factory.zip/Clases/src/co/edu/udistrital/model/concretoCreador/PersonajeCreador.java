package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Personaje;
import co.edu.udistrital.model.abstracto.PersonajeFactory;

//Clase concreta que implementa la interfaz PersonajeFactory
//Es el "creador concreto" en el patrón Factory Method
public class PersonajeCreador implements PersonajeFactory {

	// Implementación del método de la interfaz
	// Crea un objeto del tipo Personaje dependiendo de qué estadística es mayor
	@Override
	public Personaje crearPersonaje(int estadiA, int estadiB, int estadiC, int estadiD) {
		// Si el atributo estadiA (mana) es el más alto, se crea un Mago
		if (estadiA >= estadiB && estadiA >= estadiC && estadiA >= estadiD) {
			return new Mago(estadiA, estadiB, estadiC, estadiD);
			// Si fuerza (estadiB) es la mayor estadística, se crea un Guerrero
		} else if (estadiB > estadiA && estadiB >= estadiC && estadiB >= estadiD) {
			return new Guerrero(estadiA, estadiB, estadiC, estadiD);
			// Si destreza (estadiC) es la mayor, se crea un Arquero
		} else if (estadiC > estadiA && estadiC > estadiB && estadiC >= estadiD) {
			return new Arquero(estadiA, estadiB, estadiC, estadiD);
			// En caso contrario, se crea un Ladrón (cuando agilidad - estadiD - es la
			// mayor)
		} else {
			return new Ladron(estadiA, estadiB, estadiC, estadiD);
		}
	}
}
