package co.edu.udistrital.model.abstracto;

public interface PersonajeFactory { //creador
	
    // Recibe como parámetros los atributos básicos del personaje.
    // Devuelve un objeto del tipo Personaje (una subclase concreta de la clase abstracta Personaje)
    Personaje crearPersonaje(int mana1, int fuerza2, int destreza3, int agilidad4);
    
}
