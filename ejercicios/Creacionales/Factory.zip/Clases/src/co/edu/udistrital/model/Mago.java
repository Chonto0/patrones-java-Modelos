package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Personaje;

//Constructor de la clase Mago que recibe los atributos y los pasa al constructor de la clase padre (Personaje)
public class Mago extends Personaje {

	// Constructor de la clase Arquero que recibe los atributos y los pasa al
	// constructor de la clase padre (Personaje)
	public Mago(int mana, int fuerza, int destreza, int agilidad) {
		super(mana, fuerza, destreza, agilidad);// Llama al constructor de la clase abstracta
	}

	// Implementación del método abstracto describir(), requerido por la clase base
	// Retorna una descripción textual del tipo de personaje
	@Override
	public String describir() {
		return " Mago ";
	}

	// Implementación del método abstracto nivel(), también requerido por la clase
	// base
	// Calcula un "nivel" del personaje a partir de sus estadísticas, con distintos
	// pesos
	@Override
	public String nivel() {

		double pesomana = 0.4;
		double peso = 0.2;

		double suma = pesomana + peso * 3;

		double nivCal = (mana * pesomana + fuerza * peso + destreza * peso + agilidad * peso) / suma;

		int niv = (int) Math.round(nivCal);

		return Integer.toString(niv);
	}
}
