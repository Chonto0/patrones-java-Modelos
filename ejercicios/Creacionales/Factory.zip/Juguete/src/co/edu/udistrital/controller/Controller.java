package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrar("Bienvenido a la juguetería.");

		// Solicita los datos del juguete al usuario
		String tipo = vista.leerTexto("¿Qué tipo de juguete deseas? (Carro, Rompecabezas, Pelota): ");
		String nombre = vista.leerTexto("Nombre del juguete: ");
		int edad = vista.leerEntero("Edad recomendada: ");
		String material = vista.leerTexto("Material del juguete: ");

		try {
			// Usa el patrón Factory para crear el juguete
			JugueteFactory fabrica = new JugueteCreador();
			Juguete juguete = fabrica.crearJuguete(tipo, nombre, edad, material);

			// Muestra la información del juguete creado
			vista.mostrar("Juguete creado: " + juguete.describir());
			vista.mostrar("Categoría: " + juguete.categoria());

		} catch (IllegalArgumentException e) {
			// Maneja errores si el tipo de juguete no es válido
			vista.mostrar("Error: " + e.getMessage());
		}
	}
}