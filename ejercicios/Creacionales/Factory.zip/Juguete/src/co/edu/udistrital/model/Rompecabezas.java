package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juguete;

//Clase que representa un juguete tipo Rompecabezas
public class Rompecabezas extends Juguete {

	// Constructor que llama al constructor de la clase base
	public Rompecabezas(String nombre, int edad, String material) {
		super(nombre, edad, material);
	}

	// Retorna una descripción del juguete Rompecabezas
	@Override
	public String describir() {
		return "Rompecabezas '" + nombre + "' de " + material;
	}

	// Retorna la categoría del juguete
	@Override
	public String categoria() {
		return "Juego educativo";
	}
}