package co.edu.udistrital.model.abstracto;

//Clase abstracta que define la estructura base de cualquier juguete
public abstract class Juguete {
	// Atributos comunes para todos los juguetes
	protected String nombre;
	protected int edadRecomendada;
	protected String material;

	// Constructor que inicializa los atributos comunes
	public Juguete(String nombre, int edadRecomendada, String material) {
		this.nombre = nombre;
		this.edadRecomendada = edadRecomendada;
		this.material = material;
	}

	// Método abstracto para devolver una descripción del juguete
	public abstract String describir();

	// Método abstracto para devolver la categoría del juguete
	public abstract String categoria();
}
