package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {

    private Scanner scanner = new Scanner(System.in);

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine().trim();
    }

    public int leerEntero(String mensaje) {
        System.out.print(mensaje);
        return Integer.parseInt(scanner.nextLine().trim());
    }

    public void mostrar(String mensaje) {
        System.out.println(mensaje);
    }
}