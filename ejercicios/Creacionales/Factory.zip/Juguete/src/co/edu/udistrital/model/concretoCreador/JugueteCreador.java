package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.JugueteFactory;
import co.edu.udistrital.model.abstracto.Juguete;

//Implementación concreta de la fábrica de juguetes
public class JugueteCreador implements JugueteFactory {

	// Implementación del método para crear objetos de tipo Juguete
	@Override
	public Juguete crearJuguete(String tipo, String nombre, int edad, String material) {
		// Se evalúa el tipo ingresado para retornar el juguete correspondiente
		switch (tipo.toLowerCase()) {
		case "carro":
			return new Carro(nombre, edad, material);
		case "rompecabezas":
			return new Rompecabezas(nombre, edad, material);
		case "pelota":
			return new Pelota(nombre, edad, material);
		default:
			// Si el tipo no es válido, se lanza una excepción
			throw new IllegalArgumentException("Tipo de juguete no válido: " + tipo);
		}
	}
}