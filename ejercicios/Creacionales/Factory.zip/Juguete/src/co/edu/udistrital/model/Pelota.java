package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juguete;

//Clase que representa una Pelota
public class Pelota extends Juguete {

	// Constructor que llama al constructor de la clase base
	public Pelota(String nombre, int edad, String material) {
		super(nombre, edad, material);
	}

	// Retorna una descripción del juguete Pelota
	@Override
	public String describir() {
		return "Pelota '" + nombre + "' hecha de " + material;
	}

	// Retorna la categoría del juguete
	@Override
	public String categoria() {
		return "Deporte y recreación";
	}
}