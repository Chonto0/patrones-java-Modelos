package co.edu.udistrital.model.abstracto;

//Interfaz que define el método para crear juguetes
public interface JugueteFactory {
	// Método para crear un juguete dado su tipo, nombre, edad recomendada y
	// material
	Juguete crearJuguete(String tipo, String nombre, int edad, String material);
}