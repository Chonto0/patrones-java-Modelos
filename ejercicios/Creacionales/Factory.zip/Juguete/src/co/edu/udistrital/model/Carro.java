package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juguete;

//Clase que representa un juguete tipo Carro
public class Carro extends Juguete {

	// Constructor que llama al constructor de la clase base
	public Carro(String nombre, int edad, String material) {
		super(nombre, edad, material);
	}

	// Retorna una descripción del juguete carro
	@Override
	public String describir() {
		return "Carro de juguete modelo " + nombre + " fabricado en " + material;
	}

	// Retorna la categoría del juguete
	@Override
	public String categoria() {
		return "Vehículo de juguete";
	}
}