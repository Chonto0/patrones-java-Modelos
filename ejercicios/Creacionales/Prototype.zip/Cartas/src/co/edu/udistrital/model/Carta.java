package co.edu.udistrital.model;

public interface Carta {
    Carta clonar();
    String mostrarInformacion();
}
