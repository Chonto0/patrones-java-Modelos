package co.edu.udistrital.model;

public class CartaPersonaje implements Carta {
	private String nombre;
	private int poder;

	public CartaPersonaje(String nombre, int poder) {
		this.nombre = nombre;
		this.poder = poder;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setPoder(int poder) {
		this.poder = poder;
	}

	public String getNombre() {
		return nombre;
	}

	public int getPoder() {
		return poder;
	}

	@Override
	public Carta clonar() {
		return new CartaPersonaje(this.nombre, this.poder);
	}

	@Override
	public String mostrarInformacion() {
		return "Carta Personaje: " + nombre + " con poder de ataque: " + poder;
	}
}
