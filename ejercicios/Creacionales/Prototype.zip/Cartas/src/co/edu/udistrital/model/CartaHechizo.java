package co.edu.udistrital.model;

public class CartaHechizo implements Carta {
    private String hechizo;
    private int daño;

    public CartaHechizo(String hechizo, int daño) {
        this.hechizo = hechizo;
        this.daño = daño;
    }

    public void setHechizo(String hechizo) {
        this.hechizo = hechizo;
    }

    public void setDaño(int daño) {
        this.daño = daño;
    }

    public String getHechizo() {
        return hechizo;
    }

    public int getDaño() {
        return daño;
    }

    @Override
    public Carta clonar() {
        return new CartaHechizo(this.hechizo, this.daño);
    }

    @Override
    public String mostrarInformacion() {
        return "Carta Hechizo: " + hechizo + " con daño de " + daño;
    }
}
