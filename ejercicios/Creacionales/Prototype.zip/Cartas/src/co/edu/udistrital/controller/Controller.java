package co.edu.udistrital.controller;

import co.edu.udistrital.model.Carta;
import co.edu.udistrital.model.CartaPersonaje;
import co.edu.udistrital.model.CartaHechizo;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        // CARTA PERSONAJE
        CartaPersonaje personajeOriginal = new CartaPersonaje("Guerrero", 15);
        vista.mostrarInformacion("Carta original del personaje:");
        vista.mostrarInformacion(personajeOriginal.mostrarInformacion());

        Carta personajeClonada = personajeOriginal.clonar();
        ((CartaPersonaje) personajeClonada).setNombre("Guerrero Clon");
        ((CartaPersonaje) personajeClonada).setPoder(10);
        vista.mostrarInformacion("Carta clonada del personaje:");
        vista.mostrarInformacion(personajeClonada.mostrarInformacion());

        // CARTA HECHIZO
        CartaHechizo hechizoOriginal = new CartaHechizo("Fuego", 25);
        vista.mostrarInformacion("Carta original del hechizo:");
        vista.mostrarInformacion(hechizoOriginal.mostrarInformacion());

        Carta hechizoClonada = hechizoOriginal.clonar();
        ((CartaHechizo) hechizoClonada).setHechizo("Rayo");
        ((CartaHechizo) hechizoClonada).setDaño(30);
        vista.mostrarInformacion("Carta clonada del hechizo:");
        vista.mostrarInformacion(hechizoClonada.mostrarInformacion());
    }
}
