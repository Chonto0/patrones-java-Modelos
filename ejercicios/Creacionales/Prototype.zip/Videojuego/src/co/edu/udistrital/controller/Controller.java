package co.edu.udistrital.controller;

import co.edu.udistrital.model.Animal;
import co.edu.udistrital.model.Arbol;
import co.edu.udistrital.model.Casa;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		// Crear un árbol original
		Arbol a1 = new Arbol("Roble", 12.5);
		vista.mostrarInformacion("Árbol original: " + a1.toString());

		// Clonar el árbol y modificar sus atributos
		Arbol a2 = (Arbol) a1.clonar();
		a2.setTipo("Cedro");
		a2.setAltura(9.8);
		vista.mostrarInformacion("Árbol clonado y cambiado: " + a2.toString());
		vista.mostrarInformacion("Árbol original: " + a1.toString());

		// Crear una casa original y clonarla
		Casa c1 = new Casa("Madera", 4);
		vista.mostrarInformacion("Casa original: " + c1.toString());

		Casa c2 = (Casa) c1.clonar();
		c2.setMaterial("Ladrillo");
		c2.setHabitaciones(6);
		vista.mostrarInformacion("Casa clonada: " + c2.toString());

		// Crear un animal original y clonarlo
		Animal an1 = new Animal("Lobo gris");
		Animal an2 = (Animal) an1.clonar();
		an2.setEspecie("Oso pardo");

		vista.mostrarInformacion("Animal original: " + an1.toString());
		vista.mostrarInformacion("Animal clonado: " + an2.toString());
	}
}