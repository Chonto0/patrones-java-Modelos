package co.edu.udistrital.model;

//Clase que representa una casa y también se puede clonar
public class Casa implements Mapa {
	private String material;
	private int habitaciones; // Cantidad de habitaciones

	// Constructor con material y número de habitaciones
	public Casa(String material, int habitaciones) {
		this.material = material;
		this.habitaciones = habitaciones;
	}

	// Métodos getter y setter
	public void setMaterial(String material) {
		this.material = material;
	}

	public void setHabitaciones(int habitaciones) {
		this.habitaciones = habitaciones;
	}

	public String getMaterial() {
		return material;
	}

	public int getHabitaciones() {
		return habitaciones;
	}

	// Clona la casa actual
	@Override
	public Mapa clonar() {
		return new Casa(this.material, this.habitaciones);
	}

	@Override
	public String toString() {
		return "Casa [material=" + material + ", habitaciones=" + habitaciones + "]";
	}
}
