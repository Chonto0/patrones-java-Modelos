package co.edu.udistrital.model;

//Interfaz que define un contrato para clases que pueden clonarse
public interface Mapa {
 Mapa clonar(); // Método para clonar objetos que implementen esta interfaz
}