package co.edu.udistrital.model;

//Clase que representa un árbol y puede ser clonado
public class Arbol implements Mapa {
	private String tipo;
	private double altura; // Altura en metros

	// Constructor con parámetros
	public Arbol(String tipo, double altura) {
		this.tipo = tipo;
		this.altura = altura;
	}

	// Métodos getter y setter
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public String getTipo() {
		return tipo;
	}

	public double getAltura() {
		return altura;
	}

	// Clona el árbol (nuevo objeto con los mismos atributos)
	@Override
	public Mapa clonar() {
		return new Arbol(this.tipo, this.altura);
	}

	@Override
	public String toString() {
		return "Árbol [tipo=" + tipo + ", altura=" + altura + "m]";
	}
}
