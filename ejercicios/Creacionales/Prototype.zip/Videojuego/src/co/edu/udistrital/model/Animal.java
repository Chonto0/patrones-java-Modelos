package co.edu.udistrital.model;

//Clase que representa un animal y puede ser clonada (implementa Mapa)
public class Animal implements Mapa {
	private String especie;

	// Constructor para inicializar la especie
	public Animal(String especie) {
		this.especie = especie;
	}

	// Métodos getter y setter
	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public String getEspecie() {
		return especie;
	}

	// Implementación del método clonar: retorna un nuevo objeto Animal con la misma
	// especie
	@Override
	public Mapa clonar() {
		return new Animal(this.especie);
	}

	// Representación textual del objeto
	@Override
	public String toString() {
		return "Animal [especie=" + especie + "]";
	}
}
