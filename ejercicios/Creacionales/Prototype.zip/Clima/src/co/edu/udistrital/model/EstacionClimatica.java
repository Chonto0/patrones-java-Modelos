package co.edu.udistrital.model;

public class EstacionClimatica {

	private String nombre;
	private String descripcion;
	private int temperatura;

	// Constructor que inicializa los atributos de la estación
	public EstacionClimatica(String nombre, String descripcion, int temperatura) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.temperatura = temperatura;
	}

	// Métodos set: permiten modificar los atributos después de la creación
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setTemperatura(int temperatura) {
		this.temperatura = temperatura;
	}

	// Métodos get: permiten acceder a los valores de los atributos
	public String getNombre() {
		return nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public int getTemperatura() {
		return temperatura;
	}

	// Método que retorna una cadena con la información resumida de la estación
	public String getInfo() {
		return "Estación: " + nombre + " | Temp: " + temperatura + "°C | " + descripcion;
	}
}