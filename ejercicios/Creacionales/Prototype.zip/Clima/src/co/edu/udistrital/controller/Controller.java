package co.edu.udistrital.controller;

import co.edu.udistrital.model.EstacionClimatica;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {

		// Se crea una estación original con nombre, descripción y temperatura
		EstacionClimatica base = new EstacionClimatica("Estación Base", "Clima neutro", 25);
		vista.mostrarInformacion("Estación original:");
		vista.mostrarInformacion(base.getInfo());

		// Se asigna la referencia de 'base' a 'copia'. Ambas apuntan al mismo objeto
		EstacionClimatica copia = base;
		vista.mostrarInformacion("Copia de la estación:");
		vista.mostrarInformacion(copia.getInfo());

		// Se modifican los valores a través de la referencia 'copia'
		copia.setNombre("Estación Modificada");
		copia.setDescripcion("Clima húmedo y cálido");
		copia.setTemperatura(30);

		// Como 'base' y 'copia' apuntan al mismo objeto, ambos muestran los mismos
		// cambios
		vista.mostrarInformacion("\nDespués de modificar la copia:");
		vista.mostrarInformacion("Estación original:");
		vista.mostrarInformacion(base.getInfo());
		vista.mostrarInformacion("Estación copia:");
		vista.mostrarInformacion(copia.getInfo());
	}
}
