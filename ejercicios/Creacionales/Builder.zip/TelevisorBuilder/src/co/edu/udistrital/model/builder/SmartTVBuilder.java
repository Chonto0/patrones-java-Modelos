package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Televisor;
import co.edu.udistrital.model.TelevisorBuilder;

// Builder concreto que construye un televisor Smart TV
public class SmartTVBuilder implements TelevisorBuilder {
	private Televisor televisor = new Televisor();

	public void construirPantalla() {
		televisor.setPantalla("OLED 55\"");
	}

	public void construirResolucion() {
		televisor.setResolucion("4K UHD");
	}

	public void construirSistemaSonido() {
		televisor.setSistemaSonido("Dolby Atmos");
	}

	public void construirConectividad() {
		televisor.setConectividad("Wi-Fi, Bluetooth, HDMI 2.1");
	}

	public Televisor obtenerTelevisor() {
		return televisor;
	}
}
