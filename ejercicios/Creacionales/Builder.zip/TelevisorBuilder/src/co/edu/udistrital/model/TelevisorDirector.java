package co.edu.udistrital.model;

// Clase Director: orquesta la construcción de un televisor usando un builder
public class TelevisorDirector {
	private TelevisorBuilder builder;

	// Se recibe un builder concreto en el constructor
	public TelevisorDirector(TelevisorBuilder builder) {
		this.builder = builder;
	}

	// Método que construye el televisor paso a paso
	public Televisor construirTelevisor() {
		builder.construirPantalla();
		builder.construirResolucion();
		builder.construirSistemaSonido();
		builder.construirConectividad();
		return builder.obtenerTelevisor();
	}
}
