package co.edu.udistrital.model;

// Interfaz Builder: define los pasos para construir un televisor
public interface TelevisorBuilder {
	void construirPantalla();

	void construirResolucion();

	void construirSistemaSonido();

	void construirConectividad();

	// Devuelve el producto final
	Televisor obtenerTelevisor();
}
