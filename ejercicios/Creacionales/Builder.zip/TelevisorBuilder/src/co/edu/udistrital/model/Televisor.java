package co.edu.udistrital.model;

//Clase que representa un producto complejo: un televisor
public class Televisor {
	private String pantalla;
	private String resolucion;
	private String sistemaSonido;
	private String conectividad;

	// Métodos setters para configurar las partes del televisor
	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}

	public void setResolucion(String resolucion) {
		this.resolucion = resolucion;
	}

	public void setSistemaSonido(String sistemaSonido) {
		this.sistemaSonido = sistemaSonido;
	}

	public void setConectividad(String conectividad) {
		this.conectividad = conectividad;
	}

	// Método que devuelve una descripción del televisor
	public String especificaciones() {
		return "Pantalla: " + pantalla + "\nResolución: " + resolucion + "\nSistema de Sonido: " + sistemaSonido
				+ "\nConectividad: " + conectividad;
	}
}
