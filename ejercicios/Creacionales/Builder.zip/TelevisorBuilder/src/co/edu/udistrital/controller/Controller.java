package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.builder.LEDTVBuilder;
import co.edu.udistrital.model.builder.SmartTVBuilder;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido a la tienda de televisores");
		vista.mostrarInformacion("1. Smart TV\n2. LED TV");

		// Lee la opción del usuario
		int opcion = vista.leerDatoEntero("Seleccione el tipo de televisor: ");

		// Selecciona el builder correspondiente usando switch expression
		TelevisorBuilder builder = switch (opcion) {
		case 1 -> new SmartTVBuilder();
		case 2 -> new LEDTVBuilder();
		default -> {
			vista.mostrarInformacion("Opción inválida.");
			yield null;
		}
		};

		// Si la opción es válida, se construye el televisor y se muestran sus
		// especificaciones
		if (builder != null) {
			TelevisorDirector director = new TelevisorDirector(builder);
			Televisor televisor = director.construirTelevisor();
			vista.mostrarInformacion("Especificaciones del televisor:");
			vista.mostrarInformacion(televisor.especificaciones());
		}
	}
}