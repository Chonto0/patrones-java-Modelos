package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Televisor;
import co.edu.udistrital.model.TelevisorBuilder;

// Builder concreto que construye un televisor LED
public class LEDTVBuilder implements TelevisorBuilder {
	private Televisor televisor = new Televisor();

	public void construirPantalla() {
		televisor.setPantalla("LED 42\"");
	}

	public void construirResolucion() {
		televisor.setResolucion("Full HD");
	}

	public void construirSistemaSonido() {
		televisor.setSistemaSonido("Stereo");
	}

	public void construirConectividad() {
		televisor.setConectividad("HDMI, USB");
	}

	public Televisor obtenerTelevisor() {
		return televisor;
	}
}
