package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.builder.VueloInternacionalBuilder;
import co.edu.udistrital.model.builder.VueloNacionalBuilder;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido a la aerolínea");
		vista.mostrarInformacion("1. Vuelo Internacional\n2. Vuelo Nacional");

		int opcion = vista.leerDatoEntero("Seleccione el tipo de vuelo: ");

		// Selecciona el builder adecuado según la opción del usuario
		VueloBuilder builder = switch (opcion) {
		case 1 -> new VueloInternacionalBuilder();
		case 2 -> new VueloNacionalBuilder();
		default -> {
			vista.mostrarInformacion("Opción inválida.");
			yield null;
		}
		};

		// Si se eligió una opción válida, se construye y muestra el vuelo
		if (builder != null) {
			VueloDirector director = new VueloDirector(builder);
			Vuelo vuelo = director.construirVuelo();
			vista.mostrarInformacion("Especificaciones del vuelo:");
			vista.mostrarInformacion(vuelo.especificaciones());
		}
	}
}