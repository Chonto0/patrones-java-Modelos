package co.edu.udistrital.model;

public class Vuelo {
	// Atributos del vuelo
	private String destino;
	private String aeropuertoSalida;
	private String tipoAvion;
	private String horaSalida;

	// Métodos setter para establecer los valores del vuelo
	public void setDestino(String destino) {
		this.destino = destino;
	}

	public void setAeropuertoSalida(String aeropuertoSalida) {
		this.aeropuertoSalida = aeropuertoSalida;
	}

	public void setTipoAvion(String tipoAvion) {
		this.tipoAvion = tipoAvion;
	}

	public void setHoraSalida(String horaSalida) {
		this.horaSalida = horaSalida;
	}

	// Método que devuelve las especificaciones completas del vuelo en formato de
	// texto
	public String especificaciones() {
		return "Destino: " + destino + "\nAeropuerto de salida: " + aeropuertoSalida + "\nTipo de avión: " + tipoAvion
				+ "\nHora de salida: " + horaSalida;
	}
}
