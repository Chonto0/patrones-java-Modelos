package co.edu.udistrital.model;

// Clase que dirige el proceso de construcción de un vuelo usando un builder específico
public class VueloDirector {
	private VueloBuilder builder;

	// Constructor que recibe el builder que se usará para construir el vuelo
	public VueloDirector(VueloBuilder builder) {
		this.builder = builder;
	}

	// Construye el vuelo paso a paso, delegando al builder
	public Vuelo construirVuelo() {
		builder.construirDestino();
		builder.construirAeropuertoSalida();
		builder.construirTipoAvion();
		builder.construirHoraSalida();
		return builder.obtenerVuelo(); // Retorna el objeto construido
	}
}
