package co.edu.udistrital.model;

// Interfaz que define los pasos necesarios para construir un objeto Vuelo
public interface VueloBuilder {

	void construirDestino();

	void construirAeropuertoSalida();

	void construirTipoAvion();

	void construirHoraSalida();

	// Devuelve el vuelo ya construido
	Vuelo obtenerVuelo();
}
