package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.Vuelo;
import co.edu.udistrital.model.VueloBuilder;

// Builder concreto que construye un vuelo nacional
public class VueloNacionalBuilder implements VueloBuilder {
	private Vuelo vuelo = new Vuelo(); // Instancia del vuelo a construir

	public void construirDestino() {
		vuelo.setDestino("Medellín");
	}

	public void construirAeropuertoSalida() {
		vuelo.setAeropuertoSalida("Aeropuerto Internacional El Dorado");
	}

	public void construirTipoAvion() {
		vuelo.setTipoAvion("Airbus A320");
	}

	public void construirHoraSalida() {
		vuelo.setHoraSalida("10:30");
	}

	public Vuelo obtenerVuelo() {
		return vuelo; // Devuelve el vuelo nacional configurado
	}
}
