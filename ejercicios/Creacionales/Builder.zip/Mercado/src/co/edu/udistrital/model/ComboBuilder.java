package co.edu.udistrital.model;

public interface ComboBuilder {
    void construirHamburguesa();
    void construirPapas();
    void construirBebida();
    void construirPostre();
    Combo obtenerCombo();
}
