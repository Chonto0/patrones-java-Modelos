package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.*;

public class ComboPremiumBuilder implements ComboBuilder {
    private Combo combo = new Combo();

    public void construirHamburguesa() { combo.setHamburguesa("Angus Deluxe"); }
    public void construirPapas() { combo.setPapas("Papas grandes"); }
    public void construirBebida() { combo.setBebida("Malteada de chocolate"); }
    public void construirPostre() { combo.setPostre("McFlurry"); }

    public Combo obtenerCombo() {
        return combo;
    }
}
