package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.*;

public class ComboInfantilBuilder implements ComboBuilder {
    private Combo combo = new Combo();

    public void construirHamburguesa() { combo.setHamburguesa("Hamburguesa infantil"); }
    public void construirPapas() { combo.setPapas("Papas pequeñas"); }
    public void construirBebida() { combo.setBebida("Jugo de manzana"); }
    public void construirPostre() { combo.setPostre("Juguete"); }

    public Combo obtenerCombo() {
        return combo;
    }
}
