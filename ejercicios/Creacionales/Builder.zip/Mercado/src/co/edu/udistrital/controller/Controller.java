package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.builder.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido a McDonald's");
		vista.mostrarInformacion("1. Combo Infantil\n2. Combo Clásico\n3. Combo Premium");

		// Lee la opción del usuario
		int opcion = vista.leerDatoEntero("Seleccione su combo: ");

		// Selecciona el builder correspondiente según la opción
		ComboBuilder builder = switch (opcion) {
		case 1 -> new ComboInfantilBuilder();
		case 2 -> new ComboClasicoBuilder();
		case 3 -> new ComboPremiumBuilder();
		default -> {
			vista.mostrarInformacion("Opción inválida.");
			yield null;
		}
		};

		// Si la opción es válida, se construye y muestra el combo
		if (builder != null) {
			ComboDirector director = new ComboDirector(builder);
			Combo combo = director.construirCombo();
			vista.mostrarInformacion("Tu combo contiene:");
			vista.mostrarInformacion(combo.mostrarContenido());
		}
	}
}