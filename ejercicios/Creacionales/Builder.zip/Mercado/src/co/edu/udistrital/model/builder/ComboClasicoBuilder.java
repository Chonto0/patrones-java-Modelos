package co.edu.udistrital.model.builder;

import co.edu.udistrital.model.*;

public class ComboClasicoBuilder implements ComboBuilder {
    private Combo combo = new Combo();

    public void construirHamburguesa() { combo.setHamburguesa("Big Mac"); }
    public void construirPapas() { combo.setPapas("Papas medianas"); }
    public void construirBebida() { combo.setBebida("Coca-Cola"); }
    public void construirPostre() { combo.setPostre("Sundae de vainilla"); }

    public Combo obtenerCombo() {
        return combo;
    }
}
