package co.edu.udistrital.model;

public class ComboDirector {
	private ComboBuilder builder;

	// Se recibe un builder específico (infantil, clásico o premium)
	public ComboDirector(ComboBuilder builder) {
		this.builder = builder;
	}

	// Construye el combo llamando a todos los pasos definidos en la interfaz
	public Combo construirCombo() {
		builder.construirHamburguesa();
		builder.construirPapas();
		builder.construirBebida();
		builder.construirPostre();
		return builder.obtenerCombo(); // Devuelve el combo final
	}
}