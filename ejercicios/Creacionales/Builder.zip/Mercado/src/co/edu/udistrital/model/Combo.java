package co.edu.udistrital.model;

public class Combo {
	private String hamburguesa;
	private String papas;
	private String bebida;
	private String postre;

	// Métodos para establecer los componentes del combo
	public void setHamburguesa(String hamburguesa) {
		this.hamburguesa = hamburguesa;
	}

	public void setPapas(String papas) {
		this.papas = papas;
	}

	public void setBebida(String bebida) {
		this.bebida = bebida;
	}

	public void setPostre(String postre) {
		this.postre = postre;
	}

	// Devuelve el contenido del combo en forma de cadena
	public String mostrarContenido() {
		return "\nHamburguesa: " + hamburguesa + "\nPapas: " + papas + "\nBebida: " + bebida + "\nPostre: " + postre;
	}
}