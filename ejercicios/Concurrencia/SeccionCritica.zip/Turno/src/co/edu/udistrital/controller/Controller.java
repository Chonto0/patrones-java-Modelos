package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private GestorTurnos gestor;

	public Controller() {
		vista = new VistaConsola();
		gestor = new GestorTurnos();
	}

	public void run() {
		synchronized (vista) {
			vista.mostrarInformacion("=== CONSULTORIO MÉDICO EN LÍNEA ===");
		}

		Thread[] hilos = new Thread[3];

		for (int i = 0; i < 3; i++) {
			hilos[i] = nuevoHiloReserva();
			hilos[i].start();
		}

		for (Thread hilo : hilos) {
			try {
				hilo.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		synchronized (vista) {
			vista.mostrarInformacion(">>> RESUMEN FINAL DE TURNOS:");
			for (Turno t : gestor.obtenerTurnos()) {
				String mensaje = "Turno " + t.getId() + ": ";
				mensaje += t.estaReservado() ? "Reservado por " + t.getPaciente() : "Disponible";
				vista.mostrarInformacion(mensaje);
			}
			vista.mostrarInformacion(">>> Fin del proceso de asignación de turnos.");
		}
	}

	private Thread nuevoHiloReserva() {
		return new Thread(() -> {
			String nombre;
			synchronized (vista) {
				nombre = vista.leerCadenaTexto("Ingrese nombre del paciente:");
			}

			boolean exito = false;
			int idTurno;

			while (!exito) {
				idTurno = leerIdTurnoValido();

				exito = gestor.reservarTurno(idTurno, nombre);

				synchronized (vista) {
					if (exito) {
						vista.mostrarInformacion("Turno " + idTurno + " reservado exitosamente por " + nombre);
					} else {
						vista.mostrarInformacion(
								"El turno " + idTurno + " ya está reservado. " + nombre + ", intente otro.");
					}
				}
			}
		});
	}

	private int leerIdTurnoValido() {
		int idTurno = -1;
		boolean valido = false;

		while (!valido) {
			try {
				synchronized (vista) {
					idTurno = vista.leerDatoEntero("Ingrese ID del turno a reservar (1-5):");
				}
				if (idTurno >= 1 && idTurno <= 5) {
					valido = true;
				} else {
					synchronized (vista) {
						vista.mostrarInformacion("El ID debe estar entre 1 y 5. Inténtelo de nuevo.");
					}
				}
			} catch (Exception e) {
				synchronized (vista) {
					vista.mostrarInformacion("Entrada inválida. Debe ingresar un número entero.");
				}
			}
		}

		return idTurno;
	}
}
