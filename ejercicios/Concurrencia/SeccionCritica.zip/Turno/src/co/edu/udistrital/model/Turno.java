package co.edu.udistrital.model;

public class Turno {
	private int id;
	private boolean reservado;
	private String paciente;

	public Turno(int id) {
		this.id = id;
		this.reservado = false;
		this.paciente = "";
	}

	public int getId() {
		return id;
	}

	public boolean estaReservado() {
		return reservado;
	}

	public String getPaciente() {
		return paciente;
	}

	public void reservar(String paciente) {
		this.reservado = true;
		this.paciente = paciente;
	}
}
