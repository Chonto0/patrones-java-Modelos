package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class GestorTurnos {
	private List<Turno> turnos;

	public GestorTurnos() {
		turnos = new ArrayList<>();
		for (int i = 1; i <= 5; i++) {
			turnos.add(new Turno(i));
		}
	}

	public synchronized boolean reservarTurno(int id, String paciente) {
		for (Turno t : turnos) {
			if (t.getId() == id && !t.estaReservado()) {
				t.reservar(paciente);
				return true;
			}
		}
		return false;
	}

	public List<Turno> obtenerTurnos() {
		return turnos;
	}
}
