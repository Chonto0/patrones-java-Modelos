package co.edu.udistrital.model;

public class Asiento {
    private int numero;
    private boolean reservado;

    public Asiento(int numero) {
        this.numero = numero;
        this.reservado = false;
    }

    public int getNumero() {
        return numero;
    }

    public synchronized boolean reservar() {
        if (!reservado) {
            reservado = true;
            return true;
        } else {
            return false;
        }
    }

    public boolean estaReservado() {
        return reservado;
    }
}
