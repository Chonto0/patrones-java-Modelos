package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;
    private Vuelo vuelo;

    public Controller() {
        vista = new VistaConsola();
        vuelo = new Vuelo(10); 
    }

    public void run() {
        boolean continuar = true;
        vista.mostrarInformacion("=== SISTEMA DE COMPRA DE TIQUETES ===");

        while (continuar) {
            mostrarAsientos();
            int seleccion = vista.leerDatoEntero("Ingrese el número de asiento que desea reservar (0 para salir):");

            if (seleccion == 0) {
                continuar = false;
                vista.mostrarInformacion("Gracias por usar el sistema.");
            } else {
                Asiento asiento = vuelo.obtenerAsiento(seleccion);
                if (asiento == null) {
                    vista.mostrarInformacion("Número de asiento inválido.");
                } else {

                    boolean reservado = asiento.reservar();
                    if (reservado) {
                        vista.mostrarInformacion("!!! Asiento " + seleccion + " reservado exitosamente.");
                    } else {
                        vista.mostrarInformacion("X El asiento " + seleccion + " ya está reservado.");
                    }
                }
            }
        }
    }

    private void mostrarAsientos() {
        StringBuilder sb = new StringBuilder("Asientos disponibles: ");
        for (Asiento a : vuelo.getAsientos()) {
            sb.append(a.getNumero());
            if (a.estaReservado()) {
                sb.append("[X] ");
            } else {
                sb.append("[ ] ");
            }
        }
        vista.mostrarInformacion(sb.toString());
    }
}
