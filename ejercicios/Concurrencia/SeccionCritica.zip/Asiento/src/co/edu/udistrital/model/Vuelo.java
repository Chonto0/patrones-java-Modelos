package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Vuelo {
    private List<Asiento> asientos;

    public Vuelo(int cantidadAsientos) {
        asientos = new ArrayList<>();
        for (int i = 1; i <= cantidadAsientos; i++) {
            asientos.add(new Asiento(i));
        }
    }

    public Asiento obtenerAsiento(int numero) {
        if (numero > 0 && numero <= asientos.size()) {
            return asientos.get(numero - 1);
        }
        return null;
    }

    public List<Asiento> getAsientos() {
        return asientos;
    }
}
