package co.edu.udistrital.controller;

import co.edu.udistrital.model.GeneradorObjetos;
import co.edu.udistrital.model.Objeto;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("=== Generador Seguro de Objetos ===");

        while (true) {
            String nombre = vista.leerCadenaTexto("Ingrese el nombre del objeto (o 'salir'):");

            if (nombre == null || nombre.trim().isEmpty()) {
                vista.mostrarInformacion("El nombre no puede estar vacío.");
                continue;
            }

            if (nombre.equalsIgnoreCase("salir")) {
                vista.mostrarInformacion(GeneradorObjetos.obtenerResumen());
                break;
            }

            Objeto obj = GeneradorObjetos.obtenerObjeto(nombre.trim());
            vista.mostrarInformacion("Objeto generado con nombre: " + obj.getNombre());
        }
    }
}
