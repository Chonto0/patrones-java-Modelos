package co.edu.udistrital.model;

import java.util.HashMap;
import java.util.Map;

public class GeneradorObjetos {

	private static Map<String, Objeto> objetos = new HashMap<>();

	public static Objeto obtenerObjeto(String nombreOriginal) {
		String clave = nombreOriginal.trim().toLowerCase();
		synchronized (GeneradorObjetos.class) {
			if (!objetos.containsKey(clave)) {
				objetos.put(clave, new Objeto(nombreOriginal.trim()));
			}
			return objetos.get(clave);
		}
	}

	public static String obtenerResumen() {
		synchronized (GeneradorObjetos.class) {
			int cantidad = objetos.size();
			return "Se crearon " + cantidad + " objeto" + (cantidad == 1 ? "" : "s") + " único"
					+ (cantidad == 1 ? "." : "s.");
		}
	}
}
