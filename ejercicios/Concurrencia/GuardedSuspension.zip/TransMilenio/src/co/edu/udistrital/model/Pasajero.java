package co.edu.udistrital.model;

public class Pasajero extends Thread {

    private final String nombre;
    private final TransMilenio bus;
    private final PasajeroCallback callback;

    public interface PasajeroCallback {
        void informar(String mensaje);
    }

    public Pasajero(String nombre, TransMilenio bus, PasajeroCallback callback) {
        this.nombre = nombre;
        this.bus = bus;
        this.callback = callback;
    }

    @Override
    public void run() {
        callback.informar("[" + java.time.LocalTime.now().withNano(0) + "] " + nombre + " intenta subirse al TransMilenio...");

        boolean subio = bus.intentarSubir(nombre, callback);

        if (subio) {
            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            bus.bajar(nombre, callback);
        } else {
            callback.informar("[" + java.time.LocalTime.now().withNano(0) + "] " + nombre + " fue interrumpido y no se subió.");
        }
    }
}
