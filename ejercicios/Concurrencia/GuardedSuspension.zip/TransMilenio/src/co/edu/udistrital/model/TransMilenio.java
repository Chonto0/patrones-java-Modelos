package co.edu.udistrital.model;

public class TransMilenio {

    private final int capacidadMaxima;
    private int pasajerosActuales = 0;

    public TransMilenio(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public synchronized boolean intentarSubir(String nombre, Pasajero.PasajeroCallback callback) {
        long inicioEspera = System.currentTimeMillis();

        if (pasajerosActuales >= capacidadMaxima) {
            callback.informar(timestamp() + " " + nombre + " está esperando. Ocupación llena: " +
                    pasajerosActuales + "/" + capacidadMaxima);
        }

        while (pasajerosActuales >= capacidadMaxima) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }

        long finEspera = System.currentTimeMillis();
        long tiempoEspera = finEspera - inicioEspera;

        pasajerosActuales++;

        if (tiempoEspera > 0) {
            callback.informar(timestamp() + " " + nombre + " subió después de esperar " +
                    tiempoEspera + " ms. Ocupación: " + pasajerosActuales + "/" + capacidadMaxima);
        } else {
            callback.informar(timestamp() + " " + nombre + " subió al TransMilenio. Ocupación: " +
                    pasajerosActuales + "/" + capacidadMaxima);
        }

        return true;
    }

    public synchronized void bajar(String nombre, Pasajero.PasajeroCallback callback) {
        pasajerosActuales--;
        callback.informar(timestamp() + " " + nombre + " se bajó del TransMilenio. Espacios disponibles: " +
                (capacidadMaxima - pasajerosActuales));
        notify(); 
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    private String timestamp() {
        return "[" + java.time.LocalTime.now().withNano(0) + "]";
    }
}
