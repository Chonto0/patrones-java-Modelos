package co.edu.udistrital.controller;

import co.edu.udistrital.model.Pasajero;
import co.edu.udistrital.model.TransMilenio;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private TransMilenio bus;

	public Controller() {
		vista = new VistaConsola();
		int capacidad = vista.leerDatoEntero("Ingrese la capacidad del TransMilenio:");
		bus = new TransMilenio(capacidad);
	}

	public void run() {
		int cantidadPasajeros = vista.leerDatoEntero("Ingrese el número de pasajeros:");

		for (int i = 1; i <= cantidadPasajeros; i++) {
			String nombre = "Pasajero" + i;

			Pasajero pasajero = new Pasajero(nombre, bus, mensaje -> {
				synchronized (vista) {
					vista.mostrarInformacion(mensaje);
				}
			});

			pasajero.start();

			try {
				Thread.sleep(50); 
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}
	}
}
