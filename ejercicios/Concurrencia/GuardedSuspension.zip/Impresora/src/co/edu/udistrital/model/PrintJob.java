package co.edu.udistrital.model;

public class PrintJob extends Thread {
	private int turno;
	private String documento;
	private ColaImpresion cola;
	private PrintCallback callback;

	public PrintJob(int turno, String documento, ColaImpresion cola, PrintCallback callback) {
		this.turno = turno;
		this.documento = documento;
		this.cola = cola;
		this.callback = callback;
	}

	@Override
	public void run() {
		cola.imprimir(turno, documento, callback);
	}
}
