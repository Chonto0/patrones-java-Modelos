package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.ColaImpresion;
import co.edu.udistrital.model.PrintCallback;
import co.edu.udistrital.model.PrintJob;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private ColaImpresion cola;

	public Controller() {
		vista = new VistaConsola();
		cola = new ColaImpresion();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido al sistema de impresión.");
		int n = vista.leerDatoEntero("¿Cuántos documentos desea imprimir?");

		List<PrintJob> trabajos = new ArrayList<>();

		PrintCallback callback = mensaje -> vista.mostrarInformacion(mensaje);

		for (int i = 1; i <= n; i++) {
			String doc = vista.leerCadenaTexto("Ingrese el nombre del documento #" + i + ":");
			PrintJob job = new PrintJob(i, doc, cola, callback);
			trabajos.add(job);
		}

		vista.mostrarInformacion("\nIniciando cola de impresión...\n");

		for (PrintJob trabajo : trabajos) {
			trabajo.start();
		}
	}
}
