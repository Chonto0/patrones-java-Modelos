package co.edu.udistrital.model;

@FunctionalInterface
public interface PrintCallback {
	void notificar(String mensaje);
}
