package co.edu.udistrital.model;

public class ColaImpresion {

	private int turnoActual = 1;

	public synchronized void imprimir(int turno, String documento, PrintCallback callback) {
		while (turno != turnoActual) {
			try {
				wait();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
			}
		}

		callback.notificar("Imprimiendo documento: " + documento + " [Turno: " + turno + "]");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
		callback.notificar("Documento impreso: " + documento);

		turnoActual++;
		notifyAll();
	}
}
