package co.edu.udistrital.controller;

import co.edu.udistrital.model.Ascensor;
import co.edu.udistrital.view.VistaConsola;

import java.util.List;

public class Controller {

	private VistaConsola vista;
	private Ascensor ascensor;

	public Controller() {
		vista = new VistaConsola();
		ascensor = new Ascensor();
	}

	public void run() {
		boolean continuar = true;

		while (continuar) {
			int pisoDestino = vista.leerDatoEntero("Ingrese el piso al que desea ir (0-10): ");

			Thread hiloMovimiento = new Thread(() -> {
				List<String> mensajes = ascensor.moverAlPiso(pisoDestino);
				for (String mensaje : mensajes) {
					vista.mostrarInformacion(mensaje);
				}
			});

			Thread hiloPuertas = new Thread(() -> {
				String mensajePuerta = ascensor.abrirPuertas();
				vista.mostrarInformacion(mensajePuerta);
			});

			hiloMovimiento.start();
			hiloPuertas.start();

			try {
				hiloMovimiento.join();
				hiloPuertas.join();
			} catch (InterruptedException e) {
				vista.mostrarInformacion("Error en los hilos: " + e.getMessage());
			}

			String respuesta = vista.leerCadenaTexto("¿Desea ir a otro piso? (s/n): ");
			continuar = respuesta.equalsIgnoreCase("s");
		}

		vista.mostrarInformacion("Programa finalizado.");
	}
}
