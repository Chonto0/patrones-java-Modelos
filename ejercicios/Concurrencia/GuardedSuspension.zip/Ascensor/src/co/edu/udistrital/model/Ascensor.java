package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

public class Ascensor {

    private int pisoActual = 0;
    private int pisoDestino = -1;
    private boolean enMovimiento = false;

    public synchronized List<String> moverAlPiso(int piso) {
        List<String> mensajes = new ArrayList<>();
        enMovimiento = true;
        pisoDestino = piso;

        mensajes.add("Ascensor en movimiento hacia el piso " + pisoDestino + "...");

        while (pisoActual != pisoDestino) {
            try {
                Thread.sleep(1000); 
                if (pisoActual < pisoDestino) {
                    pisoActual++;
                } else {
                    pisoActual--;
                }
                mensajes.add("Piso actual: " + pisoActual);
            } catch (InterruptedException e) {
                mensajes.add("Error durante el movimiento: " + e.getMessage());
            }
        }

        enMovimiento = false;
        notifyAll();
        return mensajes;
    }

    public synchronized String abrirPuertas() {
        while (enMovimiento || pisoActual != pisoDestino) {
            try {
                wait(); 
            } catch (InterruptedException e) {
                return "Error al intentar abrir puertas: " + e.getMessage();
            }
        }
        return "Puertas abiertas en el piso " + pisoActual;
    }

    public int getPisoActual() {
        return pisoActual;
    }
}
