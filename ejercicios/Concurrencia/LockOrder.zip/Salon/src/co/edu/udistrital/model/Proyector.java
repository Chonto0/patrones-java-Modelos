package co.edu.udistrital.model;

public class Proyector {
	private String nombre;

	public Proyector(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Proyector: " + nombre;
	}
}
