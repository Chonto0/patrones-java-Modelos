package co.edu.udistrital.model;

public class Salon {
	private String nombre;

	public Salon(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Salón: " + nombre;
	}
}
