package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private Salon salon;
	private Proyector proyector;
	private ReservaRecursos reserva;

	public Controller() {
		this.vista = new VistaConsola();
		this.salon = new Salon("Salón 101");
		this.proyector = new Proyector("Proyector A");
		this.reserva = new ReservaRecursos();
	}

	public void run() {
		vista.mostrarInformacion("=== SISTEMA DE RESERVA UNIVERSITARIA ===");

		Thread t1 = new Thread(() -> {
			String resultado = reserva.reservar(salon, proyector, "Usuario A");
			vista.mostrarInformacion(resultado); // La vista se usa aquí, en el controlador
		});

		Thread t2 = new Thread(() -> {
			String resultado = reserva.reservar(proyector, salon, "Usuario B");
			vista.mostrarInformacion(resultado);
		});

		t1.start();
		t2.start();

		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		vista.mostrarInformacion("Proceso de reserva finalizado.");
	}
}
