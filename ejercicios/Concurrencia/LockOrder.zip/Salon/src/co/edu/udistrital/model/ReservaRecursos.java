package co.edu.udistrital.model;

public class ReservaRecursos {

	public String reservar(Object recurso1, Object recurso2, String solicitante) {
		Object primerLock, segundoLock;

		int hash1 = System.identityHashCode(recurso1);
		int hash2 = System.identityHashCode(recurso2);

		if (hash1 < hash2) {
			primerLock = recurso1;
			segundoLock = recurso2;
		} else if (hash1 > hash2) {
			primerLock = recurso2;
			segundoLock = recurso1;
		} else {
			Object tieLock = new Object();
			synchronized (tieLock) {
				synchronized (recurso1) {
					synchronized (recurso2) {
						return "[" + solicitante + "] Recursos reservados (caso de empate).";
					}
				}
			}
		}

		synchronized (primerLock) {
			synchronized (segundoLock) {
				return "[" + solicitante + "] Reservó " + recurso1 + " y " + recurso2 + " exitosamente.";
			}
		}
	}
}
