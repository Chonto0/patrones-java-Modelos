package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		int cantidad = vista.leerDatoEntero("¿Cuántos vehículos desea simular?");
		List<Vehiculo> vehiculos = new ArrayList<>();
		List<Calle> calles = new ArrayList<>();

		for (int i = 0; i < cantidad * 2; i++) {
			String nombreCalle = vista.leerCadenaTexto("Ingrese nombre de la calle " + (i + 1) + ":");
			calles.add(new Calle(nombreCalle));
		}

		for (int i = 0; i < cantidad; i++) {
			String nombreVehiculo = vista.leerCadenaTexto("Ingrese nombre del vehículo " + (i + 1) + ":");
			Calle origen = calles.get(i);
			Calle destino = calles.get(i + cantidad);
			vehiculos.add(new Vehiculo(nombreVehiculo, origen, destino, vista));
		}

		for (Vehiculo v : vehiculos) {
			v.start();
		}

		for (Vehiculo v : vehiculos) {
			try {
				v.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		vista.mostrarInformacion("Simulación finalizada.");
	}
}
