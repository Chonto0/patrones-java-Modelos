package co.edu.udistrital.model;

public class Calle {
	private String nombre;

	public Calle(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}
}
