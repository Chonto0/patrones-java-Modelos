package co.edu.udistrital.view;

import java.util.Scanner;
import co.edu.udistrital.model.Notificador;

public class VistaConsola implements Notificador {

	private Scanner sc;

	public VistaConsola() {
		sc = new Scanner(System.in);
	}

	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}

	@Override
	public void notificar(String mensaje) {
		mostrarInformacion(mensaje);
	}

	public int leerDatoEntero(String mensaje) {
		System.out.println(mensaje);
		int dato = sc.nextInt();
		sc.nextLine();
		return dato;
	}

	public String leerCadenaTexto(String mensaje) {
		System.out.println(mensaje);
		return sc.nextLine();
	}
}
