package co.edu.udistrital.model;

public interface Notificador {
	void notificar(String mensaje);
}
