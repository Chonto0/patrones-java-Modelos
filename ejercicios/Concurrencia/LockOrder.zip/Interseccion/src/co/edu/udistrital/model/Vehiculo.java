package co.edu.udistrital.model;

public class Vehiculo extends Thread {

	private String nombre;
	private Calle calleOrigen;
	private Calle calleDestino;
	private Notificador notificador;

	public Vehiculo(String nombre, Calle origen, Calle destino, Notificador notificador) {
		this.nombre = nombre;
		this.calleOrigen = origen;
		this.calleDestino = destino;
		this.notificador = notificador;
	}

	@Override
	public void run() {
		cruzarInterseccion();
	}

	private void cruzarInterseccion() {
		Object lock1 = calleOrigen;
		Object lock2 = calleDestino;

		int hash1 = System.identityHashCode(lock1);
		int hash2 = System.identityHashCode(lock2);

		Object primero = (hash1 < hash2) ? lock1 : lock2;
		Object segundo = (hash1 < hash2) ? lock2 : lock1;

		notificador.notificar(nombre + " se acerca a la intersección desde " + calleOrigen.getNombre());

		synchronized (primero) {
			notificador.notificar(nombre + " obtuvo acceso a " + ((Calle) primero).getNombre());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			synchronized (segundo) {
				notificador.notificar(nombre + " obtuvo acceso a " + ((Calle) segundo).getNombre());
				notificador.notificar(nombre + " está cruzando la intersección...");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				notificador.notificar(nombre + " ha cruzado la intersección.");
			}
		}
	}
}
