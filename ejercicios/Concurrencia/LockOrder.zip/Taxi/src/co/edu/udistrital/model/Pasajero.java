package co.edu.udistrital.model;

public class Pasajero {
	private String nombre;

	public Pasajero(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Pasajero[" + nombre + "]";
	}
}
