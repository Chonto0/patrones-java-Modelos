package co.edu.udistrital.model;

public class Taxi {
	private String placa;

	public Taxi(String placa) {
		this.placa = placa;
	}

	public String getPlaca() {
		return placa;
	}

	@Override
	public String toString() {
		return "Taxi[" + placa + "]";
	}
}
