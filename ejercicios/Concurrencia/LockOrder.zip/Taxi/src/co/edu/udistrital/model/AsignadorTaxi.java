package co.edu.udistrital.model;

public class AsignadorTaxi {

    public String asignarTaxi(Pasajero pasajero, Taxi taxi) {
        Object primero, segundo;

        int hashPasajero = System.identityHashCode(pasajero);
        int hashTaxi = System.identityHashCode(taxi);

        if (hashPasajero < hashTaxi) {
            primero = pasajero;
            segundo = taxi;
        } else {
            primero = taxi;
            segundo = pasajero;
        }

        synchronized (primero) {
            synchronized (segundo) {
                return "*"+ taxi + " ha sido asignado a " + pasajero;
            }
        }
    }
}
