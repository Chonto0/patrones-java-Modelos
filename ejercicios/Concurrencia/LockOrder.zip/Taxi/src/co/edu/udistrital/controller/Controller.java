package co.edu.udistrital.controller;

import co.edu.udistrital.model.*;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	private AsignadorTaxi asignador;

	public Controller() {
		vista = new VistaConsola();
		asignador = new AsignadorTaxi();
	}

	public void run() {
		vista.mostrarInformacion("=== SISTEMA DE ASIGNACIÓN DE TAXIS ===");

		String nombrePasajero = vista.leerCadenaTexto("Ingrese el nombre del pasajero:");
		String placaTaxi = vista.leerCadenaTexto("Ingrese la placa del taxi:");

		Pasajero pasajero = new Pasajero(nombrePasajero);
		Taxi taxi = new Taxi(placaTaxi);

		Thread hilo1 = new Thread(() -> {
			String resultado = asignador.asignarTaxi(pasajero, taxi);
			vista.mostrarInformacion(resultado);
		});

		Thread hilo2 = new Thread(() -> {
			String resultado = asignador.asignarTaxi(pasajero, taxi);
			vista.mostrarInformacion(resultado);
		});

		hilo1.start();
		hilo2.start();

		try {
			hilo1.join();
			hilo2.join();
		} catch (InterruptedException e) {
			vista.mostrarInformacion("Error al esperar los hilos: " + e.getMessage());
		}

		vista.mostrarInformacion("Asignación completada sin interbloqueo.");
	}
}
