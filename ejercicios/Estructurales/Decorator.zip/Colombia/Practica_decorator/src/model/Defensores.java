package model;

public class Defensores extends DecoradorEquipo {
    private Equipo equipo;

    public Defensores(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String getDescripcion() {
        return equipo.getDescripcion() + "\nDefensores:\nJohan Mojica + Dávinson Sánchez + Jhon Lucumí + Daniel Muñoz";
    }
}
