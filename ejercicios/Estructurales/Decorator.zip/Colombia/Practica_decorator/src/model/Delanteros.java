package model;

public class Delanteros extends DecoradorEquipo {
    private Equipo equipo;

    public Delanteros(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String getDescripcion() {
        return equipo.getDescripcion() + "\nDelanteros:\nLuis Díaz + Cucho Hernández + Yaser Asprilla";
    }
}
