package model;

public class Centrocampistas extends DecoradorEquipo {
    private Equipo equipo;

    public Centrocampistas(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String getDescripcion() {
        return equipo.getDescripcion() + "\nCentrocampistas:\nJames Rodríguez + Richard Ríos + Kevin Castaño";
    }
}
