package model;

public class Equipo {
    public String getDescripcion() {
        return "El equipo de la selección es: \n";
    }
}
