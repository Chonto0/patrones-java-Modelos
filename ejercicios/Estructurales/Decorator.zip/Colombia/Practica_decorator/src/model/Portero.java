package model;

public class Portero extends DecoradorEquipo {
    private Equipo equipo;

    public Portero(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String getDescripcion() {
        return equipo.getDescripcion() + "\nPortero:\nKevin Mier";
    }
}
