package model;

public abstract class DecoradorEquipo extends Equipo {
    @Override
    public abstract String getDescripcion();
}
