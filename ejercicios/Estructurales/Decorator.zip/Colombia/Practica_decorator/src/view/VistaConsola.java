package view;

import java.util.Scanner;

public class VistaConsola {

    private Scanner sc = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        System.out.println("BIENVENIDO A LA FORMACIÓN DE LA SELECCIÓN");
        System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        System.out.println("Seleccione una opción para agregar jugadores:");
        System.out.println("1. Delanteros");
        System.out.println("2. Centrocampistas");
        System.out.println("3. Defensores");
        System.out.println("4. Portero");
        System.out.println("0. Finalizar y mostrar equipo");
    }

    public int leerOpcion() {
        System.out.print("Seleccione opción: ");
        return sc.nextInt();
    }

    public void mostrarDescripcion(String descripcion) {
        System.out.println("\n" + descripcion);
    }

    public void mostrarFinal() {
        System.out.println("\n¡TENEMOS EQUIPO!");
    }

    public void mostrarOpcionInvalida() {
        System.out.println("Opción no válida.");
    }
}
