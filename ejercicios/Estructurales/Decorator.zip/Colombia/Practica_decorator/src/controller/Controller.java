package controller;

import model.*;
import view.VistaConsola;

public class Controller {
    private Equipo equipo;
    private VistaConsola vista;

    public Controller() {
        equipo = new Equipo();
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            switch (opcion) {
                case 1:
                    equipo = new Delanteros(equipo);
                    break;
                case 2:
                    equipo = new Centrocampistas(equipo);
                    break;
                case 3:
                    equipo = new Defensores(equipo);
                    break;
                case 4:
                    equipo = new Portero(equipo);
                    break;
                case 0:
                    break;
                default:
                    vista.mostrarOpcionInvalida();
            }
        } while (opcion != 0);

        vista.mostrarDescripcion(equipo.getDescripcion());
        vista.mostrarFinal();
    }
}
