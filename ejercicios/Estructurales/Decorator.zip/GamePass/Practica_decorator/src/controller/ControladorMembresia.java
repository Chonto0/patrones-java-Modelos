package controller;

import model.*;
import view.VistaConsola;

public class ControladorMembresia {
    private VistaConsola vista;
    private Membresia membresia;

    public ControladorMembresia() {
        this.vista = new VistaConsola();
        this.membresia = new Membresia(); // base
    }

    public void run() {
        int opcion;

        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1 -> membresia = new MembresiaCore(membresia);
                case 2 -> membresia = new MembresiaStandard(membresia);
                case 3 -> membresia = new MembresiaUltimate(membresia);
                case 0 -> vista.mostrarResultado(membresia.getDescripcion(), membresia.getPrecio());
                default -> vista.mostrarMensaje("Opción no válida.");
            }

        } while (opcion != 0);
    }
}
