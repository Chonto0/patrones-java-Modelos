package controller;

public class XboxMembresiaApp {
    public static void main(String[] args) {
        ControladorMembresia controlador = new ControladorMembresia();
        controlador.run();
    }
}
