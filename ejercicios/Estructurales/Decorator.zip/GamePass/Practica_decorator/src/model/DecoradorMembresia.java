package model;

public abstract class DecoradorMembresia extends Membresia {
    @Override
    public abstract String getDescripcion();

    @Override
    public abstract int getPrecio();
}
