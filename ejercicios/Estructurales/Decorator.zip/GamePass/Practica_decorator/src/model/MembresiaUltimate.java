package model;

public class MembresiaUltimate extends DecoradorMembresia {
    private Membresia membresia;

    public MembresiaUltimate(Membresia membresia) {
        this.membresia = membresia;
    }

    @Override
    public String getDescripcion() {
        return membresia.getDescripcion() +
                "- Cientos de juegos en consola y PC\n" +
                "- Juegos desde el día de lanzamiento\n" +
                "- Multijugador online para consola\n" +
                "- Ofertas, recompensas y ventajas en títulos gratuitos\n" +
                "- Suscripción a EA Play\n";
    }

    @Override
    public int getPrecio() {
        return membresia.getPrecio() + 42990;
    }
}
