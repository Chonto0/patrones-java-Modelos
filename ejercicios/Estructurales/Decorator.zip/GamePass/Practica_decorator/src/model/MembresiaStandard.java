package model;

public class MembresiaStandard extends DecoradorMembresia {
    private Membresia membresia;

    public MembresiaStandard(Membresia membresia) {
        this.membresia = membresia;
    }

    @Override
    public String getDescripcion() {
        return membresia.getDescripcion() +
                "- Cientos de juegos de alta calidad para consola\n" +
                "- Multijugador online para consola\n" +
                "- Ofertas y descuentos\n";
    }

    @Override
    public int getPrecio() {
        return membresia.getPrecio() + 29900;
    }
}
