package model;

public class Membresia {
    public String getDescripcion() {
        return "Suscripción base:\n";
    }

    public int getPrecio() {
        return 0;
    }
}
