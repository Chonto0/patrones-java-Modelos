package model;

public class MembresiaCore extends DecoradorMembresia {
    private Membresia membresia;

    public MembresiaCore(Membresia membresia) {
        this.membresia = membresia;
    }

    @Override
    public String getDescripcion() {
        return membresia.getDescripcion() +
                "- Catálogo seleccionado (25+ juegos de consola)\n" +
                "- Multijugador online para consola\n" +
                "- Ofertas y descuentos\n";
    }

    @Override
    public int getPrecio() {
        return membresia.getPrecio() + 21900;
    }
}
