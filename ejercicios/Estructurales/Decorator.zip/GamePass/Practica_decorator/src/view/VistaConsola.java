package view;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("\nSeleccione la membresía Xbox Game Pass que desea agregar:");
        System.out.println("1. Core ($21.900)");
        System.out.println("2. Standard ($29.900)");
        System.out.println("3. Ultimate ($42.990)");
        System.out.println("0. Finalizar y mostrar detalles");
        System.out.print("Opción: ");
    }

    public int leerOpcion() {
        return sc.nextInt();
    }

    public void mostrarResultado(String descripcion, int precio) {
        System.out.println("\nResumen de tu membresía:");
        System.out.println(descripcion);
        System.out.println("Precio total: $" + precio);
        System.out.println("\n¡Gracias por unirte a Xbox Game Pass!");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
