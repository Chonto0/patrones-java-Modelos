package view;

import java.util.Scanner;

public class VistaConsola {
    private Scanner sc = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("\nPersonaliza tu prenda:");
        System.out.println("1. Agregar estampado (+$8000)");
        System.out.println("2. Agregar bordado (+$10000)");
        System.out.println("3. Agregar capucha (+$12000)");
        System.out.println("4. Agregar bolsillos (+$6000)");
        System.out.println("0. Finalizar diseño y mostrar resumen");
        System.out.print("Opción: ");
    }

    public int leerOpcion() {
        return sc.nextInt();
    }

    public void mostrarResumen(String descripcion, int precio) {
        System.out.println("\nResumen de tu prenda:");
        System.out.println(descripcion);
        System.out.println("Precio total: $" + precio);
        System.out.println("¡Gracias por comprar con nosotros!");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
