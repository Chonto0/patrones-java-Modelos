package controller;

import model.*;
import view.VistaConsola;

public class PrendaController {
    private Prenda prenda;
    private VistaConsola vista;

    public PrendaController() {
        prenda = new Prenda(); // base
        vista = new VistaConsola();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            switch (opcion) {
                case 1 -> prenda = new Estampado(prenda);
                case 2 -> prenda = new Bordado(prenda);
                case 3 -> prenda = new Capucha(prenda);
                case 4 -> prenda = new Bolsillos(prenda);
                case 0 -> vista.mostrarResumen(prenda.getDescripcion(), prenda.getPrecio());
                default -> vista.mostrarMensaje("Opción inválida.");
            }
        } while (opcion != 0);
    }
}
