package controller;

public class AppMain {
    public static void main(String[] args) {
        PrendaController controlador = new PrendaController();
        controlador.iniciar();
    }
}
