package model;

public class Bordado extends DecoradorPrenda {
    private Prenda prenda;

    public Bordado(Prenda prenda) {
        this.prenda = prenda;
    }

    @Override
    public String getDescripcion() {
        return prenda.getDescripcion() + " + Bordado personalizado";
    }

    @Override
    public int getPrecio() {
        return prenda.getPrecio() + 10000;
    }
}
