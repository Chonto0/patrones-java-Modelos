package model;

public class Bolsillos extends DecoradorPrenda {
    private Prenda prenda;

    public Bolsillos(Prenda prenda) {
        this.prenda = prenda;
    }

    @Override
    public String getDescripcion() {
        return prenda.getDescripcion() + " + Bolsillos delanteros";
    }

    @Override
    public int getPrecio() {
        return prenda.getPrecio() + 6000;
    }
}
