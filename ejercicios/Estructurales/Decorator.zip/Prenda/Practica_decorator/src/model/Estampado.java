package model;

public class Estampado extends DecoradorPrenda {
    private Prenda prenda;

    public Estampado(Prenda prenda) {
        this.prenda = prenda;
    }

    @Override
    public String getDescripcion() {
        return prenda.getDescripcion() + " + Estampado artístico";
    }

    @Override
    public int getPrecio() {
        return prenda.getPrecio() + 8000;
    }
}
