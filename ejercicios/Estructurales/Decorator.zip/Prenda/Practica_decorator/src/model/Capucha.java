package model;

public class Capucha extends DecoradorPrenda {
    private Prenda prenda;

    public Capucha(Prenda prenda) {
        this.prenda = prenda;
    }

    @Override
    public String getDescripcion() {
        return prenda.getDescripcion() + " + Capucha ajustable";
    }

    @Override
    public int getPrecio() {
        return prenda.getPrecio() + 12000;
    }
}
