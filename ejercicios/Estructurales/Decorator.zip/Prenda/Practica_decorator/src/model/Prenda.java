package model;

public class Prenda {
    public String getDescripcion() {
        return "Prenda básica (camiseta)";
    }

    public int getPrecio() {
        return 15000;
    }
}
