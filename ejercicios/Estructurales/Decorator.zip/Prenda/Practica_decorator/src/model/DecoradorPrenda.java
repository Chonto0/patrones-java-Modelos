package model;

public abstract class DecoradorPrenda extends Prenda {
    @Override
    public abstract String getDescripcion();

    @Override
    public abstract int getPrecio();
}
