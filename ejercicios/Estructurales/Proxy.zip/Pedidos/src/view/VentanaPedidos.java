package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import model.PedidoProxy;

public class VentanaPedidos extends JFrame implements ActionListener {
    private JTextArea areaPedidos;
    private JTextArea areaEdicion;
    private JButton btnCargar, btnGuardar, btnActualizar, btnSalir;
    private PedidoProxy proxy;

    public VentanaPedidos() {
        proxy = new PedidoProxy();
        inicializarComponentes();
    }

    private void inicializarComponentes() {
        setTitle("Gestión de Pedidos - Proxy");
        setSize(500, 400);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        areaPedidos = new JTextArea();
        areaPedidos.setEditable(false);
        areaPedidos.setBounds(20, 20, 440, 100);
        add(areaPedidos);

        areaEdicion = new JTextArea();
        areaEdicion.setBounds(20, 130, 440, 100);
        add(areaEdicion);

        btnCargar = new JButton("Cargar");
        btnCargar.setBounds(20, 250, 100, 30);
        btnCargar.addActionListener(this);
        add(btnCargar);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(130, 250, 100, 30);
        btnGuardar.addActionListener(this);
        add(btnGuardar);

        btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(240, 250, 100, 30);
        btnActualizar.addActionListener(this);
        add(btnActualizar);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(350, 250, 100, 30);
        btnSalir.addActionListener(this);
        add(btnSalir);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnCargar) {
            areaPedidos.setText(proxy.obtenerPedidos());
        } else if (e.getSource() == btnGuardar) {
            String nuevoContenido = areaEdicion.getText();
            proxy.guardarPedidos(nuevoContenido);
            JOptionPane.showMessageDialog(this, "Pedidos guardados correctamente.");
        } else if (e.getSource() == btnActualizar) {
            areaPedidos.setText(proxy.obtenerPedidos());
        } else if (e.getSource() == btnSalir) {
            System.exit(0);
        }
    }
}
