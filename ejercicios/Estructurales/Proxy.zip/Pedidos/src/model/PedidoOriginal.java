package model;

public class PedidoOriginal implements Pedido {
    private String contenido;

    public PedidoOriginal() {
        this.contenido = "";
    }

    public void cargarPedidos() {
        this.contenido = "Pedido 1: 3 hamburguesas\nPedido 2: 2 pizzas\nPedido 3: 5 jugos naturales";
    }

    @Override
    public String obtenerPedidos() {
        return contenido;
    }
}
