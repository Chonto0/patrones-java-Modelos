package model;

public class PedidoProxy implements Pedido {
    private PedidoOriginal original;

    public PedidoProxy() {
        original = new PedidoOriginal();
        original.cargarPedidos(); 
    }

    public void guardarPedidos(String contenido) {
        original = new PedidoOriginal();
        original.cargarPedidos(); 
        original = new PedidoOriginal() {
            private String datos = contenido;

            @Override
            public String obtenerPedidos() {
                return datos;
            }
        };
    }

    @Override
    public String obtenerPedidos() {
        return original.obtenerPedidos();
    }
}
