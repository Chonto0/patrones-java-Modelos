package model;

public interface Pedido {
    String obtenerPedidos();
}
