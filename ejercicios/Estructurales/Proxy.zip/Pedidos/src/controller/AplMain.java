package controller;

import view.VentanaPedidos;

public class AplMain {
	public static void main(String[] args) {
		VentanaPedidos ventana = new VentanaPedidos();
		ventana.setVisible(true);
	}
}
