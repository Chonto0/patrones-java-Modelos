package controller;

import model.Cuenta;
import model.CuentaProxy;

public class Controller {
    private Cuenta cuenta;

    public Controller() {
        cuenta = new CuentaProxy(1000.00);
    }

    public boolean validarPIN(String pin) {
        return cuenta.validarPIN(pin);
    }

    public double consultarSaldo() {
        return cuenta.consultarSaldo();
    }

    public boolean retirar(double monto) {
        return cuenta.retirar(monto);
    }
}
