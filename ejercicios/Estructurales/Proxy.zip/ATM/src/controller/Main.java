package controller;

import controller.Controller;
import view.VentanaATM;

public class Main {
    public static void main(String[] args) {
        Controller controlador = new Controller();
        VentanaATM ventana = new VentanaATM(controlador);
        ventana.setVisible(true);
    }
}
