package view;

import controller.Controller;
import javax.swing.*;
import java.awt.event.*;

public class VentanaATM extends JFrame implements ActionListener {

    private JLabel lblPin, lblMonto, lblSaldo;
    private JPasswordField txtPin;
    private JTextField txtMonto;
    private JButton btnValidar, btnConsultar, btnRetirar;
    private Controller controlador;

    public VentanaATM(Controller controlador) {
        this.controlador = controlador;

        setTitle("Cajero Automático - Patrón Proxy MVC");
        setSize(350, 250);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        lblPin = new JLabel("Ingrese PIN:");
        lblPin.setBounds(20, 20, 100, 25);
        add(lblPin);

        txtPin = new JPasswordField();
        txtPin.setBounds(120, 20, 150, 25);
        add(txtPin);

        btnValidar = new JButton("Validar PIN");
        btnValidar.setBounds(100, 60, 120, 30);
        btnValidar.addActionListener(this);
        add(btnValidar);

        lblMonto = new JLabel("Monto a retirar:");
        lblMonto.setBounds(20, 100, 100, 25);
        add(lblMonto);

        txtMonto = new JTextField();
        txtMonto.setBounds(120, 100, 150, 25);
        txtMonto.setEnabled(false);
        add(txtMonto);

        btnRetirar = new JButton("Retirar");
        btnRetirar.setBounds(50, 140, 100, 30);
        btnRetirar.setEnabled(false);
        btnRetirar.addActionListener(this);
        add(btnRetirar);

        btnConsultar = new JButton("Consultar Saldo");
        btnConsultar.setBounds(160, 140, 140, 30);
        btnConsultar.setEnabled(false);
        btnConsultar.addActionListener(this);
        add(btnConsultar);

        lblSaldo = new JLabel("Saldo: ");
        lblSaldo.setBounds(20, 180, 300, 25);
        add(lblSaldo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnValidar) {
            String pin = new String(txtPin.getPassword());
            if (controlador.validarPIN(pin)) {
                JOptionPane.showMessageDialog(this, "PIN correcto. Acceso concedido.");
                txtMonto.setEnabled(true);
                btnRetirar.setEnabled(true);
                btnConsultar.setEnabled(true);
                btnValidar.setEnabled(false);
                txtPin.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "PIN incorrecto. Intente de nuevo.");
            }

        } else if (e.getSource() == btnConsultar) {
            double saldo = controlador.consultarSaldo();
            if (saldo >= 0) {
                lblSaldo.setText("Saldo: $" + saldo);
            } else {
                JOptionPane.showMessageDialog(this, "Debe validar el PIN primero.");
            }

        } else if (e.getSource() == btnRetirar) {
            try {
                double monto = Double.parseDouble(txtMonto.getText());
                if (monto <= 0) {
                    JOptionPane.showMessageDialog(this, "Ingrese un monto válido.");
                    return;
                }
                boolean resultado = controlador.retirar(monto);
                if (resultado) {
                    JOptionPane.showMessageDialog(this, "Retiro exitoso.");
                    lblSaldo.setText("Saldo: $" + controlador.consultarSaldo());
                    txtMonto.setText("");
                } else {
                    JOptionPane.showMessageDialog(this, "Saldo insuficiente o error.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese un número válido.");
            }
        }
    }
}
