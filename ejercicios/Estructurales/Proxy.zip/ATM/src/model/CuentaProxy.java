package model;

public class CuentaProxy implements Cuenta {
    private CuentaOriginal cuentaReal;
    private boolean accesoPermitido = false;

    public CuentaProxy(double saldoInicial) {
        cuentaReal = new CuentaOriginal(saldoInicial);
    }

    @Override
    public boolean validarPIN(String pin) {
        accesoPermitido = cuentaReal.validarPIN(pin);
        return accesoPermitido;
    }

    @Override
    public double consultarSaldo() {
        return accesoPermitido ? cuentaReal.consultarSaldo() : -1;
    }

    @Override
    public boolean retirar(double monto) {
        return accesoPermitido && cuentaReal.retirar(monto);
    }

    public boolean tieneAcceso() {
        return accesoPermitido;
    }
}
