package model;

public class CuentaOriginal implements Cuenta {
    private String pinCorrecto = "1234";
    private double saldo;

    public CuentaOriginal(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    @Override
    public boolean validarPIN(String pin) {
        return pinCorrecto.equals(pin);
    }

    @Override
    public double consultarSaldo() {
        return saldo;
    }

    @Override
    public boolean retirar(double monto) {
        if (monto > 0 && saldo >= monto) {
            saldo -= monto;
            return true;
        }
        return false;
    }
}
