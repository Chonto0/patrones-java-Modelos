package model;

public interface Cuenta {
	boolean validarPIN(String pin);

	double consultarSaldo();

	boolean retirar(double monto);
}
