package view;

import javax.swing.*;

import model.ConfiguracionProxy;

import java.awt.event.*;

public class VentanaConfiguracion extends JFrame implements ActionListener {

    private JTextField txtClave;
    private JComboBox<String> cmbResolucion;
    private JSlider sldVolumen;
    private JCheckBox chkModoOscuro;
    private JButton btnAutenticar, btnAplicar;
    private JLabel lblEstado;
	private ConfiguracionProxy config;

    public VentanaConfiguracion() {
        setTitle("Configuración del Videojuego");
        setSize(400, 300);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        config = new ConfiguracionProxy();

        JLabel lblClave = new JLabel("Clave Admin:");
        lblClave.setBounds(20, 20, 100, 25);
        add(lblClave);

        txtClave = new JTextField();
        txtClave.setBounds(120, 20, 150, 25);
        add(txtClave);

        btnAutenticar = new JButton("Autenticar");
        btnAutenticar.setBounds(280, 20, 100, 25);
        btnAutenticar.addActionListener(this);
        add(btnAutenticar);

        cmbResolucion = new JComboBox<>(new String[]{"1920x1080", "1280x720", "800x600"});
        cmbResolucion.setBounds(120, 60, 150, 25);
        cmbResolucion.setEnabled(false);
        add(cmbResolucion);

        JLabel lblVolumen = new JLabel("Volumen:");
        lblVolumen.setBounds(20, 100, 100, 25);
        add(lblVolumen);

        sldVolumen = new JSlider(0, 100, 50);
        sldVolumen.setBounds(120, 100, 200, 40);
        sldVolumen.setEnabled(false);
        add(sldVolumen);

        chkModoOscuro = new JCheckBox("Modo Oscuro");
        chkModoOscuro.setBounds(120, 150, 150, 25);
        chkModoOscuro.setEnabled(false);
        add(chkModoOscuro);

        btnAplicar = new JButton("Aplicar Cambios");
        btnAplicar.setBounds(120, 180, 150, 30);
        btnAplicar.setEnabled(false);
        btnAplicar.addActionListener(this);
        add(btnAplicar);

        lblEstado = new JLabel("Estado: ---");
        lblEstado.setBounds(20, 220, 360, 25);
        add(lblEstado);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAutenticar) {
            String clave = txtClave.getText();
            if (config.autenticar(clave)) {
                JOptionPane.showMessageDialog(this, "Acceso concedido.");
                cmbResolucion.setEnabled(true);
                sldVolumen.setEnabled(true);
                chkModoOscuro.setEnabled(true);
                btnAplicar.setEnabled(true);
                txtClave.setEnabled(false);
                btnAutenticar.setEnabled(false);
            } else {
                JOptionPane.showMessageDialog(this, "Clave incorrecta.");
            }
        } else if (e.getSource() == btnAplicar) {
            config.cambiarResolucion(cmbResolucion.getSelectedItem().toString());
            config.cambiarVolumen(sldVolumen.getValue());
            config.cambiarModoOscuro(chkModoOscuro.isSelected());

            lblEstado.setText("Estado: " + config.obtenerEstado());
        }
    }
}