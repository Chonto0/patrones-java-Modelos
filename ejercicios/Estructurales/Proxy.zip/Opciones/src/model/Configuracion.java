package model;

public interface Configuracion {
	boolean autenticar(String claveAdmin);

	void cambiarResolucion(String resolucion);

	void cambiarVolumen(int volumen);

	void cambiarModoOscuro(boolean modoOscuro);

	String obtenerEstado();
}