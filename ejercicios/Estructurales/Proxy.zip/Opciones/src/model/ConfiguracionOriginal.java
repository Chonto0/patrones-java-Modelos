package model;

public class ConfiguracionOriginal implements Configuracion {

	private String resolucion = "1280x720";
	private int volumen = 50;
	private boolean modoOscuro = false;

	@Override
	public boolean autenticar(String claveAdmin) {
		return true; // ya está autenticado en este punto
	}

	@Override
	public void cambiarResolucion(String resolucion) {
		this.resolucion = resolucion;
	}

	@Override
	public void cambiarVolumen(int volumen) {
		this.volumen = volumen;
	}

	@Override
	public void cambiarModoOscuro(boolean modoOscuro) {
		this.modoOscuro = modoOscuro;
	}

	@Override
	public String obtenerEstado() {
		return "Resolución: " + resolucion + ", Volumen: " + volumen + ", Modo Oscuro: " + (modoOscuro ? "Sí" : "No");
	}
}