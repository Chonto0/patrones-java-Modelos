package model;

public class ConfiguracionProxy implements Configuracion {

	private ConfiguracionOriginal configReal;
	private boolean accesoPermitido = false;
	private final String claveCorrecta = "admin123";

	public ConfiguracionProxy() {
		this.configReal = new ConfiguracionOriginal();
	}

	@Override
	public boolean autenticar(String claveAdmin) {
		accesoPermitido = claveCorrecta.equals(claveAdmin);
		return accesoPermitido;
	}

	@Override
	public void cambiarResolucion(String resolucion) {
		if (accesoPermitido) {
			configReal.cambiarResolucion(resolucion);
		}
	}

	@Override
	public void cambiarVolumen(int volumen) {
		if (accesoPermitido) {
			configReal.cambiarVolumen(volumen);
		}
	}

	@Override
	public void cambiarModoOscuro(boolean modoOscuro) {
		if (accesoPermitido) {
			configReal.cambiarModoOscuro(modoOscuro);
		}
	}

	@Override
	public String obtenerEstado() {
		return configReal.obtenerEstado();
	}
}