package controller;

import view.VentanaConfiguracion;

public class AplMain {
	public static void main(String[] args) {
		VentanaConfiguracion ventana = new VentanaConfiguracion();
		ventana.setVisible(true);
	}
}