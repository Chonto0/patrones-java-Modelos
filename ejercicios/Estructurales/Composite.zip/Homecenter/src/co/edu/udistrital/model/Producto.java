package co.edu.udistrital.model;

public interface Producto {
	String getNombre();

	float getPrecio();

	String getDescripcion();

	void agregar(Producto p);

	void eliminar(Producto p);
}
