package co.edu.udistrital.view;

public class Menu {
    private VistaConsola vista;
    private Catalogo catalogo;
    private Carrito carrito;

    public Menu() {
        vista = new VistaConsola();
        catalogo = new Catalogo();
        carrito = new Carrito();
    }

    public void mostrar() {
        int opcion;
        do {
            vista.mostrarInformacion("\n--- MENÚ DE COMPRAS ---");
            vista.mostrarInformacion("1. Ver catálogo");
            vista.mostrarInformacion("2. Agregar producto al carrito");
            vista.mostrarInformacion("3. Eliminar producto del carrito");
            vista.mostrarInformacion("4. Ver carrito y total");
            vista.mostrarInformacion("5. Ver descripción de un producto");
            vista.mostrarInformacion("0. Salir");

            opcion = vista.leerDatoEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> catalogo.mostrar();
                case 2 -> carrito.agregar(catalogo, vista);
                case 3 -> carrito.eliminar(vista);
                case 4 -> carrito.mostrar(vista);
                case 5 -> catalogo.mostrarDescripcion(vista);
                case 0 -> vista.mostrarInformacion("Gracias por su compra.");
                default -> vista.mostrarInformacion("Opción inválida.");
            }
        } while (opcion != 0);
    }
}
