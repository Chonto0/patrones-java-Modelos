package co.edu.udistrital.controller;

import co.edu.udistrital.view.*;

public class Controller {
    private Menu menu;

    public Controller() {
        menu = new Menu();
    }

    public void run() {
        menu.mostrar();
    }
}
