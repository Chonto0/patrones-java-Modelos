package co.edu.udistrital.view;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.Hojas.*;

import java.util.*;

public class Catalogo {
    private List<Producto> productos;

    public Catalogo() {
        productos = new ArrayList<>();
        productos.add(new Martillo("Martillo Stanley", 45000, "Martillo resistente de acero."));
        productos.add(new Taladro("Taladro Bosch", 230000, "Taladro percutor para concreto."));
        productos.add(new Pintura("Pintura Blanca", 32000, "Pintura lavable de alta cobertura."));
    }

    public void mostrar() {
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            System.out.println(i + ". " + p.getNombre() + " ($" + p.getPrecio() + ")");
        }
    }

    public Producto obtener(int i) {
        if (i >= 0 && i < productos.size()) return productos.get(i);
        return null;
    }

    public void mostrarDescripcion(VistaConsola vista) {
        mostrar();
        int i = vista.leerDatoEntero("Ingrese el índice del producto: ");
        Producto p = obtener(i);
        if (p != null)
            vista.mostrarInformacion("Descripción: " + p.getDescripcion());
        else
            vista.mostrarInformacion("Índice inválido.");
    }
}
