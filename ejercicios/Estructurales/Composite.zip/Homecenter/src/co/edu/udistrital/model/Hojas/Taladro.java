package co.edu.udistrital.model.Hojas;

import co.edu.udistrital.model.Producto;

public class Taladro implements Producto {
    private String nombre;
    private float precio;
    private String descripcion;

    public Taladro(String nombre, float precio, String descripcion) {
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public float getPrecio() {
        return precio;
    }

    @Override
    public void agregar(Producto p) {}

    @Override
    public void eliminar(Producto p) {}

    @Override
    public String getDescripcion() {
        return descripcion;
    }
}