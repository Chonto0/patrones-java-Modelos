package co.edu.udistrital.model.Compuestos;

import java.util.ArrayList;
import java.util.List;
import co.edu.udistrital.model.Producto;

public class ProductoCompuesto implements Producto {
    private String nombre;
    private String descripcion;
    private List<Producto> productos;

    public ProductoCompuesto(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.productos = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public float getPrecio() {
        float total = 0;
        for (Producto p : productos) {
            total += p.getPrecio();
        }
        return total;
    }

    @Override
    public void agregar(Producto p) {
        productos.add(p);
    }

    @Override
    public void eliminar(Producto p) {
        productos.remove(p);
    }

    @Override
    public String getDescripcion() {
        return descripcion;
    }

    public List<Producto> getProductos() {
        return productos;
    }
}
