package co.edu.udistrital.view;

import co.edu.udistrital.model.Producto;

import java.util.*;

public class Carrito {
    private List<Producto> carrito;

    public Carrito() {
        carrito = new ArrayList<>();
    }

    public void agregar(Catalogo catalogo, VistaConsola vista) {
        catalogo.mostrar();
        int i = vista.leerDatoEntero("Índice del producto a agregar: ");
        Producto p = catalogo.obtener(i);
        if (p != null) {
            carrito.add(p);
            vista.mostrarInformacion("Producto agregado.");
        } else {
            vista.mostrarInformacion("Índice inválido.");
        }
    }

    public void eliminar(VistaConsola vista) {
        mostrar(vista);
        int i = vista.leerDatoEntero("Índice del producto a eliminar: ");
        if (i >= 0 && i < carrito.size()) {
            carrito.remove(i);
            vista.mostrarInformacion("Producto eliminado.");
        } else {
            vista.mostrarInformacion("Índice inválido.");
        }
    }

    public void mostrar(VistaConsola vista) {
        float total = 0;
        vista.mostrarInformacion("\n--- CARRITO ---");
        for (int i = 0; i < carrito.size(); i++) {
            Producto p = carrito.get(i);
            vista.mostrarInformacion(i + ". " + p.getNombre() + " ($" + p.getPrecio() + ")");
            total += p.getPrecio();
        }
        vista.mostrarInformacion("Total: $" + total);
    }
}
