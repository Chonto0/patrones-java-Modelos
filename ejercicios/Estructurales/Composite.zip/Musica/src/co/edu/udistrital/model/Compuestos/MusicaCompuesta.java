package co.edu.udistrital.model.Compuestos;

import java.util.ArrayList;
import java.util.List;

import co.edu.udistrital.model.Musica;

public class MusicaCompuesta implements Musica {
    private String nombre;
    private List<Musica> elementos;

    public MusicaCompuesta(String nombre) {
        this.nombre = nombre;
        this.elementos = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getDuracion() {
        int total = 0;
        for (Musica m : elementos) {
            total += m.getDuracion();
        }
        return total;
    }

    @Override
    public void agregar(Musica m) {
        elementos.add(m);
    }

    @Override
    public void eliminar(Musica m) {
        elementos.remove(m);
    }

    public List<Musica> getElementos() {
        return elementos;
    }
}