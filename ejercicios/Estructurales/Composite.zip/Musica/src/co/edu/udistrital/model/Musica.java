package co.edu.udistrital.model;

public interface Musica {
    String getNombre();
    int getDuracion(); // duración en minutos
    void agregar(Musica m);
    void eliminar(Musica m);
}