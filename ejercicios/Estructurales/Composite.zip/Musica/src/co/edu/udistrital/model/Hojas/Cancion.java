package co.edu.udistrital.model.Hojas;

import co.edu.udistrital.model.Musica;

public class Cancion implements Musica {
    private String nombre;
    private int duracion;

    public Cancion(String nombre, int duracion) {
        this.nombre = nombre;
        this.duracion = duracion;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getDuracion() {
        return duracion;
    }

    @Override
    public void agregar(Musica m) {
        // No aplica
    }

    @Override
    public void eliminar(Musica m) {
        // No aplica
    }
}