package co.edu.udistrital.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import co.edu.udistrital.model.Musica;
import co.edu.udistrital.model.Compuestos.MusicaCompuesta;
import co.edu.udistrital.model.Hojas.Cancion;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	private List<Cancion> cancionesDisponibles;
	private MusicaCompuesta biblioteca;

	public Controller() {
		vista = new VistaConsola();
		cancionesDisponibles = new ArrayList<>();
		biblioteca = new MusicaCompuesta("Mi Biblioteca Musical");
		inicializarCanciones();
	}

	public void run() {
		int opcion;
		do {
			vista.mostrarInformacion("\n=== Menú de Música ===");
			vista.mostrarInformacion("1. Ver canciones disponibles");
			vista.mostrarInformacion("2. Crear playlist con canciones");
			vista.mostrarInformacion("3. Mostrar biblioteca");
			vista.mostrarInformacion("4. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción: ");

			switch (opcion) {
			case 1:
				mostrarCanciones();
				break;
			case 2:
				crearPlaylist();
				break;
			case 3:
				mostrarContenido(biblioteca, 0);
				break;
			case 4:
				vista.mostrarInformacion("¡Hasta luego!");
				break;
			default:
				vista.mostrarInformacion("Opción no válida.");
			}
		} while (opcion != 4);
	}

	private void inicializarCanciones() {
		cancionesDisponibles.add(new Cancion("Bohemian Rhapsody", 6));
		cancionesDisponibles.add(new Cancion("Imagine", 3));
		cancionesDisponibles.add(new Cancion("Stairway to Heaven", 8));
		cancionesDisponibles.add(new Cancion("Hotel California", 7));
		cancionesDisponibles.add(new Cancion("Smells Like Teen Spirit", 5));
	}

	private void mostrarCanciones() {
		vista.mostrarInformacion("=== Canciones Disponibles ===");
		int index = 1;
		for (Cancion c : cancionesDisponibles) {
			vista.mostrarInformacion(index + ". " + c.getNombre() + " (" + c.getDuracion() + " min)");
			index++;
		}
	}

	private void crearPlaylist() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nombre de la playlist: ");
		String nombre = sc.nextLine();

		MusicaCompuesta playlist = new MusicaCompuesta(nombre);

		mostrarCanciones();
		vista.mostrarInformacion("Ingrese los números de las canciones que desea agregar (0 para finalizar):");

		int seleccion;
		do {
			seleccion = vista.leerDatoEntero("Número de canción: ");
			if (seleccion > 0 && seleccion <= cancionesDisponibles.size()) {
				playlist.agregar(cancionesDisponibles.get(seleccion - 1));
				vista.mostrarInformacion("Canción agregada.");
			} else if (seleccion != 0) {
				vista.mostrarInformacion("Selección no válida.");
			}
		} while (seleccion != 0);

		biblioteca.agregar(playlist);
		vista.mostrarInformacion("Playlist creada con éxito.");
		vista.mostrarInformacion("Duración total: " + playlist.getDuracion() + " min");
	}

	private void mostrarContenido(Musica musica, int nivel) {
	    String indent = "";
	    for (int i = 0; i < nivel; i++) {
	        indent += "  ";
	    }

	    vista.mostrarInformacion(indent + "- " + musica.getNombre() + " (" + musica.getDuracion() + " min)");

	    if (musica instanceof MusicaCompuesta) {
	        for (Musica sub : ((MusicaCompuesta) musica).getElementos()) {
	            mostrarContenido(sub, nivel + 1);
	        }
	    }
	}
}