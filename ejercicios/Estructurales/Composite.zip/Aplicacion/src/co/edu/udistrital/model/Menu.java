package co.edu.udistrital.model;

public interface Menu {
	String mostrar(int profundidad);
}
