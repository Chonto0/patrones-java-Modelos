package co.edu.udistrital.model.Compuestos;

import co.edu.udistrital.model.Menu;
import java.util.ArrayList;
import java.util.List;

public class MenuComponente implements Menu {
    private String nombre;
    private List<Menu> elementos;

    public MenuComponente(String nombre) {
        this.nombre = nombre;
        this.elementos = new ArrayList<>();
    }

    public void agregar(Menu componente) {
        elementos.add(componente);
    }

    public void eliminar(Menu componente) {
        elementos.remove(componente);
    }

    @Override
    public String mostrar(int profundidad) {
        StringBuilder sb = new StringBuilder();
        sb.append("  ".repeat(profundidad)).append(nombre).append(":\n");

        for (Menu componente : elementos) {
            sb.append(componente.mostrar(profundidad + 1));
        }

        return sb.toString();
    }
}
