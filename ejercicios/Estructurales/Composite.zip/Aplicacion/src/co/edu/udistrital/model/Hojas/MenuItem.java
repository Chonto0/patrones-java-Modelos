package co.edu.udistrital.model.Hojas;

import co.edu.udistrital.model.Menu;

public class MenuItem implements Menu {
	private String nombre;

	public MenuItem(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String mostrar(int profundidad) {
		return "  ".repeat(profundidad) + "- " + nombre + "\n";
	}
}
