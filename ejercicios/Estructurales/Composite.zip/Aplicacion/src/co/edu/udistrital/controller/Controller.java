package co.edu.udistrital.controller;

import co.edu.udistrital.model.Menu;
import co.edu.udistrital.model.Compuestos.MenuComponente;
import co.edu.udistrital.model.Hojas.MenuItem;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
    private VistaConsola vista;
    private Menu menuPrincipal;

    public Controller() {
        vista = new VistaConsola();
        construirMenu();
    }

    private void construirMenu() {
        MenuComponente archivo = new MenuComponente("Archivo");
        archivo.agregar(new MenuItem("Nuevo"));
        archivo.agregar(new MenuItem("Abrir"));
        archivo.agregar(new MenuItem("Guardar"));
        archivo.agregar(new MenuItem("Salir"));

        MenuComponente editar = new MenuComponente("Editar");
        editar.agregar(new MenuItem("Copiar"));
        editar.agregar(new MenuItem("Pegar"));

        MenuComponente zoom = new MenuComponente("Zoom");
        zoom.agregar(new MenuItem("Acercar"));
        zoom.agregar(new MenuItem("Alejar"));

        MenuComponente ver = new MenuComponente("Ver");
        ver.agregar(zoom);

        menuPrincipal = new MenuComponente("Menú Principal");
        ((MenuComponente) menuPrincipal).agregar(archivo);
        ((MenuComponente) menuPrincipal).agregar(editar);
        ((MenuComponente) menuPrincipal).agregar(ver);
    }

    public void run() {
        boolean salir = false;
        while (!salir) {
            vista.mostrarInformacion("\n--- Menú de la Aplicación ---");
            vista.mostrarInformacion(menuPrincipal.mostrar(0)); // Mostramos el resultado del método mostrar

            int opcion = vista.leerDatoEntero("Ingrese 0 para salir o cualquier otro número para refrescar el menú: ");
            if (opcion == 0) {
                salir = true;
                vista.mostrarInformacion("Saliendo de la aplicación...");
            }
        }
    }
}
