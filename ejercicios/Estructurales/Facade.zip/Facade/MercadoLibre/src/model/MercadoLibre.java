package model;

import model.modulos.*;

public class MercadoLibre {
	private Buscar buscar = new Buscar();
	private Categorias categorias = new Categorias();
	private Ofertas ofertas = new Ofertas();
	private Vender vender = new Vender();
	private Ayuda ayuda = new Ayuda();
	private Cuenta cuenta = new Cuenta();
	private Login login = new Login();
	private Compras compras = new Compras();

	public String buscar() {
		return buscar.buscarProducto();
	}

	public String verCategorias() {
		return categorias.mostrarCategorias();
	}

	public String verOfertas() {
		return ofertas.mostrarOfertas();
	}

	public String vender() {
		return vender.publicarProducto();
	}

	public String ayuda() {
		return ayuda.mostrarAyuda();
	}

	public String crearCuenta() {
		return cuenta.crearCuenta();
	}

	public String ingresar() {
		return login.ingresar();
	}

	public String verCompras() {
		return compras.mostrarCompras();
	}

	public String login() {
		return login.ingresar(); 
	}

}
