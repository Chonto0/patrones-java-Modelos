package model.modulos;

public class Ofertas {
	public String mostrarOfertas() {
		return"Estas son las ofertas del día en Mercado Libre.";
    }
}
