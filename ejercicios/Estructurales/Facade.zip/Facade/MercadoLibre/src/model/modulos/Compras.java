package model.modulos;

public class Compras {
	public String mostrarCompras() {
		return"Estas son tus últimas compras.";
    }
}
