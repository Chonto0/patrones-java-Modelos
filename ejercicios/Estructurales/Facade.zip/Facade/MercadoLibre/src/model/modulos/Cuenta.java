package model.modulos;

public class Cuenta {
	public String crearCuenta() {
		return"Comencemos a crear tu cuenta en Mercado Libre.";
    }
}
