package model.modulos;

public class Buscar {
    public String buscarProducto() {
        return "Ingresaste al buscador. Escribe lo que quieras encontrar.";
    }
}
