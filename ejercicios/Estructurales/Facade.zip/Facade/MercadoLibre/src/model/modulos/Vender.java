package model.modulos;

public class Vender {
	public String publicarProducto() {
		return"Publica un producto para vender fácilmente.";
    }
}
