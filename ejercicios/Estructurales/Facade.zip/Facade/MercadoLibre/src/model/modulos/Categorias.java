package model.modulos;

public class Categorias {
	public String mostrarCategorias() {
		return"Mostrando categorías destacadas: Electrónica, Ropa, Hogar, Juguetes...";
    }
}
