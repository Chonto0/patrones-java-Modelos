package model.modulos;

public class Login {
	public String ingresar() {
		return "Mostrando formulario de ingreso a tu cuenta...";
	}
}
