package model.modulos;

public class Ayuda {
	public String mostrarAyuda() {
		return"Bienvenido al centro de ayuda y PQR.";
    }
}
