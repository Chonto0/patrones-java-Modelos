package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MenuMercadoLibre extends JFrame {
    private JButton btnBuscar = new JButton("Buscar");
    private JButton btnCategorias = new JButton("Categorías");
    private JButton btnOfertas = new JButton("Ofertas");
    private JButton btnVender = new JButton("Vender");
    private JButton btnAyuda = new JButton("Ayuda / PQR");
    private JButton btnCuenta = new JButton("Crear cuenta");
    private JButton btnLogin = new JButton("Ingresar");
    private JButton btnCompras = new JButton("Mis compras");

    private JTextArea areaResultado = new JTextArea(8, 30);
    private JScrollPane scrollResultado = new JScrollPane(areaResultado);

    public MenuMercadoLibre() {
        setTitle("Mercado Libre - Simulación");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Panel de botones
        JPanel panelBotones = new JPanel(new GridLayout(4, 2, 10, 10));
        panelBotones.setBorder(BorderFactory.createTitledBorder("Opciones"));
        panelBotones.add(btnBuscar);
        panelBotones.add(btnCategorias);
        panelBotones.add(btnOfertas);
        panelBotones.add(btnVender);
        panelBotones.add(btnAyuda);
        panelBotones.add(btnCuenta);
        panelBotones.add(btnLogin);
        panelBotones.add(btnCompras);

        // Área de resultados
        areaResultado.setEditable(false);
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        scrollResultado.setBorder(BorderFactory.createTitledBorder("Resultado"));

        // Agregar componentes
        add(panelBotones, BorderLayout.CENTER);
        add(scrollResultado, BorderLayout.SOUTH);
    }

    // Métodos para conectar eventos
    public void agregarListenerBuscar(ActionListener listener) { btnBuscar.addActionListener(listener); }
    public void agregarListenerCategorias(ActionListener listener) { btnCategorias.addActionListener(listener); }
    public void agregarListenerOfertas(ActionListener listener) { btnOfertas.addActionListener(listener); }
    public void agregarListenerVender(ActionListener listener) { btnVender.addActionListener(listener); }
    public void agregarListenerAyuda(ActionListener listener) { btnAyuda.addActionListener(listener); }
    public void agregarListenerCuenta(ActionListener listener) { btnCuenta.addActionListener(listener); }
    public void agregarListenerLogin(ActionListener listener) { btnLogin.addActionListener(listener); }
    public void agregarListenerCompras(ActionListener listener) { btnCompras.addActionListener(listener); }

    // Método para mostrar resultado
    public void mostrarMensaje(String mensaje) {
        areaResultado.append(mensaje + "\n");
    }
}
