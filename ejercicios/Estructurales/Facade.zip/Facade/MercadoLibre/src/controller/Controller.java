package controller;

import model.MercadoLibre;
import view.MenuMercadoLibre;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Controller {
	private MercadoLibre fachada;
	private MenuMercadoLibre vista;

	public Controller(MenuMercadoLibre vista) {
		this.vista = vista;
		this.fachada = new MercadoLibre();
		configurarEventos();
	}

	private void configurarEventos() {
		vista.agregarListenerBuscar(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.buscar());
			}
		});

		vista.agregarListenerCategorias(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.verCategorias());
			}
		});

		vista.agregarListenerOfertas(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.verOfertas());
			}
		});

		vista.agregarListenerVender(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.vender());
			}
		});

		vista.agregarListenerAyuda(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.ayuda());
			}
		});

		vista.agregarListenerCuenta(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.crearCuenta());
			}
		});

		vista.agregarListenerLogin(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.login());
			}
		});

		vista.agregarListenerCompras(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				vista.mostrarMensaje(fachada.verCompras());
			}
		});
	}
}
