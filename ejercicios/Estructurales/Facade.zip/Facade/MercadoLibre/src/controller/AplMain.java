package controller;

import view.MenuMercadoLibre;

public class AplMain {
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(() -> {
			MenuMercadoLibre vista = new MenuMercadoLibre();
			new Controller(vista);
			vista.setVisible(true);
		});
	}
}
