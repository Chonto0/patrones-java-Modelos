package model;

import model.modulos.*;

public class Empresa {
	private DepartamentoRRHH rrhh = new DepartamentoRRHH();
	private DepartamentoContabilidad contabilidad = new DepartamentoContabilidad();
	private DepartamentoVentas ventas = new DepartamentoVentas();
	private DepartamentoProduccion produccion = new DepartamentoProduccion();
	private DepartamentoIT it = new DepartamentoIT();

	public String accederRRHH() {
		return rrhh.gestionarEmpleados();
	}

	public String accederContabilidad() {
		return contabilidad.procesarNomina();
	}

	public String accederVentas() {
		return ventas.generarVentas();
	}

	public String accederProduccion() {
		return produccion.fabricarProducto();
	}

	public String accederIT() {
		return it.mantenerSistemas();
	}
}
