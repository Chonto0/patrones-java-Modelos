package model.modulos;

public class DepartamentoVentas {
	public String generarVentas() {
		return"Ventas está generando nuevas oportunidades.";
    }
}
