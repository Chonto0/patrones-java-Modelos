package model.modulos;

public class DepartamentoRRHH {
    public String gestionarEmpleados() {
        return "RRHH está gestionando empleados.";
    }
}
