package model.modulos;

public class DepartamentoIT {
	public String mantenerSistemas() {
		return"IT está manteniendo los sistemas informáticos.";
	}
}
