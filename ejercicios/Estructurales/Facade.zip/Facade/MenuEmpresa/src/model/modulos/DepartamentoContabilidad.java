package model.modulos;

public class DepartamentoContabilidad {
	public String procesarNomina() {
		return"Contabilidad está procesando la nómina.";
	}
}
