package model.modulos;

public class DepartamentoProduccion {
	public String fabricarProducto() {
    	return "Producción está fabricando productos.";
    }
}
