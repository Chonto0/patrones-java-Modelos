package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class MenuEmpresa extends JFrame {
	private JButton btnRRHH = new JButton("Recursos Humanos");
	private JButton btnContabilidad = new JButton("Contabilidad");
	private JButton btnVentas = new JButton("Ventas");
	private JButton btnProduccion = new JButton("Producción");
	private JButton btnIT = new JButton("IT");
	private JTextArea areaResultado = new JTextArea(10, 40);

	public MenuEmpresa() {
		setTitle("Sistema Empresarial");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		JPanel panelBotones = new JPanel(new GridLayout(1, 5));
		panelBotones.add(btnRRHH);
		panelBotones.add(btnContabilidad);
		panelBotones.add(btnVentas);
		panelBotones.add(btnProduccion);
		panelBotones.add(btnIT);

		areaResultado.setEditable(false);
		JScrollPane scroll = new JScrollPane(areaResultado);

		add(panelBotones, BorderLayout.NORTH);
		add(scroll, BorderLayout.CENTER);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
	}

	// Métodos para agregar listeners a los botones
	public void agregarListenerRRHH(ActionListener listener) {
		btnRRHH.addActionListener(listener);
	}

	public void agregarListenerContabilidad(ActionListener listener) {
		btnContabilidad.addActionListener(listener);
	}

	public void agregarListenerVentas(ActionListener listener) {
		btnVentas.addActionListener(listener);
	}

	public void agregarListenerProduccion(ActionListener listener) {
		btnProduccion.addActionListener(listener);
	}

	public void agregarListenerIT(ActionListener listener) {
		btnIT.addActionListener(listener);
	}

	// Mostrar resultado en el área de texto
	public void mostrarMensaje(String mensaje) {
		areaResultado.append(mensaje + "\n");
	}

	
	public JButton getBtnRRHH() {
		return btnRRHH;
	}

	public JButton getBtnContabilidad() {
		return btnContabilidad;
	}

	public JButton getBtnVentas() {
		return btnVentas;
	}

	public JButton getBtnProduccion() {
		return btnProduccion;
	}

	public JButton getBtnIT() {
		return btnIT;
	}
}
