package controller;

import model.Empresa;
import view.MenuEmpresa;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {

	private Empresa empresa;
	private MenuEmpresa vista;

	public Controller() {
		empresa = new Empresa();
		vista = new MenuEmpresa();
		configurarEventos();
	}

	private void configurarEventos() {
		vista.agregarListenerRRHH(this);
		vista.agregarListenerContabilidad(this);
		vista.agregarListenerVentas(this);
		vista.agregarListenerProduccion(this);
		vista.agregarListenerIT(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object fuente = e.getSource();

		if (fuente == vista.getBtnRRHH()) {
			vista.mostrarMensaje(empresa.accederRRHH());
		} else if (fuente == vista.getBtnContabilidad()) {
			vista.mostrarMensaje(empresa.accederContabilidad());
		} else if (fuente == vista.getBtnVentas()) {
			vista.mostrarMensaje(empresa.accederVentas());
		} else if (fuente == vista.getBtnProduccion()) {
			vista.mostrarMensaje(empresa.accederProduccion());
		} else if (fuente == vista.getBtnIT()) {
			vista.mostrarMensaje(empresa.accederIT());
		}
	}
}
