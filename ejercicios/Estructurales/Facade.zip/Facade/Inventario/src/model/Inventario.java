package model;

import model.modulos.*;

import java.util.List;

public class Inventario {
	private InventarioGeneral general = new InventarioGeneral();
	private InventarioFavoritos favoritos = new InventarioFavoritos();
	private InventarioMunicion municion = new InventarioMunicion();
	private InventarioArmadura armadura = new InventarioArmadura();
	private InventarioCocina cocina = new InventarioCocina();
	private InventarioSalud salud = new InventarioSalud();

	public List<String> getGeneral() {
		return general.getObjetos();
	}

	public List<String> getFavoritos() {
		return favoritos.getObjetos();
	}

	public List<String> getMunicion() {
		return municion.getObjetos();
	}

	public List<String> getArmadura() {
		return armadura.getObjetos();
	}

	public List<String> getCocina() {
		return cocina.getObjetos();
	}

	public List<String> getSalud() {
		return salud.getObjetos();
	}
}
