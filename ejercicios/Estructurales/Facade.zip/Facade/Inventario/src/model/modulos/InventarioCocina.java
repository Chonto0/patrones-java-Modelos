package model.modulos;

import java.util.Arrays;
import java.util.List;

public class InventarioCocina {

	public List<String> getObjetos() {
		return Arrays.asList("Pescado crudo x3, Pan horneado x5, Frutas silvestres x10");
	}
}
