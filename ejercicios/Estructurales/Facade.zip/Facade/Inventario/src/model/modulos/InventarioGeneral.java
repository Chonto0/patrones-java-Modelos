package model.modulos;

import java.util.Arrays;
import java.util.List;

public class InventarioGeneral {

	public List<String> getObjetos() {
		return Arrays.asList("Espada de acero, Botas de cuero");
	}
}
