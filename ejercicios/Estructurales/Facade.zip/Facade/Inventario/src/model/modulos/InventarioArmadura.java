package model.modulos;

import java.util.Arrays;
import java.util.List;

public class InventarioArmadura {
	
	public List<String> getObjetos() {
		return Arrays.asList("Casco de acero", "Peto encantado");
	}
}
