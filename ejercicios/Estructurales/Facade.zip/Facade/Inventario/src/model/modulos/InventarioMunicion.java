package model.modulos;

import java.util.Arrays;
import java.util.List;

public class InventarioMunicion {

	public List<String> getObjetos() {
		return Arrays.asList("Flechas de acero x30, Explosivos de mano x2");

	}
}
