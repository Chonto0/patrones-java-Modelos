package model.modulos;

import java.util.Arrays;
import java.util.List;

public class InventarioSalud {

	public List<String> getObjetos() {
		return Arrays.asList("Pociones de curación x4, Vendajes x6, Antídoto x2");

	}
}
