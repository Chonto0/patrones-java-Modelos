package controller;

import view.MenuInventarioView;
import model.Inventario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {

	private MenuInventarioView vista;
	private Inventario inventario;

	public Controller() {
		vista = new MenuInventarioView();
		inventario = new Inventario();
		vista.setListener(this);
		vista.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object fuente = e.getSource();

		if (fuente == vista.getBtnGeneral()) {
			vista.mostrarObjetos(inventario.getGeneral());
		} else if (fuente == vista.getBtnFavoritos()) {
			vista.mostrarObjetos(inventario.getFavoritos());
		} else if (fuente == vista.getBtnMunicion()) {
			vista.mostrarObjetos(inventario.getMunicion());
		} else if (fuente == vista.getBtnArmadura()) {
			vista.mostrarObjetos(inventario.getArmadura());
		} else if (fuente == vista.getBtnCocina()) {
			vista.mostrarObjetos(inventario.getCocina());
		} else if (fuente == vista.getBtnSalud()) {
			vista.mostrarObjetos(inventario.getSalud());
		} else if (fuente == vista.getBtnSalir()) {
			JOptionPane.showMessageDialog(vista, "¡Gracias por revisar el inventario!");
			System.exit(0);
		}
	}
}
