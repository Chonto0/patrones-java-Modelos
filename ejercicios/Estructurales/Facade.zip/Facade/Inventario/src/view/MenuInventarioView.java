package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class MenuInventarioView extends JFrame {

	private JPanel panelBotones;
	private JPanel panelContenido;

	private JButton btnGeneral, btnFavoritos, btnMunicion, btnArmadura, btnCocina, btnSalud, btnSalir;

	public MenuInventarioView() {
		setTitle("Menú de Inventario");
		setSize(600, 400);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());

		// Botones del menú
		panelBotones = new JPanel();
		panelBotones.setLayout(new GridLayout(1, 7));
		panelBotones.setBackground(new Color(30, 30, 30));

		btnGeneral = new JButton("General");
		btnFavoritos = new JButton("Favoritos");
		btnMunicion = new JButton("Munición");
		btnArmadura = new JButton("Armadura");
		btnCocina = new JButton("Cocina");
		btnSalud = new JButton("Salud");
		btnSalir = new JButton("Salir");

		for (JButton b : new JButton[] { btnGeneral, btnFavoritos, btnMunicion, btnArmadura, btnCocina, btnSalud,
				btnSalir }) {
			b.setFocusPainted(false);
			panelBotones.add(b);
		}

		// Panel donde se muestran los objetos
		panelContenido = new JPanel();
		panelContenido.setBackground(new Color(50, 50, 50));
		panelContenido.setLayout(new BoxLayout(panelContenido, BoxLayout.Y_AXIS));

		add(panelBotones, BorderLayout.NORTH);
		add(new JScrollPane(panelContenido), BorderLayout.CENTER);
	}

	public void setListener(ActionListener listener) {
		btnGeneral.addActionListener(listener);
		btnFavoritos.addActionListener(listener);
		btnMunicion.addActionListener(listener);
		btnArmadura.addActionListener(listener);
		btnCocina.addActionListener(listener);
		btnSalud.addActionListener(listener);
		btnSalir.addActionListener(listener);
	}

	public JButton getBtnGeneral() {
		return btnGeneral;
	}

	public JButton getBtnFavoritos() {
		return btnFavoritos;
	}

	public JButton getBtnMunicion() {
		return btnMunicion;
	}

	public JButton getBtnArmadura() {
		return btnArmadura;
	}

	public JButton getBtnCocina() {
		return btnCocina;
	}

	public JButton getBtnSalud() {
		return btnSalud;
	}

	public JButton getBtnSalir() {
		return btnSalir;
	}

	public void mostrarObjetos(List<String> objetos) {
		panelContenido.removeAll();
		for (String obj : objetos) {
			JLabel etiqueta = new JLabel("🔹 " + obj);
			etiqueta.setForeground(Color.WHITE);
			etiqueta.setFont(new Font("Arial", Font.PLAIN, 16));
			panelContenido.add(etiqueta);
			panelContenido.add(Box.createVerticalStrut(10));
		}
		panelContenido.revalidate();
		panelContenido.repaint();
	}
}
