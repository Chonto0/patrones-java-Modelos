package model.abstraccion;

import model.implementador.Microfono;

public class MicrofonoCondensador extends TipoMicrofono {

	public MicrofonoCondensador(Microfono marca) {
		super(marca);
	}

	@Override
	public void iniciarGrabacion() {
		marca.grabarAudio();
	}


	@Override
	public String getDescripcion() {
		return "Micrófono Condensador de marca " + marca.getNombre();
	}
}
