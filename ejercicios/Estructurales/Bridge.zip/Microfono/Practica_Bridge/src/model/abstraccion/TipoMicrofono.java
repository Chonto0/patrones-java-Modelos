package model.abstraccion;

import model.implementador.Microfono;

public abstract class TipoMicrofono {

	protected Microfono marca;

	public TipoMicrofono(Microfono marca) {
		this.marca = marca;
	}

	public abstract void iniciarGrabacion();

	public abstract String getDescripcion();
}
