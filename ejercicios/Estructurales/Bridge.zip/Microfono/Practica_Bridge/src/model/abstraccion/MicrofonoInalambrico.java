package model.abstraccion;

import model.implementador.Microfono;

public class MicrofonoInalambrico extends TipoMicrofono {

	public MicrofonoInalambrico(Microfono marca) {
		super(marca);
	}

	@Override
	public void iniciarGrabacion() {
		marca.grabarAudio();
	}



	@Override
	public String getDescripcion() {
		return "Micrófono Inalámbrico de marca " + marca.getNombre();
	}
}
