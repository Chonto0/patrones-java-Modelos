package model.implementador;

public interface Microfono {
	void grabarAudio();

	String getNombre();
}
