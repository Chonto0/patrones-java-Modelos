package model.implementador;

public class HyperX implements Microfono {

	@Override
	public void grabarAudio() {
	}

	@Override
	public String getNombre() {
		return "HyperX";
	}
}
