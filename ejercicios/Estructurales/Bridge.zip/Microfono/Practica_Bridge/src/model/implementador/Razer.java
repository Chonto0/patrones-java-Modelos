package model.implementador;

public class Razer implements Microfono {

	@Override
	public void grabarAudio() {
	}

	@Override
	public String getNombre() {
		return "Razer";
	}
}
