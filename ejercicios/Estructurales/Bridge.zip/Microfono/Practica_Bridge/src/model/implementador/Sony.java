package model.implementador;

public class Sony implements Microfono {

	@Override
	public void grabarAudio() {

	}

	@Override
	public String getNombre() {
		return "Sony";
	}
}
