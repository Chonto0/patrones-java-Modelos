package controller;

public class AplMain {
    public static void main(String[] args) {
        Controller controlador = new Controller();
        controlador.run();
    }
}
