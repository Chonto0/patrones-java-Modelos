package controller;

import model.abstraccion.*;
import model.implementador.*;
import view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		int opcion;

		do {
			vista.mostrarInformacion("\n=== Menú de Grabación ===");
			vista.mostrarInformacion("1. Grabar con Micrófono Inalámbrico Sony");
			vista.mostrarInformacion("2. Grabar con Micrófono Condensador Razer");
			vista.mostrarInformacion("3. Grabar con Micrófono Inalámbrico HyperX");
			vista.mostrarInformacion("0. Salir");
			opcion = vista.leerDatoEntero("Seleccione una opción: \n");

			TipoMicrofono microfono = null;

			switch (opcion) {
			case 1:
				microfono = new MicrofonoInalambrico(new Sony());
				break;
			case 2:
				microfono = new MicrofonoCondensador(new Razer());
				break;
			case 3:
				microfono = new MicrofonoInalambrico(new HyperX());
				break;
			case 0:
				vista.mostrarInformacion("Saliendo...");
				break;
			default:
				vista.mostrarInformacion("Opción inválida.");
			}

			if (microfono != null) {
				vista.mostrarInformacion("Iniciando grabación con " + microfono.getDescripcion());
				microfono.iniciarGrabacion();
				vista.mostrarInformacion("Grabación detenida para " + microfono.getDescripcion());
			}

		} while (opcion != 0);
	}
}
