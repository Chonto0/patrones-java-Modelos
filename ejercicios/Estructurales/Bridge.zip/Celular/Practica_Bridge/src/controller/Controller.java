package controller;

import model.abstraccion.*;
import model.implementador.*;
import view.VistaConsola;

public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        DispositivoMovil smartphone = new Smartphone(new Android());
        vista.mostrarInformacion("Smartphone con Android:");
        vista.mostrarInformacion("Encendiendo Smartphone...");
        smartphone.encender();
        vista.mostrarInformacion("Abriendo YouTube...");
        smartphone.usarAplicacion("YouTube");
        vista.mostrarInformacion("Apagando Smartphone...");
        smartphone.apagar();
        
        vista.mostrarInformacion("\n--------------------------\n");

        DispositivoMovil tablet = new Tablet(new IOS());
        vista.mostrarInformacion("Tablet con iOS:");
        vista.mostrarInformacion("Encendiendo Tablet...");
        tablet.encender();
        vista.mostrarInformacion("Abriendo Safari...");
        tablet.usarAplicacion("Safari");
        vista.mostrarInformacion("Apagando Tablet...");
        tablet.apagar();

        vista.mostrarInformacion("\n--------------------------\n");
        
        DispositivoMovil celular = new CelularTeclas(new BlackBerryOS());
        vista.mostrarInformacion("Celular con BlackBerryOS:");
        vista.mostrarInformacion("Encendiendo Celular...");
        celular.encender();
        vista.mostrarInformacion("Abriendo Facebook...");
        celular.usarAplicacion("Facebook");
        vista.mostrarInformacion("Apagando Celular...");
        celular.apagar();
    }
}
