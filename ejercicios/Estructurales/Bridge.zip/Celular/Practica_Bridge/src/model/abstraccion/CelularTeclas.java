package model.abstraccion;

import model.implementador.SistemaOperativo;

public class CelularTeclas extends DispositivoMovil {
	public CelularTeclas(SistemaOperativo sistema) {
		super(sistema);
	}

	@Override
	public void encender() {
		sistema.iniciarSistema();
	}

	@Override
	public void usarAplicacion(String app) {
		sistema.abrirAplicacion(app);
	}

	@Override
	public void apagar() {
		sistema.apagarSistema();
	}
}
