package model.abstraccion;

import model.implementador.SistemaOperativo;

public abstract class DispositivoMovil {
    protected SistemaOperativo sistema;

    public DispositivoMovil(SistemaOperativo sistema) {
        this.sistema = sistema;
    }

    public abstract void encender();
    public abstract void usarAplicacion(String app);
    public abstract void apagar();
}
