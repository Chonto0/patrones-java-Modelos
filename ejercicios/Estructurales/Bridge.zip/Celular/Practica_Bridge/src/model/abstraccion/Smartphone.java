package model.abstraccion;

import model.implementador.SistemaOperativo;

public class Smartphone extends DispositivoMovil {
    public Smartphone(SistemaOperativo sistema) {
        super(sistema);
    }

    @Override
    public void encender() {
        sistema.iniciarSistema();
    }

    @Override
    public void usarAplicacion(String app) {
        sistema.abrirAplicacion(app);
    }

    @Override
    public void apagar() {
        sistema.apagarSistema();
    }
}
