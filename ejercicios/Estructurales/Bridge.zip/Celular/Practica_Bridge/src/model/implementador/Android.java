package model.implementador;

public class Android implements SistemaOperativo {
	@Override
	public void iniciarSistema() {
	}

	@Override
	public void abrirAplicacion(String app) {
	}

	@Override
	public void apagarSistema() {
	}
}
