package model.implementador;

public interface SistemaOperativo {
    void iniciarSistema();
    void abrirAplicacion(String app);
    void apagarSistema();
}
