package model.implementador;

public class IOS implements SistemaOperativo {
	@Override
	public void iniciarSistema() {
	}

	@Override
	public void abrirAplicacion(String app) {
	}

	@Override
	public void apagarSistema() {
	}
}
