package model.abstraccion;

import model.implementador.PlataformaStreaming;

public class Reproduccion4K extends TipoReproduccion {

	public Reproduccion4K(PlataformaStreaming plataforma) {
		super(plataforma);
	}

	@Override
	public String reproducirPelicula(String titulo) {
		return "Iniciando reproducción 4K...\n" + plataforma.cargarContenido(titulo) + "\n" + plataforma.reproducir();
	}

	@Override
	public String detenerReproduccion() {
		return "\nReproducción 4K finalizada.";
	}
}
