package model.abstraccion;

import model.implementador.PlataformaStreaming;

public abstract class TipoReproduccion {

	PlataformaStreaming plataforma;

	public TipoReproduccion(PlataformaStreaming plataforma) {
		this.plataforma = plataforma;
	}

	public abstract String reproducirPelicula(String titulo);

	public abstract String detenerReproduccion();
}