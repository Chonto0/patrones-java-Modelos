package model.abstraccion;

import model.implementador.PlataformaStreaming;

public class ReproduccionHD extends TipoReproduccion {

	public ReproduccionHD(PlataformaStreaming plataforma) {
		super(plataforma);
	}

	@Override
	public String reproducirPelicula(String titulo) {
		return "Iniciando reproducción HD...\n" + plataforma.cargarContenido(titulo) + "\n" + plataforma.reproducir();
	}

	@Override
	public String detenerReproduccion() {
		return "\nReproducción HD finalizada.";
	}
}
