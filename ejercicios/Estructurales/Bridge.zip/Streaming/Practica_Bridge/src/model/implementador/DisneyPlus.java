package model.implementador;

public class DisneyPlus implements PlataformaStreaming {

	public String cargarContenido(String titulo) {
		return "Disney+ cargando: " + titulo;
	}

	@Override
	public String reproducir() {
		return "Reproduciendo en Disney+...";
	}

	@Override
	public String detener() {
		return "Reproducción detenida en Disney+.";
	}
}
