package model.implementador;

public class PrimeVideo implements PlataformaStreaming {

	@Override
	public String cargarContenido(String titulo) {
		return "Prime Video cargando: " + titulo;
	}

	@Override
	public String reproducir() {
		return "Reproduciendo en Prime Video...";
	}

	@Override
	public String detener() {
		return "Reproducción detenida en Prime Video.";
	}
}
