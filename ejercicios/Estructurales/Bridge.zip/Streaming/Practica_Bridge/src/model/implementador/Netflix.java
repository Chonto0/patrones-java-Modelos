package model.implementador;

public class Netflix implements PlataformaStreaming {

	public String cargarContenido(String titulo) {
		return "Netflix cargando: "+ titulo;
	}

	public String reproducir() {
		return "Reproduciendo en Netflix...";
	}

	public String detener() {
		return "Reproducción detenida en Netflix.";
	}
}
