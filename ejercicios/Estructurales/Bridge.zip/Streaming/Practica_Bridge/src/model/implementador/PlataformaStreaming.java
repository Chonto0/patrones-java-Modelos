package model.implementador;

public interface PlataformaStreaming {
	String cargarContenido(String titulo);
	String reproducir();
	String detener();
}