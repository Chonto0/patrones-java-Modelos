package controller;

import model.abstraccion.*;
import model.implementador.*;
import view.VistaConsola;

public class Controller {

	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("=== Reproductor de Películas ===\n");

		TipoReproduccion hdNetflix = new ReproduccionHD(new Netflix());
		vista.mostrarInformacion(hdNetflix.reproducirPelicula("Inception"));
		vista.mostrarInformacion(hdNetflix.detenerReproduccion());

		vista.mostrarInformacion("");

		TipoReproduccion uhdDisney = new Reproduccion4K(new DisneyPlus());
		vista.mostrarInformacion(uhdDisney.reproducirPelicula("Avengers: Endgame"));
		vista.mostrarInformacion(uhdDisney.detenerReproduccion());

		vista.mostrarInformacion("");

		TipoReproduccion hdPrime = new ReproduccionHD(new PrimeVideo());
		vista.mostrarInformacion(hdPrime.reproducirPelicula("The Boys"));
		vista.mostrarInformacion(hdPrime.detenerReproduccion());
	}
}
