package controller;

import model.os.*;
import model.app.*;
import model.adapter.*;
import view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		this.vista = new VistaConsola();
	}

	public void run() {
		vista.mostrarInformacion("Bienvenido al Simulador de Ejecución de Aplicaciones");

		boolean continuar = true;

		while (continuar) {
			String osVersion = vista.leerTexto("Ingrese la versión del sistema operativo (v1 o v2): ");
			String appType = vista.leerTexto("Ingrese el tipo de app a ejecutar (legacy o modern): ");

			OS os = switch (osVersion.toLowerCase()) {
			case "v2" -> new AndroidV2();
			case "v1" -> new AndroidV1();
			default -> {
				vista.mostrarInformacion("Versión no válida. Se usará Android v1 por defecto.");
				yield new AndroidV1();
			}
			};

			MobileApp app = switch (appType.toLowerCase()) {
			case "modern" -> new ModernApp();
			case "legacy" -> new LegacyApp();
			default -> {
				vista.mostrarInformacion("Tipo de app no válido. Se usará Legacy por defecto.");
				yield new LegacyApp();
			}
			};

			AppAdapter adapter = new AppAdapter(app, os);
			vista.mostrarInformacion(adapter.execute());

			String respuesta = vista.leerTexto("¿Desea ejecutar otra app? (si/no): ");
			continuar = respuesta.equalsIgnoreCase("si");
		}

		vista.mostrarInformacion("Gracias por usar el simulador. ¡Hasta pronto!");
	}
}
