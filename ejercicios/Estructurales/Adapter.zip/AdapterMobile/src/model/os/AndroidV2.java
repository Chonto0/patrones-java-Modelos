package model.os;

public class AndroidV2 implements OS {

    @Override
    public String getVersion() {
        return "Android v2.0";
    }

    @Override
    public String launchAPI() {
        return "Ejecutando API avanzada (v2)";
    }
}
