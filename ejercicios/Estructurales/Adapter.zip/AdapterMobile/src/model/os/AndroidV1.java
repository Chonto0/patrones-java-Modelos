package model.os;

public class AndroidV1 implements OS {

    @Override
    public String getVersion() {
        return "Android v1.0";
    }

    @Override
    public String launchAPI() {
        return "Ejecutando API básica (sólo v1)";
    }
}
