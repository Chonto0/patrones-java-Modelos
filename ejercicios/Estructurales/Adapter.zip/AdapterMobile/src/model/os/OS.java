package model.os;

public interface OS {
    String getVersion();
    String launchAPI();
}
