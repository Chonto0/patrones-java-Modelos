package model.adapter;

import model.app.LegacyApp;
import model.app.MobileApp;
import model.app.ModernApp;
import model.os.OS;

public class AppAdapter implements MobileApp {

	private MobileApp app;
	private OS os;

	public AppAdapter(MobileApp app, OS os) {
		this.app = app;
		this.os = os;
	}

	@Override
	public String execute() {
		StringBuilder resultado = new StringBuilder();
		resultado.append("Dispositivo con ").append(os.getVersion()).append("\n");

		if (app instanceof ModernApp && os.getVersion().startsWith("Android v1")) {
			resultado.append("ModernApp no es compatible con ").append(os.getVersion())
					.append(". Ejecutando modo degradado...\n");
			resultado.append(os.launchAPI()).append("\n");
			resultado.append(new LegacyApp().execute());
		} else {
			resultado.append(os.launchAPI()).append("\n");
			resultado.append(app.execute());
		}

		return resultado.toString();
	}
}
