package model.app;

public interface MobileApp {
    String execute();
}
