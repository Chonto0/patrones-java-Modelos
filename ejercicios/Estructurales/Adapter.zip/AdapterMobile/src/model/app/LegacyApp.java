package model.app;

public class LegacyApp implements MobileApp {
    @Override
    public String execute() {
        return "LegacyApp: uso de funcionalidades básicas.";
    }
}
