package model.app;

public class ModernApp implements MobileApp {
    @Override
    public String execute() {
        return "ModernApp: uso de funcionalidades avanzadas.";
    }
}
