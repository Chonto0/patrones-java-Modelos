package model;

public interface HDMI {
    String conectarConHDMI();
}
