package model;

public class Laptop implements HDMI {
	@Override
	public String conectarConHDMI() {
		return "Laptop conectada por HDMI.";
	}
}
