package model;

public class HDMIaVGAAdapter implements VGA {
    private HDMI dispositivoHDMI;

    public HDMIaVGAAdapter(HDMI dispositivoHDMI) {
        this.dispositivoHDMI = dispositivoHDMI;
    }

    @Override
    public String conectarConVGA() {
        String conversion = "Adaptador convierte señal de HDMI a VGA...";
        String resultadoHDMI = dispositivoHDMI.conectarConHDMI();
        return conversion + "\n" + resultadoHDMI;
    }
}
