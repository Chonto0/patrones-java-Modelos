package model;

public interface VGA {
    String conectarConVGA();
}
