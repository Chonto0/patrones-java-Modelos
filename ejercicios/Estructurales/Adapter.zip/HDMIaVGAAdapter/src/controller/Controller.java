package controller;

import model.*;
import view.VistaConsola;

public class Controller {
	private VistaConsola vista;

	public Controller() {
		vista = new VistaConsola();
	}

	public void run() {
		HDMI laptop = new Laptop(); // modelo
		VGA adaptador = new HDMIaVGAAdapter(laptop); // adapter
		conectarDispositivo(adaptador);
	}

	public void conectarDispositivo(VGA cableVGA) {
		vista.mostrarInformacion("Proyector intentando conectarse...");
		vista.mostrarInformacion(cableVGA.conectarConVGA());
		vista.mostrarInformacion("¡Proyección en curso!\n");
	}
}
