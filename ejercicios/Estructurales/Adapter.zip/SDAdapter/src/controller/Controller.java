package controller;

import model.*;
import view.VistaConsola;

public class Controller {
    private VistaConsola view;

    public Controller() {
        this.view = new VistaConsola();
    }

    public void run() {
        view.mostrarInformacion("Iniciando simulación de dispositivos USB...\n");

        // Crear tarjetas
        SDCard sd = new SDCard();
        MicroSDCard microSD = new MicroSDCard();

        // Crear adaptadores
        USBDevice sdAdapter = new SDCardReaderAdapter(sd);
        USBDevice microSDAdapter = new MicroSDCardReaderAdapter(microSD);

        // Conectar dispositivos
        conectarUSB(sdAdapter);
        conectarUSB(microSDAdapter);

        view.mostrarInformacion("Proceso finalizado.");
    }

    public void conectarUSB(USBDevice device) {
        view.mostrarInformacion("Conectando dispositivo USB...");
        view.mostrarInformacion(device.readData());
        view.mostrarInformacion("———\n");
    }
}
