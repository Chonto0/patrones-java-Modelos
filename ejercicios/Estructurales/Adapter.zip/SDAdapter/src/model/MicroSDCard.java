package model;

public class MicroSDCard {
    public String accessMicroSD() {
        return "Leyendo datos desde la tarjeta microSD...";
    }
}
