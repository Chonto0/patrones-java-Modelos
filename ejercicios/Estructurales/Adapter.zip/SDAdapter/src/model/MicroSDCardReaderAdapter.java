package model;

public class MicroSDCardReaderAdapter implements USBDevice {
    private MicroSDCard microSDCard;

    public MicroSDCardReaderAdapter(MicroSDCard microSDCard) {
        this.microSDCard = microSDCard;
    }

    @Override
    public String readData() {
        return microSDCard.accessMicroSD();
    }
}
