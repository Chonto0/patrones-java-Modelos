package model;

public class SDCardReaderAdapter implements USBDevice {
    private SDCard sdCard;

    public SDCardReaderAdapter(SDCard sdCard) {
        this.sdCard = sdCard;
    }

    @Override
    public String readData() {
        return sdCard.readFromSD();
    }
}
