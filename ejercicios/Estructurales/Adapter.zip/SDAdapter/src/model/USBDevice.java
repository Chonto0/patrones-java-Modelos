package model;

public interface USBDevice {
    String readData(); 
}
