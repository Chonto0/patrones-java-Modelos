package model;

public class SDCard {
    public String readFromSD() {
        return "Leyendo datos desde la tarjeta SD...";
    }
}
