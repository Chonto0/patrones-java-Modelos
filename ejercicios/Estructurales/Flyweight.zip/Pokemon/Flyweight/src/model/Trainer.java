package model;

import java.util.ArrayList;
import java.util.List;

public class Trainer {
    private List<Pokemon> pokemons = new ArrayList<>();

    public void addPokemon(String nickname, int nivel, String especie, String tipo, String[] habilidades) {
        PokemonType pokemonType = PokemonFactory.getPokemonType(especie, tipo, habilidades);
        Pokemon pokemon = new Pokemon(nickname, nivel, pokemonType);
        pokemons.add(pokemon);
    }

    public List<String> getPokemonInfo() {
        List<String> infoList = new ArrayList<>();
        for (Pokemon p : pokemons) {
            infoList.add(p.getInfo());
        }
        return infoList;
    }
}
