package model;

public class PokemonType {
    private String especie;
    private String tipo;
    private String[] habilidades;

    public PokemonType(String especie, String tipo, String[] habilidades) {
        this.especie = especie;
        this.tipo = tipo;
        this.habilidades = habilidades;
    }

    public String getInfo(String nickname, int level) {
        StringBuilder info = new StringBuilder();
        info.append("Pokémon: ").append(nickname).append(" (Nivel ").append(level).append(")\n");
        info.append("  Especie: ").append(especie).append(" | Tipo: ").append(tipo).append("\n");
        info.append("  Habilidades: ");
        for (String habilidad : habilidades) {
            info.append(habilidad).append(" ");
        }
        info.append("\n---------------------------");
        return info.toString();
    }
}
