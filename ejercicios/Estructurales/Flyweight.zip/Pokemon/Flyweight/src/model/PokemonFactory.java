package model;

import java.util.HashMap;
import java.util.Map;

public class PokemonFactory {
    private static Map<String, PokemonType> types = new HashMap<>();

    public static PokemonType getPokemonType(String especie, String tipo, String[] habilidades) {
        String key = especie + "-" + tipo + "-" + String.join(",", habilidades);

        if (!types.containsKey(key)) {
            types.put(key, new PokemonType(especie, tipo, habilidades));
        }

        return types.get(key);
    }
}
