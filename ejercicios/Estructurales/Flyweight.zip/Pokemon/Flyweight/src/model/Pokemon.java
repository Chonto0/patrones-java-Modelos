package model;

public class Pokemon {
    private String nickname;
    private int nivel;
    private PokemonType tipo;

    public Pokemon(String nickname, int nivel, PokemonType tipo) {
        this.nickname = nickname;
        this.nivel = nivel;
        this.tipo = tipo;
    }

    public String getInfo() {
        return tipo.getInfo(nickname, nivel);
    }
}
