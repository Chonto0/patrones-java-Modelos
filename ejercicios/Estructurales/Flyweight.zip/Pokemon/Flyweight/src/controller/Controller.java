package controller;

import model.Trainer;
import view.VistaConsola;

public class Controller {
    private Trainer ash;
    private VistaConsola vista;

    public void run() {
        ash = new Trainer();
        vista = new VistaConsola();

        ash.addPokemon("Sparky", 15, "Pikachu", "Eléctrico", new String[]{"Impactrueno", "Agilidad"});
        ash.addPokemon("Bolt", 12, "Pikachu", "Eléctrico", new String[]{"Impactrueno", "Agilidad"});
        ash.addPokemon("Blaze", 30, "Charizard", "Fuego", new String[]{"Lanzallamas", "Vuelo"});
        ash.addPokemon("Inferno", 33, "Charizard", "Fuego", new String[]{"Lanzallamas", "Vuelo"});

        vista.mostrarInformacion("\nPokémon registrados:\n");
        for (String info : ash.getPokemonInfo()) {
            vista.mostrarInformacion(info);
        }
    }
}
