package model;

import java.util.ArrayList;
import java.util.List;

public class Almacen {
	private List<Gafas> gafasList = new ArrayList<>();

	public boolean addGafas(String marca, String formula, String marco, String color, String materialentes) {
		boolean isNew = GafasFactory.isNewType(marco, color, materialentes);
		GafasType type = GafasFactory.getGafasType(marco, color, materialentes);
		gafasList.add(new Gafas(marca, formula, type));
		return isNew;
	}

	public List<String> listarGafas() {
		List<String> resultado = new ArrayList<>();
		for (Gafas g : gafasList) {
			resultado.add(g.draw());
		}
		return resultado;
	}
}
