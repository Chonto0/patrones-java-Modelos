package model;

import java.util.HashMap;
import java.util.Map;

// Flyweight Factory
public class GafasFactory {
    private static Map<String, GafasType> gafasTypeMap = new HashMap<>();

    public static GafasType getGafasType(String marco, String color, String materialentes) {
        String key = marco + ":" + color + ":" + materialentes;

        if (!gafasTypeMap.containsKey(key)) {
            gafasTypeMap.put(key, new GafasType(marco, color, materialentes));
        }

        return gafasTypeMap.get(key);
    }

    public static boolean isNewType(String marco, String color, String materialentes) {
        String key = marco + ":" + color + ":" + materialentes;
        return !gafasTypeMap.containsKey(key);
    }
}
