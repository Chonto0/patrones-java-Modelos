package model;

// Contexto
public class Gafas {
    private String marca;
    private String formula;
    private GafasType gafasType;

    public Gafas(String marca, String formula, GafasType gafasType) {
        this.marca = marca;
        this.formula = formula;
        this.gafasType = gafasType;
    }

    public String draw() {
        return gafasType.draw(marca, formula);
    }
}
