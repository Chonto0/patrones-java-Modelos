package model;

// Clase Flyweight
public class GafasType {
    private String marco;
    private String color;
    private String materialentes;

    public GafasType(String marco, String color, String materialentes) {
        this.marco = marco;
        this.color = color;
        this.materialentes = materialentes;
    }

    public String draw(String marca, String formula) {
        return "Gafas: [Marco: " + marco + ", Color: " + color + ", Material de lentes: " +
                materialentes + ", Marca: " + marca + ", Formula: " + formula + "]";
    }
}
