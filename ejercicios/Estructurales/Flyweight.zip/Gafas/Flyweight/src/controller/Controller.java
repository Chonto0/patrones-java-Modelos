package controller;

import model.Almacen;
import view.VistaConsola;

public class Controller {

	private Almacen almacen;
	private VistaConsola vista;

	public void run() {
        almacen = new Almacen();
        vista = new VistaConsola();

        byte opcion;
        do {
            opcion = Byte.parseByte(vista.leerTexto(
                    "\nDijita la opción que desees realizar: \n1. Agregar Gafas a tu almacen \n2. Ver todas las gafas de tu almacen \n3. Salir\n\n"));
   

            switch (opcion) {
                case 1 -> {
                    String marca = vista.leerTexto("¿Cuál es la marca de tus gafas? ");
                    String formula = vista.leerTexto("¿Cuál es la fórmula de tus gafas? ");
                    String marco = vista.leerTexto("¿Cuál es el marco de tus gafas? ");
                    String color = vista.leerTexto("¿Cuál es el color de tus gafas? ");
                    String materialentes = vista.leerTexto("¿Cuál es el material de tus lentes? ");

                    boolean nuevo = almacen.addGafas(marca, formula, marco, color, materialentes);
                    if (nuevo) {
                        vista.mostrarInformacion("✔ Se ha creado un nuevo tipo de gafas.");
                    } else {
                        vista.mostrarInformacion("✔ Tipo de gafas ya existente, se reutiliza.");
                    }
                }
                case 2 -> vista.mostrarLista("Lista de Gafas en Almacén", almacen.listarGafas());
                case 3 -> vista.mostrarInformacion("Gracias por tu visita.");
                default -> vista.mostrarInformacion("Opción no válida.");
            }

        } while (opcion != 3);
    }
}
