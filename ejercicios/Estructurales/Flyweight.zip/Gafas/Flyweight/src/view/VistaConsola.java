package view;

import java.util.Scanner;

public class VistaConsola {

    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarLista(String titulo, java.util.List<String> items) {
        System.out.println(titulo);
        for (String item : items) {
            System.out.println("- " + item);
        }
    }

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }
}
