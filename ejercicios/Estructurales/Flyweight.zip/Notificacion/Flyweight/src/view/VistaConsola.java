package view;

import java.util.Scanner;
import java.util.List;

public class VistaConsola {
    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarLista(List<String> mensajes) {
        for (String m : mensajes) {
            System.out.println(m);
        }
    }

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }
}
