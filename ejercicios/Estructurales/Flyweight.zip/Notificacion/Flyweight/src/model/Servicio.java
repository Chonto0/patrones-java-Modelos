package model;

import java.util.ArrayList;
import java.util.List;

public class Servicio {
    private List<Notificacion> notificaciones = new ArrayList<>();
    private List<String> mensajes = new ArrayList<>();

    public void addNotification(String destinatario, String canal, String hora, String titulo, String cuerpo, String icono) {
        boolean nueva = NotificacionFactory.isNewType(titulo, cuerpo, icono);
        TypeNotificacion tipo = NotificacionFactory.getTypeNotificacion(titulo, cuerpo, icono);
        notificaciones.add(new Notificacion(destinatario, canal, hora, tipo));
        if (nueva) {
            mensajes.add("Creando nuevo tipo de notificación: " + titulo +"\n");
        }
    }

    public List<String> sendAll() {
        List<String> salida = new ArrayList<>(mensajes);
        for (Notificacion n : notificaciones) {
            salida.add(n.send());
        }
        return salida;
    }
}
