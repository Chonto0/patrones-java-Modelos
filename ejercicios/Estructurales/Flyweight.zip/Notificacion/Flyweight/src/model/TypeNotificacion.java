package model;

public class TypeNotificacion {
    private String titulo;
    private String cuerpo;
    private String icono;

    public TypeNotificacion(String titulo, String cuerpo, String icono) {
        this.titulo = titulo;
        this.cuerpo = cuerpo;
        this.icono = icono;
    }

    public String display(String destinatario, String canal, String marcatiempo) {
    	return String.format(
    		    "Notificación para: %s\nCanal: %s | Hora: %s\nTítulo: %s\nCuerpo: %s\nIcono: %s\n-----------------------",
    		    destinatario, canal, marcatiempo, titulo, cuerpo, icono
    		);
    }
}