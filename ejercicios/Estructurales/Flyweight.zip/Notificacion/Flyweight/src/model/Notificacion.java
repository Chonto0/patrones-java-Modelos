package model;

public class Notificacion {
    private String destinatario;
    private String canal;
    private String hora;
    private TypeNotificacion tipo;

    public Notificacion(String destinatario, String canal, String hora, TypeNotificacion tipo) {
        this.destinatario = destinatario;
        this.canal = canal;
        this.hora = hora;
        this.tipo = tipo;
    }

    public String send() {
        return tipo.display(destinatario, canal, hora);
    }
}
