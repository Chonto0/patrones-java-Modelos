package model;

import java.util.HashMap;
import java.util.Map;

public class NotificacionFactory {
    private static Map<String, TypeNotificacion> types = new HashMap<>();

    public static TypeNotificacion getTypeNotificacion(String titulo, String cuerpo, String icono) {
        String key = titulo + "|" + cuerpo + "|" + icono;
        if (!types.containsKey(key)) {
            types.put(key, new TypeNotificacion(titulo, cuerpo, icono));
        }
        return types.get(key);
    }

    public static boolean isNewType(String titulo, String cuerpo, String icono) {
        String key = titulo + "|" + cuerpo + "|" + icono;
        return !types.containsKey(key);
    }
}
