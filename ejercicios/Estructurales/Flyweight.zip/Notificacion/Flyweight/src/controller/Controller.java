package controller;

import model.Servicio;
import view.VistaConsola;

public class Controller {
    private VistaConsola vista;
    private Servicio servicio;

    public Controller() {
        this.vista = new VistaConsola();
        this.servicio = new Servicio();
    }

    public void run() {
        // Agregar notificaciones (algunas con tipos repetidos)
        servicio.addNotification("Juan", "email", "2025-06-16 09:00", "Nueva oferta disponible",
                "¡Aprovecha el 50% de descuento!", "$");

        servicio.addNotification("Luisa", "SMS", "2025-06-16 09:05", "Nueva oferta disponible",
                "¡Aprovecha el 50% de descuento!", "$");

        servicio.addNotification("Carlos", "push", "2025-06-16 10:00", "Recordatorio de evento",
                "Tu evento inicia en 1 hora", "!!!");

        servicio.addNotification("Ana", "email", "2025-06-16 10:10", "Recordatorio de evento",
                "Tu evento inicia en 1 hora", "!!!");

        vista.mostrarInformacion("\n°°° Notificaciones enviadas:\n");
        vista.mostrarLista(servicio.sendAll());
    }
}
